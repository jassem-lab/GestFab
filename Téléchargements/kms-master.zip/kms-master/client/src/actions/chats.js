import * as api from "../api/index.js";
import {
  GET_CHAT,
  CREATE_CHAT,
  MESSAGE_SEEN,
  START_LOADING_CHAT,
  END_LOADING_CHAT,
  GET_CHATS,
  CHATS_START_LOADING,
  CHATS_END_LOADING,
  DELETE_CHAT,
  MESSAGE_SEEN_BY_PATIENT,
  GET_CHATS_BY_DOCTORS,
  EDIT_CHAT,
  CHATS_STARTS_LOADING,
  CHATS_ENDS_LOADING,
} from "../constants/actionTypes.js";

export const GetChat = (id, filters) => async (dispatch) => {
  try {
    dispatch({ type: START_LOADING_CHAT });
    const { data } = await api.fetchChat(id, filters);
    dispatch({ type: GET_CHAT, payload: data });
    dispatch({ type: END_LOADING_CHAT });
  } catch (error) {
    console.log(error);
  }
};

export const getChats = () => async (dispatch) => {
  try {
    dispatch({ type: CHATS_STARTS_LOADING });
    const { data, headers } = await api.fetchChats();
    dispatch({
      type: GET_CHATS,
      payload: { data, numberOfPages: +headers["x-pagination-count"] },
    });
    dispatch({ type: CHATS_ENDS_LOADING });
  } catch (error) {
    console.log(error);
  }
};

export const getChatsByDoctors = (doctors) => async (dispatch) => {
  try {
    dispatch({ type: CHATS_START_LOADING });
    const { data, headers } = await api.fetchChatsByDoctors(doctors);
    dispatch({
      type: GET_CHATS_BY_DOCTORS,
      payload: { data, numberOfPages: +headers["x-pagination-count"] },
    });
    dispatch({ type: CHATS_END_LOADING });
  } catch (error) {
    console.log(error);
  }
};

export const createChat = (formData) => async (dispatch) => {
  try {
    dispatch({ type: START_LOADING_CHAT });
    const { data } = await api.createChat(formData);
    dispatch({ type: CREATE_CHAT, payload: data });
    dispatch({ type: END_LOADING_CHAT });
  } catch (error) {
    console.log(error);
  }
};

export const editChat = (id, formData) => async (dispatch) => {
  try {
    dispatch({ type: START_LOADING_CHAT });
    const { data } = await api.editChat(id, formData);
    dispatch({ type: EDIT_CHAT, payload: data });
    dispatch({ type: END_LOADING_CHAT });
  } catch (error) {
    console.log(error);
  }
};

export const deleteChat = (id) => async (dispatch) => {
  try {
    await api.deleteChat(id);
    dispatch({ type: DELETE_CHAT, payload: id });
  } catch (error) {
    console.log(error);
  }
};

export const messageSeen = (id) => async (dispatch) => {
  try {
    await api.messageSeen(id);
    dispatch({ type: MESSAGE_SEEN, payload: id });
  } catch (error) {
    console.log(error);
  }
};

export const messageSeenbyPatient = (id) => async (dispatch) => {
  try {
    await api.messageSeenByPatient(id);
    dispatch({ type: MESSAGE_SEEN_BY_PATIENT, payload: id });
  } catch (error) {
    console.log(error);
  }
};
