import { AGENDAS_LOADING, AGENDAS_END_LOADING, ONE_AGENDA_LOADING, ONE_AGENDA_END_LOADING, GET_AGENDA, GET_AGENDAS, CREATE_AGENDA, EDIT_AGENDA, DELETE_AGENDA, CREATE_TEMPLATE, UPDATE_TEMPLATE, GET_DOCTOR_DURATION } from "../constants/actionTypes";
import * as api from '../api/index.js';
export const getAgenda = () => async (dispatch) => {
  try {
    dispatch({ type: ONE_AGENDA_LOADING });
    const { data: { data } } = await api.fetchAgenda();
    dispatch({ type: GET_AGENDA, payload: { data } });
    dispatch({ type: ONE_AGENDA_END_LOADING });
  } catch (error) {
    console.log(error);
  }
};

export const getAgendas = () => async (dispatch) => {
    try {
      dispatch({ type: AGENDAS_LOADING });
      const { data } = await api.fetchAgendas();
      dispatch({ type: GET_AGENDAS, payload: data });
      dispatch({ type: AGENDAS_END_LOADING });
    } catch (error) {
      console.log(error);
    }
  };

  export const getDoctorDuration = (id) => async (dispatch) => {
    try {
      const { data } = await api.getDoctorDuration(id);
      dispatch({ type: GET_DOCTOR_DURATION, payload: data });
    } catch (error) {
      console.log(error);
    }
  };

  export const getAgendasByIds = (ids) => async (dispatch) => {
    try {
      dispatch({ type: AGENDAS_LOADING });
      const { data } = await api.fetchAgendasByIds(ids);
      dispatch({ type: GET_AGENDAS, payload: data });
      dispatch({ type: AGENDAS_END_LOADING });
    } catch (error) {
      console.log(error);
    }
  };

export const createAgenda = (agenda) => async (dispatch) => {
  try {
    dispatch({ type: AGENDAS_LOADING });
    const { data } = await api.createAgenda(agenda);
    dispatch({ type: CREATE_AGENDA, payload: data });
    dispatch({ type: AGENDAS_END_LOADING });
  } catch (error) {
    console.log(error);
  }
};

export const editAgenda = (id, agenda) => async (dispatch) => {
  try {
    dispatch({ type: AGENDAS_LOADING });
    const { data } = await api.editAgenda(id, agenda);
    dispatch({ type: EDIT_AGENDA, payload: data });
    dispatch({ type: AGENDAS_END_LOADING });
  } catch (error) {
    console.log(error);
  }
};

export const deleteAgenda = (id) => async (dispatch) => {
  try {
    await api.deleteAgenda(id);
    dispatch({ type: DELETE_AGENDA, payload: id });
  } catch (error) {
    console.log(error);
  }
};

export const createTemplate = (AgendaId, formData) => async (dispatch) => {
  try {
    dispatch({ type: AGENDAS_LOADING });
    const { data } = await api.createTemplate(AgendaId, formData);
    dispatch({ type: CREATE_TEMPLATE, payload: data });
    dispatch({ type: AGENDAS_END_LOADING });
  } catch (error) {
    console.log(error);
  }
}

export const editTemplate = (AgendaId, formData) => async (dispatch) => {
  try {
    dispatch({ type: AGENDAS_LOADING });
    const { data } = await api.updateTemplate(AgendaId, formData);
    dispatch({ type: UPDATE_TEMPLATE, payload: data });
    dispatch({ type: AGENDAS_END_LOADING });
  } catch (error) {
    console.log(error);
  }
}