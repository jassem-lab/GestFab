import { ETABLISSEMENTS_LOADING, ETABLISSEMENTS_END_LOADING, ONE_ETABLISSEMENT_LOADING, ONE_ETABLISSEMENT_END_LOADING, GET_ETABLISSEMENT, GET_ETABLISSEMENTS, CREATE_ETABLISSEMENT, EDIT_ETABLISSEMENT, DELETE_ETABLISSEMENT } from "../constants/actionTypes";
import * as api from '../api/index.js';

export const getEtablissement = (id) => async (dispatch) => {
  try {
    dispatch({ type: ONE_ETABLISSEMENT_LOADING });
    const { data } = await api.fetchEtablissement(id);
    dispatch({ type: GET_ETABLISSEMENT, payload: { data } });
    dispatch({ type: ONE_ETABLISSEMENT_END_LOADING });
  } catch (error) {
    console.log(error);
  }
};

export const getEtablissements = () => async (dispatch) => {
    try {
      dispatch({ type: ETABLISSEMENTS_LOADING });
      const { data } = await api.fetchEtablissements();
      dispatch({ type: GET_ETABLISSEMENTS, payload: data });
      dispatch({ type: ETABLISSEMENTS_END_LOADING });
    } catch (error) {
      console.log(error);
    }
  };

export const createEtablissement = (etablissement) => async (dispatch) => {
  try {
    dispatch({ type: ETABLISSEMENTS_LOADING });
    const { data } = await api.createEtablissement(etablissement);
    dispatch({ type: CREATE_ETABLISSEMENT, payload: data });
    dispatch({ type: ETABLISSEMENTS_END_LOADING });
  } catch (error) {
    console.log(error);
  }
};

export const editEtablissement = (id, etablissement) => async (dispatch) => {
  try {
    dispatch({ type: ETABLISSEMENTS_LOADING });
    const { data } = await api.editEtablissement(id, etablissement);
    dispatch({ type: EDIT_ETABLISSEMENT, payload: data });
    dispatch({ type: ETABLISSEMENTS_END_LOADING });
  } catch (error) {
    console.log(error);
  }
};

export const deleteEtablissement = (id) => async (dispatch) => {
  try {
    await api.deleteEtablissement(id);
    dispatch({ type: DELETE_ETABLISSEMENT, payload: id });
  } catch (error) {
    console.log(error);
  }
};