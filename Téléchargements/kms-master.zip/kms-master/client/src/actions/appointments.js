import {
  APPOINTMENTS_LOADING,
  APPOINTMENTS_END_LOADING,
  ONE_APPOINTMENT_LOADING,
  ONE_APPOINTMENT_END_LOADING,
  GET_APPOINTMENT,
  GET_APPOINTMENTS,
  FILTER_APPOINTMENTS,
  CREATE_APPOINTMENT,
  EDIT_APPOINTMENT,
  DELETE_APPOINTMENT,
  CHANGE_STATUS_APPOINTMENT,
  ADD_MANY_APPOINTMENTS,
  CHANGE_STATUS_RESA,
  GET_MY_APPOINTMENTS,
  SEED_APPOINTMENTS,
  GET_APPOINTMENTS_BY_MONTH,
  APPOINTMENTS_ERROR,
} from "../constants/actionTypes";
import * as api from "../api/index.js";

import { useEffect } from "react";

export const seedAppointments = () => async (dispatch) => {
  try {
    dispatch({ type: APPOINTMENTS_LOADING });
    const { data } = await api.seedAppointments();
    dispatch({ type: SEED_APPOINTMENTS, payload: data });
    dispatch({ type: APPOINTMENTS_END_LOADING });
  } catch (error) {
    console.log(error);
  }
};

export const getAppointmentsByMonth = (month) => async (dispatch) => {
  try {
    dispatch({ type: APPOINTMENTS_LOADING });
    const { data } = await api.fetchAppointmentsByMonth(month);
    dispatch({ type: GET_APPOINTMENTS_BY_MONTH, payload: data });
    dispatch({ type: APPOINTMENTS_END_LOADING });
  } catch (error) {
    console.log(error);
  }
};

export const getAppointment = (id) => async (dispatch) => {
  try {
    dispatch({ type: ONE_APPOINTMENT_LOADING });
    const {
      data: { data },
    } = await api.fetchAppointment(id);
    dispatch({ type: GET_APPOINTMENT, payload: { data } });
    dispatch({ type: ONE_APPOINTMENT_END_LOADING });
  } catch (error) {
    console.log(error);
  }
};

export const filterAppointments = (filters) => async (dispatch) => {
  try {
    dispatch({ type: APPOINTMENTS_LOADING });
    const { data, headers } = await api.filterAppointments(filters);
    dispatch({
      type: FILTER_APPOINTMENTS,
      payload: { data, numberOfPages: +headers["x-pagination-count"] },
    });
    dispatch({ type: APPOINTMENTS_END_LOADING });
  } catch (error) {
    console.log(error);
  }
};

export const getAppointments = () => async (dispatch) => {
  try {
    dispatch({ type: APPOINTMENTS_LOADING });
    const { data } = await api.fetchAppointments();
    dispatch({ type: GET_APPOINTMENTS, payload: data });
    dispatch({ type: APPOINTMENTS_END_LOADING });
  } catch (error) {
    console.log(error);
  }
};

export const getMyAppointments = (id, filters) => async (dispatch) => {
  try {
    dispatch({ type: APPOINTMENTS_LOADING });
    const { data, headers } = await api.fetchMyAppointments(id, filters);
    dispatch({
      type: GET_MY_APPOINTMENTS,
      payload: { data, numberOfPages: +headers["x-pagination-count"] },
    });
    dispatch({ type: APPOINTMENTS_END_LOADING });
  } catch (error) {
    console.log(error);
  }
};

export const createAppointment = (appointment) => async (dispatch) => {
  try {
    // dispatch({ type: APPOINTMENTS_LOADING });
    const { data } = await api.createAppointment(appointment);
    dispatch({ type: CREATE_APPOINTMENT, payload: data });
    dispatch({
      type: CHANGE_STATUS_RESA,
      payload: {
        id: appointment.celluleId,
        status: "taked",
        takedBy: data._id,
      },
    });
    // dispatch({ type: APPOINTMENTS_END_LOADING });
  } catch (error) {
    dispatch({ type: APPOINTMENTS_ERROR, payload: error });
  }
};

export const editAppointment = (id, appointment) => async (dispatch) => {
  try {
    // dispatch({ type: APPOINTMENTS_LOADING });
    const { data } = await api.editAppointment(id, appointment);
    dispatch({ type: EDIT_APPOINTMENT, payload: data });
    if (data?.status === "Annuler") {
      dispatch({
        type: CHANGE_STATUS_RESA,
        payload: { id: data?.celluleId, status: "free", takedBy: null },
      });
    } else {
      dispatch({
        type: CHANGE_STATUS_RESA,
        payload: { id: data.celluleId, status: "taked", takedBy: data._id },
      });
    }
    // if(data?.status === "Reported")
    // dispatch({ type: APPOINTMENTS_END_LOADING });
  } catch (error) {
    console.log(error);
  }
};

export const deleteAppointment = (id) => async (dispatch) => {
  try {
    await api.deleteAppointment(id);
    dispatch({ type: DELETE_APPOINTMENT, payload: id });
  } catch (error) {
    console.log(error);
  }
};

export const changeStatus =
  (id, resaId, status, formData) => async (dispatch) => {
    try {
      // dispatch({ type: APPOINTMENTS_LOADING });
      const { data } = await api.changeStatus(id, status, formData);
      dispatch({ type: CHANGE_STATUS_APPOINTMENT, payload: data });
      if (status === "Annuler") {
        dispatch({
          type: CHANGE_STATUS_RESA,
          payload: { id: resaId, formData, status: "free", takedBy: null },
        });
      } else {
        dispatch({
          type: CHANGE_STATUS_RESA,
          payload: { id: resaId, status: "taked", takedBy: id },
        });
      }
      // dispatch({ type: APPOINTMENTS_END_LOADING });
    } catch (error) {
      console.log(error);
    }
  };

export const addManyAppointments =
  (appointments, formData) => async (dispatch) => {
    try {
      dispatch({ type: APPOINTMENTS_LOADING });
      const { data } = await api.addManyAppointments(appointments, formData);
      dispatch({ type: ADD_MANY_APPOINTMENTS, payload: data });
      dispatch({ type: APPOINTMENTS_END_LOADING });
    } catch (error) {
      console.log(error);
    }
  };
