import { DOCTORS_LOADING, DOCTORS_END_LOADING, ONE_DOCTOR_LOADING, ONE_DOCTOR_END_LOADING, GET_DOCTOR, GET_DOCTORS, CREATE_DOCTOR, EDIT_DOCTOR, DELETE_DOCTOR, GET_DOCTORS_BY_ETAB, GET_DOCTOR_BY_USER } from "../constants/actionTypes";
import * as api from '../api/index.js';

export const getDoctor = (id) => async (dispatch) => {
  try {
    dispatch({ type: ONE_DOCTOR_LOADING });
    const { data } = await api.fetchDoctor(id);
    dispatch({ type: GET_DOCTOR, payload: data });
    dispatch({ type: ONE_DOCTOR_END_LOADING });
  } catch (error) {
    console.log(error);
  }
};

export const getDoctorByUser = (id) => async (dispatch) => {
  try {
    dispatch({ type: ONE_DOCTOR_LOADING });
    const { data } = await api.fetchDoctorByUser(id);
    dispatch({ type: GET_DOCTOR_BY_USER, payload: data });
    dispatch({ type: ONE_DOCTOR_END_LOADING });
  } catch (error) {
    console.log(error);
  }
};

export const getDoctorsByEtab = (id) => async (dispatch) => {
  try {
    dispatch({ type: ONE_DOCTOR_LOADING });
    const { data } = await api.fetchDoctorsByEtab(id);
    dispatch({ type: GET_DOCTORS_BY_ETAB, payload: data });
    dispatch({ type: ONE_DOCTOR_END_LOADING });
  } catch (error) {
    console.log(error);
  }
};

export const getDoctors = () => async (dispatch) => {
    try {
      dispatch({ type: DOCTORS_LOADING });
      const { data } = await api.fetchDoctors();
      dispatch({ type: GET_DOCTORS, payload: data });
      dispatch({ type: DOCTORS_END_LOADING });
    } catch (error) {
      console.log(error);
    }
  };

export const createDoctor = (doctor) => async (dispatch) => {
  try {
    dispatch({ type: DOCTORS_LOADING });
    const { data } = await api.createDoctor(doctor);
    dispatch({ type: CREATE_DOCTOR, payload: data });
    dispatch({ type: DOCTORS_END_LOADING });
  } catch (error) {
    console.log(error);
  }
};

export const editDoctor = (id, doctor) => async (dispatch) => {
  try {
    dispatch({ type: DOCTORS_LOADING });
    const { data } = await api.editDoctor(id, doctor);
    dispatch({ type: EDIT_DOCTOR, payload: data });
    dispatch({ type: DOCTORS_END_LOADING });
  } catch (error) {
    console.log(error);
  }
};

export const deleteDoctor = (id) => async (dispatch) => {
  try {
    await api.deleteDoctor(id);
    dispatch({ type: DELETE_DOCTOR, payload: id });
  } catch (error) {
    console.log(error);
  }
};
