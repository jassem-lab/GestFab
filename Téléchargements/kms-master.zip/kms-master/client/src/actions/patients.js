import {
  PATIENTS_LOADING,
  PATIENTS_END_LOADING,
  ONE_PATIENT_LOADING,
  ONE_PATIENT_END_LOADING,
  GET_PATIENT,
  GET_PATIENTS,
  FILTER_PATIENTS,
  CREATE_PATIENT,
  EDIT_PATIENT,
  DELETE_PATIENT,
  BLOCK_PATIENT,
  GET_PATIENTS_BY_ETAB,
  SEED_PATIENT,
  PATIENT_CHAT_LOADING,
  GET_PATIENTS_CHAT,
  PATIENT_END_LOADING,
} from "../constants/actionTypes";
import * as api from "../api/index.js";
import { useEffect } from "react";

export const getPatient = (id) => async (dispatch) => {
  try {
    dispatch({ type: ONE_PATIENT_LOADING });
    const { data } = await api.fetchPatient(id);
    dispatch({ type: GET_PATIENT, payload: data });
    dispatch({ type: ONE_PATIENT_END_LOADING });
  } catch (error) {
    console.log(error);
  }
};

export const seedPatient = () => async (dispatch) => {
  try {
    dispatch({ type: PATIENTS_LOADING });
    const { data } = await api.seedPatients();
    dispatch({ type: SEED_PATIENT, payload: data });
    dispatch({ type: PATIENTS_END_LOADING });
  } catch (error) {
    console.log(error);
  }
};

export const getPatientsByEtab = (etabId) => async (dispatch) => {
  try {
    dispatch({ type: PATIENTS_LOADING });
    const { data } = await api.fetchPatientsByEtab(etabId);
    dispatch({ type: GET_PATIENTS_BY_ETAB, payload: data });
    dispatch({ type: PATIENTS_END_LOADING });
  } catch (error) {
    console.log(error);
  }
};

// export const getPatientsByDoctors = (doctors) => async (dispatch) => {
//   try {
//     dispatch({ type: PATIENTS_LOADING });
//     const { data } = await api.fetchPatientsByDoctors(doctors);
//     dispatch({ type: GET_PATIENTS_BY_DOCTORS, payload: data });
//     dispatch({ type: PATIENTS_END_LOADING });
//   } catch (error) {
//     console.log(error);
//   }
// };

export const getPatients = () => async (dispatch) => {
  try {
    dispatch({ type: PATIENTS_LOADING });
    dispatch({ type: PATIENTS_END_LOADING });

    const { data } = await api.fetchPatients();
    dispatch({ type: GET_PATIENTS, payload: data });
  } catch (error) {
    console.log(error);
  }
};
export const getChatsByPatient = () => async (dispatch) => {
  try {
    dispatch({ type: PATIENTS_LOADING });
    const { data } = await api.fetchChatsByPatient();
    dispatch({ type: GET_PATIENTS_CHAT, payload: data });
    dispatch({ type: PATIENTS_END_LOADING });
  } catch (error) {
    console.log(error);
  }
};
export const filterPatients = (filters) => async (dispatch) => {
  try {
    dispatch({ type: PATIENTS_LOADING });
    const { data, headers } = await api.filterPatients(filters);
    dispatch({
      type: FILTER_PATIENTS,
      payload: { data, numberOfPages: +headers["x-pagination-count"] },
    });
    dispatch({ type: PATIENTS_END_LOADING });
  } catch (error) {
    console.log(error);
  }
};

export const createPatient = (patient, history) => async (dispatch) => {
  try {
    dispatch({ type: PATIENTS_LOADING });
    const { data } = await api.createPatient(patient);
    dispatch({ type: CREATE_PATIENT, payload: data });
    dispatch({ type: PATIENTS_END_LOADING });
  } catch (error) {
    console.log(error);
  }
};

export const editPatient = (id, patient) => async (dispatch) => {
  try {
    dispatch({ type: PATIENTS_LOADING });
    const { data } = await api.editPatient(id, patient);
    dispatch({ type: EDIT_PATIENT, payload: data });
    dispatch({ type: PATIENTS_END_LOADING });
  } catch (error) {
    console.log(error);
  }
};

export const deletePatient = (id) => async (dispatch) => {
  try {
    await api.deletePatient(id);
    dispatch({ type: DELETE_PATIENT, payload: id });
  } catch (error) {
    console.log(error);
  }
};

export const blockPatient = (id, blacklist) => async (dispatch) => {
  try {
    dispatch({ type: PATIENTS_LOADING });
    const { data } = await api.blockPatient(id, blacklist);
    dispatch({ type: BLOCK_PATIENT, payload: data });
    dispatch({ type: PATIENTS_END_LOADING });
  } catch (error) {
    console.log(error);
  }
};
