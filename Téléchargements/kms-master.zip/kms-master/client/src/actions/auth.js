import { AUTH, AUTH_ERROR, AUTH_LOADING } from '../constants/actionTypes';
import * as api from '../api/index.js';

export const signin = (formData, router) => async (dispatch) => {
  try {
    dispatch({ type: AUTH_LOADING });
    const { data } = await api.signIn(formData);
    dispatch({ type: AUTH, payload: data });
    router.push('/c/dashboard');
  } catch (error) {
    dispatch({ type: AUTH_ERROR, payload: error });
  }
};

export const signup = (formData, router) => async (dispatch) => {
  try {
    dispatch({ type: AUTH_LOADING });
    const { data } = await api.signUp(formData);
    dispatch({ type: AUTH, payload: data });
    router.push('/c/dashboard');
  } catch (error) {
    dispatch({ type: AUTH_ERROR, payload: error });
  }
};
