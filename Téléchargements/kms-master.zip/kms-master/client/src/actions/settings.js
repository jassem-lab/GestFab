import * as api from '../api/index.js';
import { CREATE_SETTING, DELETE_SETTING, GET_SETTINGS, SEED_SETTINGS, SETTINGS_END_LOADING, SETTINGS_LOADING, UPDATE_SETTING } from '../constants/actionTypes.js';

export const getSettings = (id) => async (dispatch) => {
    try {
      dispatch({ type: SETTINGS_LOADING });
      const { data } = await api.fetchSettings(id);
      dispatch({ type: GET_SETTINGS, payload: data });
      dispatch({ type: SETTINGS_END_LOADING });
    } catch (error) {
      console.log(error);
    }
};

export const seedSettings = () => async (dispatch) => {
    try {
      dispatch({ type: SETTINGS_LOADING });
      const { data } = await api.seedSettings();
      dispatch({ type: SEED_SETTINGS, payload: data });
      dispatch({ type: SETTINGS_END_LOADING });
    } catch (error) {
      console.log(error);
    }
};

export const createSetting = (formData) => async (dispatch) => {
    try {
      dispatch({ type: SETTINGS_LOADING });
      const { data } = await api.createSetting(formData);
      dispatch({ type: CREATE_SETTING, payload: data });
      dispatch({ type: SETTINGS_END_LOADING });
    } catch (error) {
      console.log(error);
    }
};

export const updateSetting = (formData) => async (dispatch) => {
    try {
      dispatch({ type: SETTINGS_LOADING });
      const { data } = await api.updateSetting(formData);
      dispatch({ type: UPDATE_SETTING, payload: data });
      dispatch({ type: SETTINGS_END_LOADING });
    } catch (error) {
      console.log(error);
    }
};

  export const deleteChat = (id) => async (dispatch) => {
    try {
      await api.deleteChat(id);
      dispatch({ type: DELETE_SETTING, payload: id });
    } catch (error) {
      console.log(error);
    }
  };
