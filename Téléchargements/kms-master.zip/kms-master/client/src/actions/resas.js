import * as api from '../api/index.js';
import { RESA_LOADING, RESA_END_LOADING, GET_RESA, GET_RESAS_BY_AGENDAS, GET_RESAS, CREATE_RESA, EDIT_RESA, DELETE_RESA, GET_RESAS_BY_DOCTORID, CHANGE_STATUS_RESA, GET_RESAS_BY_MONTH, GET_RESAS_BY_ETABLISSEMENTID } from "../constants/actionTypes";

export const getResa = (id) => async (dispatch) => {
  try {
    dispatch({ type: RESA_LOADING });
    const { data: { data } } = await api.fetchResa(id);
    dispatch({ type: GET_RESA, payload: { data } });
    dispatch({ type: RESA_END_LOADING });
  } catch (error) {
    console.log(error);
  }
};

export const getResasByMonth = (month) => async (dispatch) => {
  try {
    dispatch({ type: RESA_LOADING });
    const { data } = await api.fetchResasByMonth(month);
    dispatch({ type: GET_RESAS_BY_MONTH, payload: data });
    dispatch({ type: RESA_END_LOADING });
  } catch (error) {
    console.log(error);
  }
};

export const getResasByAgendas = (agendas) => async (dispatch) => {
  try {
    dispatch({ type: RESA_LOADING });
    const { data } = await api.fetchResasByAgendas(agendas);
    dispatch({ type: GET_RESAS_BY_AGENDAS, payload: data });
    dispatch({ type: RESA_END_LOADING });
  } catch (error) {
    console.log(error);
  }
};

export const getResasByDoctorId = (id) => async (dispatch) => {
    try {
      dispatch({ type: RESA_LOADING });
      const { data } = await api.fetchResasByDoctorId(id);
      dispatch({ type: GET_RESAS_BY_DOCTORID, payload: data });
      dispatch({ type: RESA_END_LOADING });
    } catch (error) {
      console.log(error);
    }
};

// getResasByEtablissementId

export const getResasByEtablissementId = (id) => async (dispatch) => {
  try {
    dispatch({ type: RESA_LOADING });
    const { data } = await api.fetchResasByEtablissementId(id);
    dispatch({ type: GET_RESAS_BY_ETABLISSEMENTID, payload: data });
    dispatch({ type: RESA_END_LOADING });
  } catch (error) {
    console.log(error);
  }
};

export const getResas = () => async (dispatch) => {
    try {
      dispatch({ type: RESA_LOADING });
      const { data } = await api.fetchResas();
      dispatch({ type: GET_RESAS, payload: data });
      dispatch({ type: RESA_END_LOADING });
    } catch (error) {
      console.log(error);
    }
  };

export const createResa = (resa) => async (dispatch) => {
  try {
    const { data } = await api.createResa(resa);
    dispatch({ type: CREATE_RESA, payload: data });
  } catch (error) {
    console.log(error);
  }
};

export const editResa = (id, resa) => async (dispatch) => {
  try {
    const { data } = await api.editResa(id, resa);
    dispatch({ type: EDIT_RESA, payload: data });
  } catch (error) {
    console.log(error);
  }
};

export const deleteResa = (id) => async (dispatch) => {
  try {
    await api.deleteResa(id);
    dispatch({ type: DELETE_RESA, payload: id });
  } catch (error) {
    console.log(error);
  }
};

export const resaChangeStatus = (id, status) => async (dispatch) => {
  try {
    await api.changeStatusResa(id, status);
    dispatch({ type: CHANGE_STATUS_RESA, payload: id });
  } catch (error) {
    console.log(error);
  }
};