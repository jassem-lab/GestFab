import { FETCH_ALL, FETCH_POST, CREATE, UPDATE, DELETE, LIKE, COMMENT, START_LOADING_POST, END_LOADING_POST, PUBLIC_WAITING, TOP_POST, WAITING_POSTS, ONE_POST_LOADING, ONE_POST_END_LOADING, PUBLIC_POSTS } from '../constants/actionTypes';
import * as api from '../api/index.js';

export const getPost = (id) => async (dispatch) => {
  try {
    dispatch({ type: ONE_POST_LOADING });
    const { data: { data } } = await api.fetchPost(id);
    dispatch({ type: FETCH_POST, payload: { data } });
    dispatch({ type: ONE_POST_END_LOADING });
  } catch (error) {
    console.log(error);
  }
};

export const getPosts = () => async (dispatch) => {
  try {
    dispatch({ type: START_LOADING_POST });
    const { data: { data } } = await api.fetchPosts();
    dispatch({ type: FETCH_ALL, payload: { data } });
    dispatch({ type: END_LOADING_POST });
  } catch (error) {
    console.log(error);
  }
};

export const getWaitingPosts = () => async (dispatch) => {
  try {
    dispatch({ type: START_LOADING_POST });
    const { data: { data } } = await api.fetchWaitingPosts();
    dispatch({ type: WAITING_POSTS, payload: { data } });
    dispatch({ type: END_LOADING_POST });
  } catch (error) {
    console.log(error);
  }
};

export const getPublicPosts = () => async (dispatch) => {
  try {
    dispatch({ type: START_LOADING_POST });
    const { data: { data } } = await api.fetchPublicPosts();
    dispatch({ type: PUBLIC_POSTS, payload: { data } });
    dispatch({ type: END_LOADING_POST });
  } catch (error) {
    console.log(error);
  }
};

export const createPost = (post, history) => async (dispatch) => {
  try {
    dispatch({ type: START_LOADING_POST });
    const { data } = await api.createPost(post);
    dispatch({ type: CREATE, payload: data });
    dispatch({ type: END_LOADING_POST });
  } catch (error) {
    console.log(error);
  }
};

export const updatePost = (id, post) => async (dispatch) => {
  try {
    dispatch({ type: START_LOADING_POST });
    const { data } = await api.updatePost(id, post);
    dispatch({ type: UPDATE, payload: data });
    dispatch({ type: END_LOADING_POST });
  } catch (error) {
    console.log(error);
  }
};

export const likePost = (id) => async (dispatch) => {
  const user = JSON.parse(localStorage.getItem('profile'));
  try {
    const { data } = await api.likePost(id, user?.token);
    dispatch({ type: LIKE, payload: data });
  } catch (error) {
    console.log(error);
  }
};

export const commentPost = (value, id) => async (dispatch) => {
  try {
    const { data } = await api.comment(value, id);
    dispatch({ type: COMMENT, payload: data });
    return data.comments;
  } catch (error) {
    console.log(error);
  }
};

export const deletePost = (id) => async (dispatch) => {
  try {
    await api.deletePost(id);
    dispatch({ type: DELETE, payload: id });
  } catch (error) {
    console.log(error);
  }
};

export const publicWaiting = (id, formData) => async (dispatch) => {
  try {
    dispatch({ type: START_LOADING_POST });
    const { data } = await api.publicWaiting(id, formData);
    dispatch({ type: PUBLIC_WAITING, payload: data });
    dispatch({ type: END_LOADING_POST });
  } catch (error) {
    console.log(error);
  }
};

export const topSwitch = (id, formData) => async (dispatch) => {
  try {
    dispatch({ type: START_LOADING_POST });
    const { data } = await api.topSwitch(id, formData);
    dispatch({ type: TOP_POST, payload: data });
    dispatch({ type: END_LOADING_POST });
  } catch (error) {
    console.log(error);
  }
};


