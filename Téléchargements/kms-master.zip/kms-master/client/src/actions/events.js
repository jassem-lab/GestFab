import { EVENTS_END_LOADING, EVENTS_LOADING, FILTER_EVENTS } from "../constants/actionTypes";
import * as api from '../api/index.js';

export const filterEvents = (filters) => async (dispatch) => {
    try {
        dispatch({type: EVENTS_LOADING});
        const {data, headers} = await api.filterEvents(filters);
        dispatch({type: FILTER_EVENTS, payload: {data, numberOfPages: +headers['x-pagination-count']}});
        dispatch({type: EVENTS_END_LOADING});
    } catch (error) {
        console.log(error);
    }
};