import * as api from '../api/index.js';
import { SMS_END_LOADING, SMS_GET_TOMORROW, SMS_LOADING, SMS_SEND, SMS_LOG } from '../constants/actionTypes.js';

// Send sms
export const smsGetTomorrow = () => async (dispatch) => {
    try {
      dispatch({ type: SMS_LOADING });
      const { data } = await api.getTomorrowApps();
      dispatch({ type: SMS_GET_TOMORROW, payload: data });
      dispatch({ type: SMS_END_LOADING });
    } catch (error) {
      console.log(error);
    }
};

export const sendSms = () => async (dispatch) => {
    try {
        dispatch({ type: SMS_LOADING });
        const { data } = await api.sendSms();
        dispatch({ type: SMS_SEND, payload: data });
        dispatch({ type: SMS_END_LOADING });
    } catch (error) {
        console.log(error);
    }
}
// Sms log
export const smsGetLog = () => async (dispatch) => {
    try {
        dispatch({ type: SMS_LOADING });
        const { data } = await api.smsLog();
        dispatch({ type: SMS_LOG, payload: data });
        dispatch({ type: SMS_END_LOADING });
    } catch (error) {
        console.log(error);
    }
}

  