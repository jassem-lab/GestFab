import React, { useEffect, useState } from "react";
import { CircularProgress, Grid, makeStyles } from "@material-ui/core";
import PropTypes from "prop-types";
import Avatar from "@material-ui/core/Avatar";
import { useDispatch, useSelector } from "react-redux";
import { EditUser, getUser } from "../../../actions/users";
import CloudUploadIcon from "@material-ui/icons/CloudUpload";
import Button from "@material-ui/core/Button";
import TextField from "@material-ui/core/TextField";
import Compress from "compress.js";

const useStyles = makeStyles((theme) => ({
  profileContainer: {
    padding: "40px 60px",
  },
  large: {
    width: theme.spacing(20),
    height: theme.spacing(20),
    margin: "0 auto 20px",
  },
  centerButton: {
    display: "flex",
    alignItems: "center",
    margin: "0 auto",
  },
  inputs: {
    display: "block",
    width: "50%",
    marginBottom: theme.spacing(4),
    "& input": {
      width: "100%",
      minWidth: "280px",
    },
  },
  button: {
    marginTop: theme.spacing(4),
    marginBottom: theme.spacing(4),
    width: "48%",
    background: "#31b929de",
    color: "#fff",
    transition: "all 0.3s ease-in-out",
    padding: "10px 20px",
    textAlign: "center",
    "&:hover": {
      background: "#31b929de",
    },
  },
  loading: {
    marginLeft: "10px",
    color: "#fff",
  },
  btnIcon: {
    display: "inline-block",
    margin: "0 10px 0 0",
  },
}));

function Profile(props) {
  
  const { selectProfile, userID, userEmail } = props;
  const compress = new Compress();
  const classes = useStyles();
  const dispatch = useDispatch();
  const { user, UsersIsLoading } = useSelector((state) => state.users);
  const [profileData, setProfileData] = useState({
    name: "",
    phone: "",
    email: userEmail,
    avatar: null,
  });

  useEffect(selectProfile, [selectProfile]);

  const resizePhotos = async (file) => {
    const resizedImages = await compress.compress([file], {
      size: 2, // the max size in MB, defaults to 2MB
      quality: 1, // the quality of the image, max is 1,
      maxWidth: 250, // the max width of the output image, defaults to 1920px
      maxHeight: 250, // the max height of the output image, defaults to 1920px
      resize: true, // defaults to true, set false if you do not want to resize the image width and height
    });
    const resizedPhoto = resizedImages[0];
    return resizedPhoto;
  };

  const uploadPhotos = (e) => {
    const file = e.target.files[0];
    let photo = "";
    if (file) {
      resizePhotos(file)
        .then((res) => {
          photo = `data:image/${res.ext};base64,${res.data}`;
        })
        .then(() => setProfileData({ ...profileData, avatar: photo }));
    }
  };

  useEffect(() => {
    if (userID) {
      dispatch(getUser(userID));
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [dispatch]);

  useEffect(() => {
    if (user) {
      setProfileData({
        ...profileData,
        name: user.name,
        phone: user.phone,
        avatar: user.avatar,
      });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user]);

  const handleSubmit = (event) => {
    event.preventDefault();
    dispatch(EditUser(userID, profileData));
  };

  return (
    <div className={classes.profileContainer}>
      <Grid container>
        <Grid item xs={12} md={6}>
          <Avatar
            className={classes.large}
            src={
              profileData?.avatar ||
              "https://www.medicskillssb.com/images/instructors/general_male.png"
            }
          />
          <Button
            variant="contained"
            color="default"
            className={classes.centerButton}
            onClick={() =>
              document
                .querySelector("#avatarInputContainer input[type=file]")
                ?.click()
            }
          >
            <CloudUploadIcon style={{ margin: "0 8px 0 0" }} /> Télécharger une
            photo
          </Button>
          <div id="avatarInputContainer" style={{ display: "none" }}>
            <input
              type="file"
              multiple={false}
              onChange={(e) => uploadPhotos(e)}
            />
          </div>
        </Grid>
        <Grid item xs={12} md={6}>
          <form noValidate autoComplete="off">
            <TextField
              id="email-input"
              name="email"
              label="Email"
              defaultValue={userEmail}
              variant="filled"
              InputProps={{ readOnly: true }}
              className={classes.inputs}
            />
            <TextField
              required
              id="name-input"
              name="name"
              label="Nom"
              value={profileData?.name || ""}
              onChange={(e) =>
                setProfileData({ ...profileData, name: e.target.value })
              }
              variant="outlined"
              className={classes.inputs}
            />
            <TextField
              required
              id="phone-input"
              name="phone"
              label="Téléphone"
              value={profileData?.phone || ""}
              onChange={(e) =>
                setProfileData({ ...profileData, phone: e.target.value })
              }
              variant="outlined"
              className={classes.inputs}
            />
            <Button
              fullWidth
              name="save"
              id="save"
              onClick={(e) => handleSubmit(e)}
              className={classes.button}
            >
              Enregistrer
              {UsersIsLoading ? (
                <CircularProgress
                  className={classes.loading}
                  style={{ width: "18px", height: "18px" }}
                />
              ) : null}
            </Button>
          </form>
        </Grid>
      </Grid>
    </div>
  );
}

Profile.propTypes = {
  selectProfile: PropTypes.func,
};

export default Profile;
