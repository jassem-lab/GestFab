import React, {
  Fragment,
  useRef,
  useCallback,
  useState,
  useEffect,
} from "react";
import { Link } from "react-router-dom";
import PropTypes from "prop-types";
import classNames from "classnames";
import DriveEtaIcon from "@mui/icons-material/DriveEta";
import {
  AppBar,
  Toolbar,
  Typography,
  Avatar,
  Drawer,
  List,
  IconButton,
  ListItem,
  ListItemIcon,
  Hidden,
  Tooltip,
  Box,
  makeStyles,
  ButtonBase,
} from "@material-ui/core";
import DashboardIcon from "@material-ui/icons/Dashboard";
import EventIcon from "@material-ui/icons/Event";
import ListIcon from "@material-ui/icons/List";
import ChatIcon from "@material-ui/icons/Chat";
import AssignmentIndIcon from "@material-ui/icons/AssignmentInd";
import FaceIcon from "@material-ui/icons/Face";
import AccountCircleIcon from "@material-ui/icons/AccountCircle";
import PowerSettingsNewIcon from "@material-ui/icons/PowerSettingsNew";
import MenuIcon from "@material-ui/icons/Menu";
import SettingsIcon from "@material-ui/icons/Settings";
import AssignmentIcon from "@material-ui/icons/Assignment";
import SideDrawer from "./SideDrawer";
import NavigationDrawer from "../../../shared/components/NavigationDrawer";
import { LOGOUT } from "../../../constants/actionTypes";
import { useDispatch, useSelector } from "react-redux";
import Badge from "@mui/material/Badge";
import MailIcon from "@mui/icons-material/Mail";
const useStyles = makeStyles((theme) => ({
  appBar: {
    boxShadow: theme.shadows[6],
    backgroundColor: theme.palette.common.white,
    transition: theme.transitions.create(["width", "margin"], {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.leavingScreen,
    }),
    [theme.breakpoints.down("xs")]: {
      width: "100%",
      marginLeft: 0,
    },
  },
  appBarToolbar: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    paddingLeft: theme.spacing(1),
    paddingRight: theme.spacing(1),
    [theme.breakpoints.up("sm")]: {
      paddingLeft: theme.spacing(2),
      paddingRight: theme.spacing(2),
    },
    [theme.breakpoints.up("md")]: {
      paddingLeft: theme.spacing(3),
      paddingRight: theme.spacing(3),
    },
    [theme.breakpoints.up("lg")]: {
      paddingLeft: theme.spacing(4),
      paddingRight: theme.spacing(4),
    },
  },
  accountAvatar: {
    backgroundColor: theme.palette.secondary.main,
    height: 24,
    width: 24,
    marginLeft: theme.spacing(2),
    marginRight: theme.spacing(2),
    [theme.breakpoints.down("xs")]: {
      marginLeft: theme.spacing(1.5),
      marginRight: theme.spacing(1.5),
    },
  },
  drawerPaper: {
    height: "100%vh",
    whiteSpace: "nowrap",
    border: 0,
    width: theme.spacing(7),
    overflowX: "hidden",
    marginTop: theme.spacing(8),
    [theme.breakpoints.up("sm")]: {
      width: theme.spacing(9),
    },
    backgroundColor: theme.palette.common.black,
  },
  smBordered: {
    [theme.breakpoints.down("xs")]: {
      borderRadius: "50% !important",
    },
  },
  menuLink: {
    textDecoration: "none",
    color: theme.palette.text.primary,
  },
  iconListItem: {
    width: "auto",
    borderRadius: theme.shape.borderRadius,
    paddingTop: 11,
    paddingBottom: 11,
    marginLeft: theme.spacing(1),
    marginRight: theme.spacing(1),
  },
  textPrimary: {
    color: theme.palette.primary.main,
  },
  mobileItemSelected: {
    backgroundColor: `${theme.palette.primary.main} !important`,
  },
  brandText: {
    fontFamily: "'Baloo Bhaijaan', cursive",
    fontWeight: 400,
  },
  username: {
    paddingLeft: 0,
    paddingRight: 0,
  },
  justifyCenter: {
    justifyContent: "center",
  },
  permanentDrawerListItem: {
    justifyContent: "center",
    paddingTop: theme.spacing(2),
    paddingBottom: theme.spacing(2),
  },
  select: {
    minWidth: "220px",
    padding: "5px 15px",
    borderRadius: "5px",
    marginRight: theme.spacing(2),
    fontSize: "17px",
    fontWeight: "bold",
  },
  icon: {
    color: "#4829B2",
    fontSize: "35px",
    marginTop: "5px",
  },
}));

function NavBar(props) {
  const { selectedTab, user, etablissements, doctors, settings } = props;
  const classes = useStyles();
  const dispatch = useDispatch();
  const links = useRef([]);
  const [isMobileOpen, setIsMobileOpen] = useState(false);
  const [isSideDrawerOpen, setIsSideDrawerOpen] = useState(false);
  const [etablissementId, setEtablissementId] = useState(null);
  const { patients } = useSelector((state) => state.patients);

  useEffect(() => {
    if (user && user.role === "patient") {
      setEtablissementId(
        etablissements.find(
          (etab) =>
            etab._id ===
            patients?.find((patient) => patient._id === user._id)?.assignedEtab
              ?._id
        )?._id
      );
    } else if (user && user.role === "client") {
      setEtablissementId(
        etablissements.find(
          (etab) =>
            etab._id ===
            doctors?.find((doctor) => doctor.user?._id === user._id)
              ?.etablissement._id
        )?._id
      );
    } else if (localStorage.getItem("etablissement")) {
      setEtablissementId(localStorage.getItem("etablissement"));
    } else if (etablissements && etablissements.length > 0) {
      setEtablissementId(etablissements[0]._id);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [etablissements, doctors, user]);

  const openMobileDrawer = useCallback(() => {
    setIsMobileOpen(true);
  }, [setIsMobileOpen]);

  const closeMobileDrawer = useCallback(() => {
    setIsMobileOpen(false);
  }, [setIsMobileOpen]);

  const openDrawer = useCallback(() => {
    setIsSideDrawerOpen(true);
  }, [setIsSideDrawerOpen]);

  const closeDrawer = useCallback(() => {
    setIsSideDrawerOpen(false);
  }, [setIsSideDrawerOpen]);

  const logout = () => {
    dispatch({ type: LOGOUT });
    props.logout();
    window.location.reload();
  };
  const { chats } = useSelector((state) => state.chats);
  let menuItems = [];
  if (user?.role === "admin") {
    menuItems = [
      {
        link: "/c/dashboard",
        name: "Dashboard",
        onClick: closeMobileDrawer,
        icon: {
          desktop: (
            <DashboardIcon
              className={
                selectedTab === "Dashboard" ? classes.textPrimary : "text-white"
              }
              fontSize="small"
            />
          ),
          mobile: <DashboardIcon className="text-white" />,
        },
      },
      {
        link: "/c/list-rdv",
        name: "Liste R.D.V",
        onClick: closeMobileDrawer,
        icon: {
          desktop: (
            <ListIcon
              className={
                selectedTab === "Appointment"
                  ? classes.textPrimary
                  : "text-white"
              }
              fontSize="small"
            />
          ),
          mobile: <ListIcon className="text-white" />,
        },
      },
      {
        link: "/c/calendar",
        name: "Calendrier",
        onClick: closeMobileDrawer,
        icon: {
          desktop: (
            <EventIcon
              className={
                selectedTab === "Calendar" ? classes.textPrimary : "text-white"
              }
              fontSize="small"
            />
          ),
          mobile: <EventIcon className="text-white" />,
        },
      },

      {
        link: "/c/messenger",
        name: "Messenger",
        onClick: closeMobileDrawer,
        icon: {
          desktop:
            chats.filter((item) => item.seen === false).length > 0 ? (
              <Badge
                badgeContent={
                  chats.filter((item) => item.seen === false).length
                }
                fontSize="small"
                color="primary"
                style={{ zIndex: "3" }}
              >
                <MailIcon
                  className={
                    selectedTab === "Messenger"
                      ? classes.textPrimary
                      : "text-white"
                  }
                  fontSize="small"
                />
              </Badge>
            ) : (
              <Badge badgeContent={0} color="primary" fontSize="small" showZero>
                <MailIcon
                  className={
                    selectedTab === "Messenger"
                      ? classes.textPrimary
                      : "text-white"
                  }
                  fontSize="small"
                />
              </Badge>
            ),
          mobile: <ChatIcon className="text-white" />,
        },
      },

      {
        link: "/c/calendarVAD",
        name: "Calendrier VAD",
        onClick: closeMobileDrawer,
        icon: {
          desktop: (
            <DriveEtaIcon
              className={
                selectedTab === "CalendarVAD"
                  ? classes.textPrimary
                  : "text-white"
              }
              fontSize="small"
            />
          ),
          mobile: <EventIcon className="text-white" />,
        },
      },

      {
        link: "/c/patients",
        name: "Liste Patients",
        onClick: closeMobileDrawer,
        icon: {
          desktop: (
            <AssignmentIndIcon
              className={
                selectedTab === "Patients" ? classes.textPrimary : "text-white"
              }
              fontSize="small"
            />
          ),
          mobile: <AssignmentIndIcon className="text-white" />,
        },
      },
      {
        link: "/c/events",
        name: "Journal d'événements",
        onClick: closeMobileDrawer,
        icon: {
          desktop: (
            <AssignmentIcon
              className={
                selectedTab === "Events" ? classes.textPrimary : "text-white"
              }
              fontSize="small"
            />
          ),
          mobile: <AssignmentIcon className="text-white" />,
        },
      },
      {
        link: "/c/profile",
        name: "Profile",
        onClick: closeMobileDrawer,
        icon: {
          desktop: (
            <AccountCircleIcon
              className={
                selectedTab === "Profile" ? classes.textPrimary : "text-white"
              }
              fontSize="small"
            />
          ),
          mobile: <AccountCircleIcon className="text-white" />,
        },
      },
      {
        link: "/",
        name: "Logout",
        onClick: logout,
        icon: {
          desktop: (
            <PowerSettingsNewIcon className="text-white" fontSize="small" />
          ),
          mobile: <PowerSettingsNewIcon className="text-white" />,
        },
      },
    ];
  } else if (user?.role === "client") {
    menuItems = [
      {
        link: "/c/dashboard",
        name: "Dashboard",
        onClick: closeMobileDrawer,
        icon: {
          desktop: (
            <DashboardIcon
              className={
                selectedTab === "Dashboard" ? classes.textPrimary : "text-white"
              }
              fontSize="small"
            />
          ),
          mobile: <DashboardIcon className="text-white" />,
        },
      },
      {
        link: "/c/calendar",
        name: "Calendrier",
        onClick: closeMobileDrawer,
        icon: {
          desktop: (
            <EventIcon
              className={
                selectedTab === "Calendar" ? classes.textPrimary : "text-white"
              }
              fontSize="small"
            />
          ),
          mobile: <EventIcon className="text-white" />,
        },
      },
      {
        link: "/c/list-rdv",
        name: "Liste R.D.V",
        onClick: closeMobileDrawer,
        icon: {
          desktop: (
            <ListIcon
              className={
                selectedTab === "List" ? classes.textPrimary : "text-white"
              }
              fontSize="small"
            />
          ),
          mobile: <ListIcon className="text-white" />,
        },
      },
      {
        link: "/c/calendarVAD",
        name: "Calendrier VAD",
        onClick: closeMobileDrawer,
        icon: {
          desktop: (
            <DriveEtaIcon
              className={
                selectedTab === "CalendarVAD"
                  ? classes.textPrimary
                  : "text-white"
              }
              fontSize="small"
            />
          ),
          mobile: <EventIcon className="text-white" />,
        },
      },
      {
        link: "/c/messenger",
        name: "Messenger",
        onClick: closeMobileDrawer,
        icon: {
          desktop: (
            <ChatIcon
              className={
                selectedTab === "Messenger" ? classes.textPrimary : "text-white"
              }
              fontSize="small"
            />
          ),
          mobile: <ChatIcon className="text-white" />,
        },
      },
      {
        link: "/c/patients",
        name: "Liste Patients",
        onClick: closeMobileDrawer,
        icon: {
          desktop: (
            <AssignmentIndIcon
              className={
                selectedTab === "Patients" ? classes.textPrimary : "text-white"
              }
              fontSize="small"
            />
          ),
          mobile: <AssignmentIndIcon className="text-white" />,
        },
      },
      {
        link: "/c/events",
        name: "Journal d'événements",
        onClick: closeMobileDrawer,
        icon: {
          desktop: (
            <AssignmentIcon
              className={
                selectedTab === "Events" ? classes.textPrimary : "text-white"
              }
              fontSize="small"
            />
          ),
          mobile: <AssignmentIcon className="text-white" />,
        },
      },
      {
        link: "/c/profile",
        name: "Profile",
        onClick: closeMobileDrawer,
        icon: {
          desktop: (
            <AccountCircleIcon
              className={
                selectedTab === "Profile" ? classes.textPrimary : "text-white"
              }
              fontSize="small"
            />
          ),
          mobile: <AccountCircleIcon className="text-white" />,
        },
      },
      {
        link: "/",
        name: "Logout",
        onClick: logout,
        icon: {
          desktop: (
            <PowerSettingsNewIcon className="text-white" fontSize="small" />
          ),
          mobile: <PowerSettingsNewIcon className="text-white" />,
        },
      },
    ];
  } else if (user?.role === "patient") {
    menuItems = [
      {
        link: "/c/list-rdv",
        name: "Mes rendez-vous",
        onClick: closeMobileDrawer,
        icon: {
          desktop: (
            <ListIcon
              className={
                selectedTab === "List" ? classes.textPrimary : "text-white"
              }
              fontSize="small"
            />
          ),
          mobile: <ListIcon className="text-white" />,
        },
      },
      {
        link: "/c/profile",
        name: "Profile",
        onClick: closeMobileDrawer,
        icon: {
          desktop: (
            <AccountCircleIcon
              className={
                selectedTab === "Profile" ? classes.textPrimary : "text-white"
              }
              fontSize="small"
            />
          ),
          mobile: <AccountCircleIcon className="text-white" />,
        },
      },
      {
        link: "/",
        name: "Logout",
        onClick: logout,
        icon: {
          desktop: (
            <PowerSettingsNewIcon className="text-white" fontSize="small" />
          ),
          mobile: <PowerSettingsNewIcon className="text-white" />,
        },
      },
    ];
  } else {
    menuItems = [
      {
        link: "/",
        name: "Logout",
        onClick: logout,
        icon: {
          desktop: (
            <PowerSettingsNewIcon className="text-white" fontSize="small" />
          ),
          mobile: <PowerSettingsNewIcon className="text-white" />,
        },
      },
    ];
  }

  const handleSelectEtablissement = (event) => {
    event.preventDefault();
    setEtablissementId(event.target.value);
    props.selectEtablissement(event.target.value);
    localStorage.setItem("etablissement", event.target.value);
  };

  return (
    <Fragment>
      <AppBar position="sticky" className={classes.appBar}>
        <Toolbar className={classes.appBarToolbar}>
          <Box display="flex" alignItems="center">
            <Hidden smUp>
              <Box mr={1}>
                <IconButton
                  aria-label="Open Navigation"
                  onClick={openMobileDrawer}
                  color="primary"
                >
                  <MenuIcon />
                </IconButton>
              </Box>
            </Hidden>
            <Hidden xsDown>
              <Link to="/">
                <Typography
                  variant="h4"
                  className={classes.brandText}
                  display="inline"
                  color="primary"
                >
                  Kine
                </Typography>
                <Typography
                  variant="h4"
                  className={classes.brandText}
                  display="inline"
                  color="secondary"
                >
                  Doc
                </Typography>
              </Link>
            </Hidden>
          </Box>
          <Box display="flex" justifyContent="center" alignItems="center">
            <span
              style={{ color: "#333", fontSize: "17px", marginRight: "10px" }}
            >
              Etablissement:{" "}
            </span>
            <select
              disabled={user?.role === "client" || user?.role === "patient"}
              value={etablissementId ? etablissementId : ""}
              onChange={handleSelectEtablissement}
              className={classes.select}
              name="etablissement"
              id="selectetablissement"
            >
              {etablissements?.map((etab) => (
                <option key={etab._id} value={etab._id}>
                  {etab.name}
                </option>
              ))}
            </select>

            {user?.role === "admin" && (
              <Link to="/c/doctors">
                <FaceIcon className={classes.icon} />
              </Link>
            )}
          </Box>
          <Box
            display="flex"
            justifyContent="flex-end"
            alignItems="center"
            className="noprint"
          >
            <ButtonBase>
              <Typography color="textPrimary">{user?.name}</Typography>
              <Avatar
                alt="profile picture"
                src={user?.avatar || "/images/logged_in/profilePicture.jpg"}
                className={classNames(classes.accountAvatar)}
              />
            </ButtonBase>
            {user?.role === "admin" && (
              <IconButton
                onClick={openDrawer}
                color="primary"
                aria-label="Open Sidedrawer"
              >
                <SettingsIcon />
              </IconButton>
            )}
          </Box>
          <SideDrawer
            open={isSideDrawerOpen}
            onClose={closeDrawer}
            settings={settings}
            className="noprint"
          />
        </Toolbar>
      </AppBar>
      <Hidden xsDown className="noprint">
        <Drawer
          variant="permanent"
          classes={{
            paper: classes.drawerPaper,
          }}
          open={false}
        >
          <List>
            {menuItems.map((element, index) => (
              <Link
                to={element.link}
                className={classes.menuLink}
                onClick={element.onClick}
                key={index}
                ref={(node) => {
                  links.current[index] = node;
                }}
              >
                <Tooltip
                  title={element.name}
                  placement="right"
                  key={element.name}
                >
                  <ListItem
                    selected={selectedTab === element.name}
                    button
                    divider={index !== menuItems.length - 1}
                    className={classes.permanentDrawerListItem}
                    onClick={() => {
                      links.current[index].click();
                    }}
                    aria-label={
                      element.name === "Logout"
                        ? "Logout"
                        : `Go to ${element.name}`
                    }
                  >
                    <ListItemIcon className={classes.justifyCenter}>
                      {element.icon.desktop}
                    </ListItemIcon>
                  </ListItem>
                </Tooltip>
              </Link>
            ))}
          </List>
        </Drawer>
      </Hidden>
      <NavigationDrawer
        className="noprint"
        menuItems={menuItems.map((element) => ({
          link: element.link,
          name: element.name,
          icon: element.icon.mobile,
          onClick: element.onClick,
        }))}
        anchor="left"
        open={isMobileOpen}
        selectedItem={selectedTab}
        onClose={closeMobileDrawer}
      />
    </Fragment>
  );
}

NavBar.propTypes = {
  selectedTab: PropTypes.string.isRequired,
};

export default NavBar;
