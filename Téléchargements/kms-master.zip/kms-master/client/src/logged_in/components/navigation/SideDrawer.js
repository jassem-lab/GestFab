import React, { useState } from "react";
import PropTypes from "prop-types";
import {
  Drawer,
  IconButton,
  Toolbar,
  Divider,
  Typography,
  Box,
  withStyles,
} from "@material-ui/core";
import CloseIcon from "@material-ui/icons/Close";
import SmsModal from "../Sms/SmsModal";
import LogModal from "../Sms/LogModal";
import SmsSelect from "../Sms/SmsSelect";

const drawerWidth = 240;

const styles = {
  toolbar: {
    minWidth: drawerWidth,
  },
  seedBtn: {
    width: "100%",
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    padding: "10px 20px",
    borderRadius: "5px",
    marginTop: "10px",
    cursor: "pointer",
    border: "1px solid #eee",
  },
  settingContainer: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: "10px",
  },
  label: {
    width: "40%",
    marginRight: "5%",
  },
  input: {
    width: "55%",
    padding: "5px 20px",
    borderRadius: "5px",
    border: "1px solid #eee",
  },
  saveBtn: {
    width: "100%",
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    padding: "10px 20px",
    backgroundColor: "#3f6611",
    color: "#fff",
    borderRadius: "5px",
    marginTop: "20px",
    cursor: "pointer",
    border: "1px solid #eee",
  },
};

function SideDrawer(props) {
  const { classes, onClose, open } = props;
  const [smsModal, setSmsModal] = useState(false);
  const [logModal, setLogModal] = useState(false);
  const [smsSelect, setSmsSelect] = useState(false);

  return (
    <Drawer anchor="right" open={open} variant="temporary" onClose={onClose}>
      <Toolbar disableGutters className={classes.toolbar}>
        <Box
          pl={3}
          pr={3}
          display="flex"
          justifyContent="space-between"
          width="100%"
          alignItems="center"
        >
          <Typography variant="h6">Paramètres</Typography>
          <IconButton
            onClick={onClose}
            color="primary"
            aria-label="Close Sidedrawer"
          >
            <CloseIcon />
          </IconButton>
        </Box>
      </Toolbar>
      <Divider />
      <Box>
        <button className={classes.seedBtn} onClick={() => setSmsModal(true)}>
          {" "}
          Sms de demain
        </button>
      </Box>
      <Box>
        <button className={classes.seedBtn} onClick={() => setLogModal(true)}>
          {" "}
          Sms Log
        </button>
      </Box>
      <Box>
        <button className={classes.seedBtn} onClick={() => setSmsSelect(true)}>
          {" "}
          Sms Select
        </button>
      </Box>
      <SmsModal open={smsModal} onClose={() => setSmsModal(false)} />
      <LogModal open={logModal} onClose={() => setLogModal(false)} />
      <SmsSelect open={smsSelect} onClose={() => setSmsSelect(false)} />
    </Drawer>
  );
}

SideDrawer.propTypes = {
  classes: PropTypes.object.isRequired,
  open: PropTypes.bool.isRequired,
  onClose: PropTypes.func.isRequired,
};

export default withStyles(styles)(SideDrawer);
