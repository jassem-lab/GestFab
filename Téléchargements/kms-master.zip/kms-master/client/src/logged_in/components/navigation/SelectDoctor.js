import { FormControl, InputLabel, NativeSelect } from "@material-ui/core";
import React, { useEffect, useState } from "react";
import { makeStyles } from "@material-ui/core/styles";
import { flexbox } from "@material-ui/system";
import { useDispatch } from "react-redux";
import { getDoctor } from "../../../actions/doctors";

const useStyles = makeStyles((theme) => ({
  margin: {
    display: flexbox,
    flexDirection: "row",
    margin: theme.spacing(1),
  },
  typography: {
    marginBottom: "60px",
    margin: theme.spacing(1),
    color: "black",
  },
  select: {
    margin: theme.spacing(1),
    width: "200px",
    color: "rgb(72,41,178)",
    fontWeight: "bold",
  },
}));

function SelectDoctor(props) {
  const { doctors } = props;
  const dispatch = useDispatch();
  //   const [doctorID, setDoctorID] = useState("");
  const classes = useStyles();
  const [doctor, setDoctor] = useState("");
  const [doctorInf, setDoctorInf] = useState({});

  const handleChange = (event) => {
    localStorage.setItem("doctorID", event.target.value);
    // var doctorID = localStorage.getItem("doctorID");
    setDoctor(localStorage.getItem("doctorID"));
  };
  // console.log(doctor)

    const getData = () => {
      console.log(doctor);
      dispatch(getDoctor(doctor)).then((res) => {
        setDoctorInf(res);
      });
    };
    
getData();
  return (
    <FormControl variant="outlined" className={classes.margin}>
      <InputLabel htmlFor="selectdoctor" className={classes.typography}>
        Selectionner médecin{" "}
      </InputLabel>
      <NativeSelect
        value={doctor}
        onChange={handleChange}
        className={classes.select}
        inputProps={{
          name: "doctor",
          id: "selectdoctor",
        }}
      >
        <option aria-label="None" value="" />
        {doctors?.map((doctor) => (
          <option key={doctor._id} value={doctor._id}>
            {doctor.user.name}
          </option>
        ))}
        {doctorInf}
      </NativeSelect>
    </FormControl>
  );
}

export default SelectDoctor;
