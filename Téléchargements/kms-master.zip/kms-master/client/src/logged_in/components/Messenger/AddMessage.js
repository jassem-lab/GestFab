import {
  Button,
  Grid,
  TextField,
  Typography,
  makeStyles,
  Paper,
  FormControl,
  IconButton,
  Select,
  MenuItem,
} from "@material-ui/core";
import { useDispatch, useSelector } from "react-redux";
import React, { useEffect, useState } from "react";
import { createChat, editChat } from "../../../actions/chats";
import Autocomplete from "@material-ui/lab/Autocomplete";
import AttachFileIcon from "@material-ui/icons/AttachFile";
import { getAdmins } from "../../../actions/users";
import Compress from "compress.js";
import { relativeTimeRounding } from "moment";

const useStyles = makeStyles((theme) => ({
  formControl: {
    minWidth: 120,
    height: 20,
  },
  saveButton: {
    paddingTop: 10,
  },
  loading: {
    width: "20px",
    marginLeft: "10px",
  },
  attachFileButton: {
    position: "absolute",
    right: "20px",
    bottom: "20px",
  },
  mySelect: {
    marginRight: "10px",
  },
}));

function AddMessage(props) {
  const { connectedUser, doctors, chat } = props;
  const compress = new Compress();
  const { patients } = useSelector((state) => state.patients);
  const [feedback, setFeedback] = useState(null);
  const classes = useStyles();
  const dispatch = useDispatch();
  const { ChatsIsLoading } = useSelector((state) => state.chats);
  const { admins } = useSelector((state) => state.users);
  const [file, setFile] = useState(null);
  const [selectedPatient, setSelectedPatient] = useState(null);

  const [formData, setFormData] = useState({
    from: connectedUser._id,
    to:
      connectedUser.role === "client" ? admins[1]?._id : doctors[0]?.user?._id,
    about: "",
    object: "",
    message: "",
    file: null,
    seen: false,
  });

  const clear = () => {
    setFormData({
      from: connectedUser._id,
      to:
        connectedUser.role === "client"
          ? admins[0]?._id
          : doctors[0]?.user?._id,
      about: "",
      object: "",
      message: "",
      file: null,
      seen: false,
    });
    setSelectedPatient(null);
  };

  useEffect(() => {
    if (chat) {
      setFormData({
        ...formData,
        to: chat.to._id,
        about: patients?.find((pat) => pat._id === chat.about),
        object: chat.object,
        message: chat.message,
        file: chat.file,
        seen: chat.seen,
      });
      setSelectedPatient(patients?.find((pat) => pat._id === chat.about));
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [chat]);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (chat) {
      dispatch(editChat(chat._id, formData)).then(() => {
        setFeedback("Message modifié");
        props.close();
      });
    } else {
      dispatch(createChat(formData)).then(() => {
        setFeedback("Message envoyé");
        clear();
        props.close();
      });
    }
  };

  const resizePhotos = async (file) => {
    const resizedImages = await compress.compress([file], {
      size: 2, // the max size in MB, defaults to 2MB
      quality: 1, // the quality of the image, max is 1,
      maxWidth: 250, // the max width of the output image, defaults to 1920px
      maxHeight: 250, // the max height of the output image, defaults to 1920px
      resize: true, // defaults to true, set false if you do not want to resize the image width and height
    });
    const resizedPhoto = resizedImages[0];
    return resizedPhoto;
  };

  const uploadPhotos = (e) => {
    const file = e.target.files[0];
    let photo = "";
    if (file) {
      resizePhotos(file)
        .then((res) => {
          photo = `data:image/${res.ext};base64,${res.data}`;
        })
        .then(() => {
          setFormData({ ...formData, file: photo });
          setFile(photo);
        });
    }
  };

  useEffect(() => {
    if (connectedUser.role === "client") {
      dispatch(getAdmins());
    }
  }, [connectedUser, dispatch]);

  useEffect(() => {
    if (admins && admins.length > 0) {
      setFormData({ ...formData, to: admins[0]?._id });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [admins]);
  const [textWithNextLine, setTextWithNextLine] = useState("");

  const nextLine = (e) => {
    const changedMessage = e.target.value;
    if ((e.keyCode === 13) === "Enter") {
      let m = changedMessage + "\n ";
      setFormData(formData.messsage, m);
      // return textWithNextLine
    }
  };
  return (
    <form>
      <Grid container spacing={3} className="griditem">
        <Grid item xs={12}>
          <Typography variant="h4" style={{ marginTop: "10px" }}>
            {" "}
            {chat ? "Modification de" : "Nouveau"} Message{" "}
          </Typography>
        </Grid>
        <Grid item xs={12} style={{ display: "flex", alignItems: "center" }}>
          <Typography> Envoyeur : </Typography>
          <TextField
            disabled
            name="to"
            id="to"
            defaultValue={connectedUser.name}
            style={{ marginLeft: "10px" }}
          />
        </Grid>
        <Grid item xs={12} style={{ display: "flex", alignItems: "center" }}>
          <Typography> Destinataire : </Typography>
          {connectedUser.role === "client" ? (
            <Select
              name="to"
              id="to"
              className={classes.mySelect}
              value={formData?.to}
              onChange={(e) =>
                setFormData({ ...formData, to: e?.target?.value })
              }
            >
              {admins?.map((admin) => (
                <MenuItem key={admin._id} value={admin._id}>
                  {admin.name}
                </MenuItem>
              ))}
            </Select>
          ) : (
            <Select
              name="to"
              id="to"
              className={classes.mySelect}
              style={{ marginLeft: "10px" }}
              value={formData?.to}
              onChange={(e) =>
                setFormData({ ...formData, to: e?.target?.value })
              }
            >
              {doctors?.map((doctor) => (
                <MenuItem key={doctor.user?._id} value={doctor.user?._id}>
                  {doctor.user?.name}
                </MenuItem>
              ))}
            </Select>
          )}
        </Grid>

        <Grid item xs={12}>
          <FormControl className={classes.formControl}>
            <Autocomplete
              id="patient-simple-select"
              value={selectedPatient}
              onChange={(e, val) => {
                e.preventDefault();
                setSelectedPatient(val);
                setFormData({ ...formData, about: val?._id });
              }}
              options={patients}
              getOptionLabel={(option) => option?.user?.name}
              style={{ width: 300, marginBottom: "10px" }}
              renderInput={(params) => (
                <TextField
                  {...params}
                  id="patientinput"
                  label="Patient"
                  variant="outlined"
                />
              )}
            ></Autocomplete>
          </FormControl>
        </Grid>
        <Grid item xs={12}>
          <Paper
            style={{
              marginTop: "40px",
              borderColor: "#777",
              borderRadius: "5px",
            }}
          >
            <div
              style={{
                backgroundColor: "#e8e6e638",
                borderRadius: "5px 5px 0px 0px",
              }}
            >
              <TextField
                style={{ margin: "10px", width: "90%" }}
                name="object"
                id="object"
                label="Objet"
                value={formData.object}
                onChange={(e) =>
                  setFormData({ ...formData, object: e.target.value })
                }
              />
            </div>
            <div style={{ position: "relative" }}>
              <div>
                <TextField
                  style={{ margin: "10px", width: "90%" }}
                  multiline
                  rows={6}
                  name="message"
                  id="message"
                  label="Message"
                  value={formData.message}
                  onChange={(e) =>
                    setFormData({ ...formData, message: e.target.value })
                  }
                  onKeyDown={(e) => {
                    nextLine(e);
                  }}
                />
                <span>{file ? file.name : ""}</span>
              </div>
              <IconButton
                className={classes.attachFileButton}
                onClick={() =>
                  document
                    .querySelector("#fileInputContainer input[type=file]")
                    ?.click()
                }
              >
                <AttachFileIcon />
              </IconButton>
              <div id="fileInputContainer" style={{ display: "none" }}>
                <input type="file" onChange={uploadPhotos} />
              </div>
            </div>
          </Paper>
        </Grid>
      </Grid>

      <Button
        style={{ marginTop: "50px", marginRight: "10px" }}
        variant="contained"
        color="secondary"
        type="submit"
        onClick={(e) => handleSubmit(e)}
      >
        Envoyer
        {ChatsIsLoading ? (
          <img
            className={classes.loading}
            src="/images/loading.gif"
            alt="Loading"
          />
        ) : null}
      </Button>
      <Button
        onClick={props.close}
        style={{ marginTop: "50px" }}
        variant="contained"
        color="primary"
      >
        Annuler
      </Button>
      {feedback ? (
        <p style={{ color: "#080", marginTop: "15px" }}>{feedback}</p>
      ) : null}
    </form>
  );
}

export default AddMessage;
