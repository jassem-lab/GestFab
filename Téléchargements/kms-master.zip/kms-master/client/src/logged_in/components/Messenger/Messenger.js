import React, { useEffect, useState } from "react";
import { getChatsByDoctors } from "../../../actions/chats";
import { useDispatch, useSelector } from "react-redux";
import {
  makeStyles,
  CircularProgress,
  TextField,
  IconButton,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogContentText,
  DialogActions,
  Button,
  Select,
  MenuItem,
  TablePagination,
} from "@material-ui/core";
import AddIcon from "@material-ui/icons/Add";
import AddMessage from "./AddMessage";
import moment from "moment";
import { deleteChat, messageSeen } from "../../../actions/chats";
import DeleteForeverIcon from "@material-ui/icons/DeleteForever";
import VisibilityOffIcon from "@material-ui/icons/VisibilityOff";
import ChatTab from "./ChatTab";
import VisibilityIcon from "@material-ui/icons/Visibility";
import EditIcon from "@material-ui/icons/Edit";

const useStyles = makeStyles((theme) => ({
  iconButton: {
    margin: 5,
  },
  paper: {
    flexGrow: 1,
    padding: 30,
  },
  flex: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    padding: "10px 20px",
  },
  loading: {
    minHeight: "100vh",
    minWidth: "100%",
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
  },
  searchBar: {
    minWidth: "250px",
    marginTop: "-16px",
  },
  searchSelect: {
    minWidth: "250px",
    marginRight: "20px",
  },
  doctorMessage: {
    cursor: "pointer",
    transition: "all 0.5s",
    background: "#b2bce1",
  },
  adminMessage: {
    cursor: "pointer",
    transition: "all 0.5s",
    background: "#e6a2ad",
  },
  messageBox: {
    display: "block",
    flexDirection: "column",
    flexWrap: "wrap",
    whiteSpace: "break-spaces !important",
    padding: "8px",
    margin: "5px",
    border: "1px solid rgba(179,179,179, 0.3)",
    borderRadius: "10px",
    background: "rgba(179,179,179, 0.3)",
    width: "250px",
    overflow: "hidden",
    fontSize: "14px",
  },
}));

function Messenger(props) {
  const { selectMessenger, doctorsByEtab, etablissement } = props;
  const [connectedUser] = useState(
    JSON.parse(localStorage.getItem("profile"))?.user
  );
  const { chats, chatsIsLoading, numberOfPages } = useSelector(
    (state) => state.chats
  );

  const { patients } = useSelector((state) => state.patients);
  const dispatch = useDispatch();
  const classes = useStyles();
  const [showAddChat, setShowAddChat] = useState(false);
  const [selectedChat, setSelectedChat] = useState(null);
  const [deleteChatConfirmation, setDeleteChatConfirmation] = useState(false);
  const [chatTabOpen, setChatTabOpen] = useState(false);
  const [filtredChats, setFiltredChats] = useState([]);
  const [search, setSearch] = useState("");
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(20);
  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };
  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };
  const emptyRows =
    rowsPerPage -
    Math.min(rowsPerPage, filtredChats.length - page * rowsPerPage);

  useEffect(selectMessenger, [selectMessenger]);

  useEffect(() => {
    if (doctorsByEtab && doctorsByEtab.length > 0) {
      dispatch(getChatsByDoctors({ doctorsByEtab }));
    }
  }, [dispatch, doctorsByEtab]);

  useEffect(() => {
    if (chats && chats.length > 0) {
      setFiltredChats(chats);
    } else {
      setFiltredChats([]);
    }
  }, [chats]);

  const handleClickOpen = () => {
    setSelectedChat(null);
    setShowAddChat(true);
  };

  const handleClose = () => {
    setShowAddChat(false);
  };

  const handleDeleteChat = () => {
    dispatch(deleteChat(selectedChat._id));
    setDeleteChatConfirmation(false);
  };

  const handleChatTab = (chat) => {
    setSelectedChat(chat);
    setChatTabOpen(true);
  };
  const handleSeenMessage = (chatId) => {
    dispatch(messageSeen(chatId));
  };

  const handleSearch = (e) => {
    setSearch(e.target?.value);
    if (e.target?.value?.length > 0) {
      setFiltredChats(
        chats?.filter((chat) =>
          chat.message.toLowerCase().includes(e.target.value.toLowerCase())
        )
      );
    } else {
      setFiltredChats(chats);
    }
  };

  const handleSearchByDoctor = (e) => {
    if (e.target?.value?.length > 0) {
      setFiltredChats(
        chats?.filter(
          (chat) =>
            chat.to?._id === e.target.value || chat.from?._id === e.target.value
        )
      );
    } else {
      setFiltredChats(chats);
    }
  };
  const Chats = filtredChats?.slice(
    page * rowsPerPage,
    page * rowsPerPage + rowsPerPage
  );
  return (
    <Paper sx={{ width: "100%", overflow: "hidden" }}>
      <div className={classes.flex}>
        {chatsIsLoading ? (
          <div style={{ margin: 5, padding: "12px" }}>
            <CircularProgress size={25} color="primary" />
          </div>
        ) : (
          <IconButton
            color="primary"
            aria-label="add"
            className={classes.iconButton}
            onClick={handleClickOpen}
          >
            <AddIcon />
          </IconButton>
        )}
        <h5 style={{ fontSize: "18px" }}>
          Messagerie de :
          <strong style={{ color: "rgb(72,41,178)" }}>
            &nbsp;{etablissement?.name}
          </strong>
        </h5>
        <div>
          <Select
            name="doctor"
            id="doctor"
            className={classes.searchSelect}
            defaultValue=""
            onChange={(e) => handleSearchByDoctor(e)}
          >
            <MenuItem value="">Tous les docteurs</MenuItem>
            {doctorsByEtab?.map((doctor) => (
              <MenuItem key={doctor._id} value={doctor.user._id}>
                {doctor.user.name}
              </MenuItem>
            ))}
          </Select>
          <TextField
            value={search}
            label="Recherche dans les messages"
            onChange={(e) => handleSearch(e)}
            className={classes.searchBar}
          />
        </div>
      </div>
      <TableContainer sx={{ maxHeight: 440 }}>
        <Table sx={{ minWidth: 650 }} aria-label="simple table">
          <TableHead>
            <TableRow>
              <TableCell align="left">Date</TableCell>
              <TableCell align="left">Heure</TableCell>
              <TableCell align="left">De</TableCell>
              <TableCell align="left">A</TableCell>
              <TableCell align="left">Patient</TableCell>
              <TableCell align="left">Telephone</TableCell>
              <TableCell align="left">Objet</TableCell>
              <TableCell align="left">Message</TableCell>
              <TableCell align="left">Lu</TableCell>
              <TableCell align="left">Actions</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {Chats.map((chat) => (
              <TableRow
                key={chat._id}
                className={
                  chat.from?.role === "client"
                    ? classes.doctorMessage
                    : classes.adminMessage
                }
                style={!chat.seen ? { opacity: "1" } : { opacity: "0.7" }}
                sx={{ "&:last-child td, &:last-child th": { border: 0 } }}
                onClick={() => {
                  setSelectedChat(chat);
                  handleChatTab(chat);
                  chat?.to?._id === connectedUser._id &&
                    handleSeenMessage(chat._id);
                }}
              >
                <TableCell align="left">
                  {moment(chat.createdAt).format("DD/MM/YYYY")}
                </TableCell>
                <TableCell align="left">
                  {moment(chat.createdAt).format("HH:mm")}
                </TableCell>
                <TableCell align="left">{chat.from?.name}</TableCell>
                <TableCell align="left">{chat.to?.name}</TableCell>
                <TableCell align="left">
                  {patients?.find((pat) => pat._id === chat.about)?.user?.name}
                </TableCell>
                <TableCell align="left">
                  {patients?.find((pat) => pat._id === chat.about)?.user
                    ?.phone ||
                    patients.find((pat) => pat._id === chat?.about)?.fixeNumber}
                </TableCell>
                <TableCell align="left">{chat.object}</TableCell>
                <TableCell align="left">
                  <span className={classes.messageBox}>{chat.message}</span>
                </TableCell>
                <TableCell align="left">
                  {chat.seen ? (
                    <VisibilityIcon color="secondary" />
                  ) : (
                    <VisibilityOffIcon />
                  )}
                </TableCell>
                <TableCell align="left">
                  {!chat.seen && chat.from?._id === connectedUser._id ? (
                    <EditIcon
                      style={{ color: "#1bb719", cursor: "pointer" }}
                      onClick={(e) => {
                        e.preventDefault();
                        e.stopPropagation();
                        setSelectedChat(chat);
                        setShowAddChat(true);
                      }}
                    />
                  ) : null}
                  <DeleteForeverIcon
                    style={{ color: "#b54827", cursor: "pointer" }}
                    onClick={(e) => {
                      e.preventDefault();
                      e.stopPropagation();
                      setSelectedChat(chat);
                      setDeleteChatConfirmation(true);
                    }}
                  />
                </TableCell>
              </TableRow>
            ))}
            {emptyRows > 0 && (
              <TableRow style={{ height: 53 * emptyRows }}>
                <TableCell colSpan={6} />
              </TableRow>
            )}
          </TableBody>
        </Table>
      </TableContainer>
      <TablePagination
        rowsPerPageOptions={[5, 10, 25]}
        component="div"
        count={filtredChats.length}
        rowsPerPage={rowsPerPage}
        page={page}
        onChangePage={handleChangePage}
        onChangeRowsPerPage={handleChangeRowsPerPage}
      />
      <Dialog
        open={showAddChat}
        onClose={() => setShowAddChat(false)}
        aria-labelledby="form-dialog-title"
      >
        <Paper className={classes.paper}>
          <AddMessage
            chat={selectedChat}
            connectedUser={connectedUser}
            doctors={doctorsByEtab}
            show={showAddChat}
            close={handleClose}
          />
        </Paper>
      </Dialog>
      <Dialog
        open={deleteChatConfirmation}
        onClose={() => setDeleteChatConfirmation(false)}
        aria-labelledby="chat-title"
        aria-describedby="chat-description"
      >
        <DialogTitle id="chat-title">{"Supprimer ce message ?"}</DialogTitle>
        <DialogContent>
          <DialogContentText id="chat-description">
            Êtes-vous sûr de supprimer ce message ?
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button
            onClick={() => setDeleteChatConfirmation(false)}
            color="primary"
          >
            Annuler
          </Button>
          <Button onClick={handleDeleteChat} color="primary" autoFocus>
            Supprimer
          </Button>
        </DialogActions>
      </Dialog>
      <ChatTab
        showMe={chatTabOpen}
        chat={selectedChat}
        chats={chats}
        closeMe={() => setChatTabOpen(false)}
      />
    </Paper>
  );
}

export default Messenger;
