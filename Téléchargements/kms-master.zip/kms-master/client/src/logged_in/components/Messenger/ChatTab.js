import {
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  DialogContentText,
  DialogTitle,
  makeStyles,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Typography,
} from "@material-ui/core";
import React, { useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import moment from "moment";
import DeleteForeverIcon from "@material-ui/icons/DeleteForever";
import { deleteChat } from "../../../actions/chats";
import ForumIcon from "@material-ui/icons/Forum";
import MessengerViewMode from "./MessengerViewMode";

const useStyles = makeStyles((theme) => ({
  row: {
    cursor: "pointer",
    transition: "all 0.3s ease-in-out",
    "&:hover": {
      backgroundColor: "#f5f5f5",
    },
  },
  seen: {
    cursor: "pointer",
    transition: "all 0.3s ease-in-out",
    backgroundColor: "#CCC",
    "&:hover": {
      backgroundColor: "#f5f5f5",
    },
  },
  tabHeader: {
    backgroundColor: "#b3294e",
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    padding: "0 2rem 1rem",
  },
  displayRows: {
    cursor: "pointer",
    fontSize: "2rem",
    color: "#fff",
    transition: "all 0.3s ease-in-out",
    "&:hover": {
      color: "#CCC",
    },
  },
  displayMessenger: {
    cursor: "pointer",
    fontSize: "2rem",
    color: "#080",
    transition: "all 0.3s ease-in-out",
    "&:hover": {
      color: "#CCC",
    },
  },
  doctorMessage: {
    cursor: "pointer",
    transition: "all 0.5s",
    background: "#b2bce1",
  },
  adminMessage: {
    cursor: "pointer",
    transition: "all 0.5s",
    background: "#e6a2ad",
  },
}));

function ChatTab(props) {
  const { showMe, chat, chats } = props;
  const classes = useStyles();
  const dispatch = useDispatch();
  const [selectedChat, setSelectedChat] = useState(null);
  const [deleteChatConfirmation, setDeleteChatConfirmation] = useState(false);
  const [displayRows, setDisplayRows] = useState(true);
  const { patients } = useSelector((state) => state.patients);

  const handleDeleteChat = () => {
    dispatch(deleteChat(selectedChat._id));
    setDeleteChatConfirmation(false);
  };

  if (!showMe || !chat) return null;

  return (
    <Dialog
      maxWidth="sm"
      open={showMe}
      onClose={props.closeMe}
      aria-labelledby="form-dialog-title"
    >
      <div>
        <div className={classes.tabHeader}>
          <div>
            <Typography style={{ marginTop: "30px", color: "#fff" }}>
              Messagerie
            </Typography>
            <Typography
              variant="h4"
              style={{ marginBottom: "10px", color: "#fff" }}
            >
              {patients?.find((pat) => pat._id === chat.about)?.user?.name}
            </Typography>
          </div>
          <ForumIcon
            className={
              displayRows ? classes.displayRows : classes.displayMessenger
            }
            onClick={() => setDisplayRows(!displayRows)}
          />
        </div>
      </div>
      <DialogActions style={{ display: "flex", flexDirection: "column" }}>
        <DialogContent
          style={{ display: "flex", flexDirection: "column", width: "100%" }}
        >
          {displayRows ? (
            <TableContainer sx={{ maxHeight: 440 }}>
              <Table
                stickyHeader
                sx={{ minWidth: 650 }}
                aria-label="simple table"
              >
                <TableHead>
                  <TableRow>
                    <TableCell align="left">Date</TableCell>
                    <TableCell align="left">Heure</TableCell>
                    <TableCell align="left">De</TableCell>
                    <TableCell align="left">A</TableCell>
                    <TableCell align="left">Objet</TableCell>
                    <TableCell align="left">Message</TableCell>
                    <TableCell align="left">Actions</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {chats
                    ?.filter((c) => c.about === chat?.about)
                    ?.map((chat) => (
                      <TableRow
                        key={chat._id}
                        className={
                          chat.from?.role === "client"
                            ? classes.doctorMessage
                            : classes.adminMessage
                        }
                        style={
                          !chat.seen ? { opacity: "1" } : { opacity: "0.7" }
                        }
                        sx={{
                          "&:last-child td, &:last-child th": { border: 0 },
                        }}
                      >
                        <TableCell align="left">
                          {moment(chat.createdAt).format("DD/MM/YYYY")}
                        </TableCell>
                        <TableCell align="left">
                          {moment(chat.createdAt).format("HH:mm")}
                        </TableCell>
                        <TableCell align="left">{chat.from?.name}</TableCell>
                        <TableCell align="left">{chat.to?.name}</TableCell>
                        <TableCell align="left">{chat.object}</TableCell>
                        <TableCell className="ViewModeChat" align="left">
                          {chat.message}
                        </TableCell>
                        <TableCell align="left">
                          <DeleteForeverIcon
                            onClick={(e) => {
                              e.stopPropagation();
                              setSelectedChat(chat);
                              setDeleteChatConfirmation(true);
                            }}
                            style={{ color: "#b54827", cursor: "pointer" }}
                          />
                        </TableCell>
                      </TableRow>
                    ))}
                </TableBody>
              </Table>
            </TableContainer>
          ) : (
            <MessengerViewMode chats={chats} to={chat.to} about={chat.about} />
          )}
        </DialogContent>
        <Button onClick={props.closeMe} color="primary">
          Cancel
        </Button>
      </DialogActions>
      <Dialog
        open={deleteChatConfirmation}
        onClose={() => setDeleteChatConfirmation(false)}
        aria-labelledby="chat-title"
        aria-describedby="chat-description"
      >
        <DialogTitle id="chat-title">{"Supprimer ce message ?"}</DialogTitle>
        <DialogContent>
          <DialogContentText id="chat-description">
            Êtes-vous sûr de supprimer ce message ?
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button
            onClick={() => setDeleteChatConfirmation(false)}
            color="primary"
          >
            Annuler
          </Button>
          <Button onClick={handleDeleteChat} color="primary" autoFocus>
            Supprimer
          </Button>
        </DialogActions>
      </Dialog>
    </Dialog>
  );
}

export default ChatTab;
