import {
  Paper,
  Typography,
  IconButton,
  makeStyles,
  TextField,
  Dialog,
  DialogTitle,
  DialogContentText,
  DialogActions,
  Button,
  DialogContent,
} from "@material-ui/core";
import React, { useEffect, useState } from "react";
import AccountCircleIcon from "@material-ui/icons/AccountCircle";
import moment from "moment";
import { useDispatch } from "react-redux";
import AttachFileIcon from "@material-ui/icons/AttachFile";
import SendIcon from "@material-ui/icons/Send";
import DeleteForeverIcon from "@material-ui/icons/DeleteForever";
import { deleteChat } from "../../../actions/chats";
import FaceIcon from "@material-ui/icons/Face";
import { createChat } from "../../../actions/chats";
import Compress from "compress.js";

const useStyles = makeStyles((theme) => ({
  chatContainerRight: {
    display: "flex",
    justifyContent: "flex-end",
    // flexDirection: "column-reverse",
    alignItems: "flex-end",
  },
  chatContainerLeft: {
    display: "flex",
    justifyContent: "flex-start",
    // flexDirection: "column-reverse",
    alignItems: "flex-end",
  },
  chatPaperRight: {
    position: "relative",
    borderRadius: "20px 20px 0px 20px",
    width: "65%",
    padding: "10px",
    margin: "5px",
    marginBottom: "22px",
    transition: "all 0.5s",
    background: "rgb(44 178 219 / 17%)",
    "&:hover": {
      background: "rgb(44 178 219 / 30%)",
    },
  },
  chatPaperLeft: {
    position: "relative",
    borderRadius: "20px 20px 20px 0px",
    width: "65%",
    padding: "10px",
    margin: "5px",
    marginBottom: "22px",
    transition: "all 0.5s",
    background: "rgb(207 96 146 / 17%)",
    "&:hover": {
      background: "rgb(207 96 146 / 30%)",
    },
  },
  chatDateRight: {
    position: "absolute",
    color: "#737272",
    bottom: "-35px",
    right: "8px",
  },
  chatDateLeft: {
    position: "absolute",
    color: "#737272",
    bottom: "-35px",
    left: "8px",
  },
  chatSeenRight: {
    position: "absolute",
    color: "#737272",
    bottom: "-35px",
    left: "8px",
  },
  chatSeenLeft: {
    position: "absolute",
    color: "#737272",
    bottom: "-35px",
    right: "8px",
  },
  objectStyle: {
    fontSize: "10px",
  },
  topBarMessage: {
    display: "flex",
    flexDirection: "row",
    justifyContent: "space-between",
  },
  paperContainer: {},
  chatTopBar: {
    display: "flex",
    flexDirection: "row",
    backgroundColor: "#f0f0f0",
    padding: "5px",
  },
}));

function MessengerViewMode(props) {
  const compress = new Compress();
  const { chats, to, about } = props;
  const classes = useStyles();
  const user = JSON.parse(localStorage.getItem("profile"))?.user;
  const [file, setFile] = useState(null);
  const [selectedChat, setSelectedChat] = useState(null);
  const [deleteChatConfirmation, setDeleteChatConfirmation] = useState(false);
  const dispatch = useDispatch();
  const [feedback, setFeedback] = useState(null);
  const [filtredChats, setFiltredChats] = useState([]);

  const [formData, setFormData] = useState({
    from: user?._id,
    to: to?._id,
    about: about,
    object: "",
    message: "",
    file: null,
    seen: false,
  });

  const clear = () => {
    setFormData({
      from: user?._id,
      to: to?._id,
      about: about,
      object: "",
      message: "",
      file: null,
      seen: false,
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    dispatch(createChat(formData)).then(() => {
      setFeedback("Message envoyé");
      clear();
    });
  };

  const handleDeleteChat = () => {
    dispatch(deleteChat(selectedChat._id));
    setDeleteChatConfirmation(false);
  };

  const resizePhotos = async (file) => {
    const resizedImages = await compress.compress([file], {
      size: 2, // the max size in MB, defaults to 2MB
      quality: 1, // the quality of the image, max is 1,
      maxWidth: 250, // the max width of the output image, defaults to 1920px
      maxHeight: 250, // the max height of the output image, defaults to 1920px
      resize: true, // defaults to true, set false if you do not want to resize the image width and height
    });
    const resizedPhoto = resizedImages[0];
    return resizedPhoto;
  };

  const uploadPhotos = (e) => {
    const file = e.target.files[0];
    let photo = "";
    if (file) {
      resizePhotos(file)
        .then((res) => {
          photo = `data:image/${res.ext};base64,${res.data}`;
        })
        .then(() => {
          setFormData({ ...formData, file: photo });
          setFile(photo);
        });
    }
  };

  useEffect(() => {
    let timer1 = setTimeout(() => setFeedback(null), 2000);
    return () => {
      clearTimeout(timer1);
    };
  }, [feedback]);
const chats_reversed = chats.slice(0).reverse()
  return (
    <div>
      <Paper className={classes.paperContainer}>
        <div>
          <div className={classes.chatTopBar}>
            <FaceIcon color="primary" />
            <Typography color="primary" style={{ marginLeft: "5px" }}>
              {" "}
              {to?.user?.name}{" "}
            </Typography>
          </div>
          {chats_reversed
            ?.filter((c) => c.about === about)
            .map((chat) =>
              chat.from?.role === "client" ? (
                <div key={chat._id} className={classes.chatContainerRight}>
                  <Paper className={classes.chatPaperRight}>
                    <div className={classes.topBarMessage}>
                      <p className={classes.objectStyle}> {chat.object} </p>
                      <IconButton
                        size="small"
                        onClick={(e) => {
                          setSelectedChat(chat);
                          setDeleteChatConfirmation(true);
                        }}
                        style={{ color: "#b54827", cursor: "pointer" }}
                      >
                        <DeleteForeverIcon fontSize="small" />
                      </IconButton>
                    </div>
                    <Typography> {chat.message} </Typography>
                    <p className={classes.chatDateRight}>
                      {moment(chat.createdAt).format("DD/MM/YYYY HH:mm")}{" "}
                    </p>
                    <p className={classes.chatSeenRight}>
                      {" "}
                      {chat.seen ? "vu" : " "}{" "}
                    </p>
                  </Paper>
                  <FaceIcon style={{ fontSize: "40px" }} />
                </div>
              ) : (
                <div key={chat._id} className={classes.chatContainerLeft}>
                  <AccountCircleIcon style={{ fontSize: "40px" }} />
                  <Paper className={classes.chatPaperLeft}>
                    <div className={classes.topBarMessage}>
                      <IconButton
                        size="small"
                        onClick={(e) => {
                          setSelectedChat(chat);
                          setDeleteChatConfirmation(true);
                        }}
                        style={{ color: "#b54827", cursor: "pointer" }}
                      >
                        <DeleteForeverIcon fontSize="small" />
                      </IconButton>
                      <p className={classes.objectStyle}> {chat.object} </p>
                    </div>
                    <p
                      className="ViewModeChat"
                      style={{
                        whiteSpace: "break-spaces !important",
                        display: "flex !important",
                        flexDirection: "column",
                        flexWrap: "wrap",
                      }}
                    >
                      {chat.message}
                    </p>
                    <span>{file ? file.name : ""}</span>
                    <p className={classes.chatDateLeft}>
                      {moment(chat.createdAt).format("DD/MM/YYYY HH:mm")}{" "}
                    </p>
                    <p className={classes.chatSeenLeft}>
                      {" "}
                      {chat.seen ? "vu" : " "}{" "}
                    </p>
                  </Paper>
                </div>
              )
            )}
        </div>
        <Paper
          style={{
            marginTop: "40px",
            borderColor: "#777",
            borderRadius: "5px",
          }}
        >
          <div
            style={{
              backgroundColor: "#e8e6e6",
              borderRadius: "5px 5px 0px 0px",
            }}
          >
            <TextField
              style={{ marginLeft: "10px", marginBottom: "10px", width: "50%" }}
              name="object"
              id="object"
              label="Objet"
              value={formData.object}
              onChange={(e) =>
                setFormData({ ...formData, object: e.target.value })
              }
            />
          </div>
          <div
            style={{
              display: "flex",
              alignItems: "flex-end",
              justifyContent: "space-between",
            }}
          >
            <div>
              <TextField
                style={{ margin: "10px", width: "200%" }}
                multiline
                rows={3}
                name="message"
                id="message"
                label="Message"
                value={formData.message}
                onChange={(e) =>
                  setFormData({ ...formData, message: e.target.value })
                }
              />
              <span>{file ? file.name : ""}</span>
            </div>
            <div>
              <IconButton
                style={{ margin: "5px" }}
                size="small"
                onClick={() =>
                  document
                    .querySelector("#fileInputContainer input[type=file]")
                    ?.click()
                }
              >
                <AttachFileIcon />
              </IconButton>

              <IconButton
                style={{ margin: "5px" }}
                type="submit"
                size="small"
                onClick={(e) => handleSubmit(e)}
              >
                <SendIcon />
              </IconButton>
            </div>
          </div>
          <div
            id="fileInputContainer"
            style={{ display: "none", width: "100px" }}
          >
            <input type="file" onChange={uploadPhotos} />
          </div>
          {feedback ? (
            <p style={{ color: "#080", marginTop: "15px" }}>{feedback}</p>
          ) : null}
        </Paper>

        <Dialog
          open={deleteChatConfirmation}
          onClose={() => setDeleteChatConfirmation(false)}
          aria-labelledby="chat-title"
          aria-describedby="chat-description"
        >
          <DialogTitle id="chat-title">{"Supprimer ce message ?"}</DialogTitle>
          <DialogContent>
            <DialogContentText id="chat-description">
              Êtes-vous sûr de supprimer ce message ?
            </DialogContentText>
          </DialogContent>
          <DialogActions>
            <Button
              onClick={() => setDeleteChatConfirmation(false)}
              color="primary"
            >
              Annuler
            </Button>
            <Button onClick={handleDeleteChat} color="primary" autoFocus>
              Supprimer
            </Button>
          </DialogActions>
        </Dialog>
      </Paper>
    </div>
  );
}

export default MessengerViewMode;
