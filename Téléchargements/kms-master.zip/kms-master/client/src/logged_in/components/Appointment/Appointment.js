import {
  IconButton,
  Paper,
  makeStyles,
  TextField,
  TableContainer,
  Table,
  TableHead,
  TableRow,
  TableCell,
  TableBody,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogContentText,
  DialogActions,
  Button,
  CircularProgress,
  Tooltip,
} from "@material-ui/core";
import React, { useEffect, useState } from "react";
import AddIcon from "@material-ui/icons/Add";
import EditIcon from "@material-ui/icons/Edit";
import ClearIcon from "@material-ui/icons/Clear";
import DeleteIcon from "@material-ui/icons/Delete";
import DeleteForeverIcon from "@material-ui/icons/DeleteForever";
import ArrowDropDownIcon from "@material-ui/icons/ArrowDropDown";
import { useDispatch, useSelector } from "react-redux";
import AppointmentDetails from "./AppointmentDetails.js";
import {
  changeStatus,
  filterAppointments,
  getMyAppointments,
} from "../../../actions/appointments.js";
import AddAppointment from "./AddAppointment.js";
import moment from "moment";
import FaceIcon from "@material-ui/icons/Face";
import PublicIcon from "@material-ui/icons/Public";
import PersonIcon from "@material-ui/icons/Person";
import AddPatient from "../Patients/AddPatient.js";
import PrintIcon from "@material-ui/icons/Print";
import PrintApp from "./PrintApp.js";
import RestoreFromTrashIcon from "@material-ui/icons/RestoreFromTrash";
import EventAvailableIcon from "@material-ui/icons/EventAvailable";
import { useHistory } from "react-router-dom";
import { Autocomplete, Pagination } from "@material-ui/lab";
import { DatePicker } from "@material-ui/pickers";

const useStyles = makeStyles((theme) => ({
  iconButton: {
    margin: 5,
  },
  paper: {
    flexGrow: 1,
    padding: 30,
  },
  flex: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    padding: "10px 20px",
  },
  white: {
    background: "#FFF",
  },
  gray: {
    background: "#de5b5b7d",
  },
  searchBar: {
    minWidth: "200px",
    margin: "0 10px",
  },
  datePicker: {
    width: "200px",
    margin: "0 10px",
  },
  status: {
    padding: "7px 10px",
    borderRadius: "20px",
    boxShadow: "0px 0px 5px rgba(0,0,0,0.1)",
    background: "#EEE",
    fontWeight: "bold",
  },
  type: {
    padding: "7px 10px",
    borderRadius: "30px",
    boxShadow: "0px 0px 5px rgba(0,0,0,0.15)",
    fontSize: "0.8rem",
    fontWeight: "bold",
    opacity: 0.8,
  },
}));

export default function Appointment(props) {
  const { selectAppointment, doctorsByEtab, etablissement, agendas } = props;
  const classes = useStyles();
  const dispatch = useDispatch();
  const history = useHistory();
  const { patients } = useSelector((state) => state.patients);
  const { appointments, numberOfPages, AppointmentsIsLoading } = useSelector(
    (state) => state.appointments
  );

  const [selectedAppointment, setSelectedAppointment] = useState(null);
  const [showAddAppointment, setShowAddAppointment] = useState(false);
  const [detailsPageOpen, setDetailsPageOpen] = useState(false);
  const [deleteAppointmentConfirmation, setDeleteAppointmentConfirmation] =
    useState(false);
  const connectedUser = JSON.parse(localStorage.getItem("profile"))?.user;
  const [selectedPatient, setSelectedPatient] = useState(null);
  const [extendForm, setExtendForm] = useState(false);
  const [typesByEtab, setTypesByEtab] = useState([]);
  const [filterData, setFilterData] = useState({
    page: 0,
    status: undefined,
    type: undefined,
    doctorId: undefined,
    startDate: null,
    endDate: null,
    patientId: undefined,
    showCanceled: true,
  });

  useEffect(selectAppointment, [selectAppointment]);

  useEffect(() => {
    if (filterData.page >= numberOfPages) {
      setFilterData((filterData) => ({ ...filterData, page: 0 }));
    }
  }, [numberOfPages, filterData.page]);

  useEffect(() => {
    if (connectedUser.role === "patient") {
      dispatch(getMyAppointments(connectedUser._id, filterData));
    } else {
      dispatch(filterAppointments(filterData));
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [connectedUser.role, filterData]);

  useEffect(() => {
    if (agendas?.length > 0) {
      var types = [];
      // eslint-disable-next-line array-callback-return
      agendas?.map((agenda) => {
        if (agenda.template?.table) {
          // eslint-disable-next-line array-callback-return
          agenda.template?.table?.map((consultation) => {
            if (
              types?.filter(
                (cs) =>
                  cs.type?.toLowerCase()?.trim() ===
                  consultation.type?.toLowerCase()?.trim()
              )?.length === 0
            ) {
              types?.push({
                type: consultation.type,
                color: consultation.color,
                doctor: doctorsByEtab?.find((doc) =>
                  doc.agendas.includes(agenda._id)
                )?.user?.name,
                doctorId: doctorsByEtab?.find((doc) =>
                  doc.agendas.includes(agenda._id)
                )?._id,
              });
            }
          });
        } else {
          // eslint-disable-next-line array-callback-return
          agenda.consultationsTypes?.map((consultation) => {
            if (
              types?.filter(
                (cs) =>
                  cs.type?.toLowerCase()?.trim() ===
                  consultation?.toLowerCase()?.trim()
              )?.length === 0
            ) {
              types?.push({
                type: consultation,
              });
            }
          });
        }
      });

      setTypesByEtab(types);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [agendas, doctorsByEtab]);

  const handleClickOpen = () => {
    setSelectedAppointment(null);
    setShowAddAppointment(true);
  };

  const appointmentDetails = (appointment) => {
    setSelectedAppointment(appointment);
    setDetailsPageOpen(true);
  };

  const handleDeleteAppointment = () => {
    dispatch(
      changeStatus(
        selectedAppointment?._id,
        selectedAppointment.celluleId,
        "Annuler"
      )
    );
    setDeleteAppointmentConfirmation(true);
  };

  const handleDoctorChanged = (_, value) =>
    setFilterData({ ...filterData, page: 0, doctorId: value?._id });

  const handlePatientChanged = (_, value) =>
    setFilterData({ ...filterData, page: 0, patientId: value?._id });

  const handleDateChanged = (field) => (value) =>
    setFilterData({
      ...filterData,
      page: 0,
      [field]: value && moment(value).format("YYYY-MM-DD"),
    });

  const handleClearDate = (field) => (event) => {
    event.stopPropagation();
    handleDateChanged(field)(null);
  };

  const handleShowCanceledChanged = () =>
    setFilterData({ ...filterData, showCanceled: !filterData.showCanceled });

  const handlePageChanged = (_, newPage) =>
    setFilterData({ ...filterData, page: newPage - 1 });

  const handlePrint = () => window.print();

  return (
    <Paper sx={{ width: "100%", overflow: "hidden" }}>
      <div className="noprint">
        <div className={classes.flex}>
          <h5 style={{ fontSize: "18px" }}>
            Rendez vous de :
            <strong style={{ color: "rgb(72,41,178)" }}>
              &nbsp;{etablissement?.name}
            </strong>
          </h5>
          <div className={classes.flex}>
            <IconButton
              color="primary"
              aria-label="print"
              className={classes.iconButton}
              onClick={handlePrint}
            >
              <PrintIcon />
            </IconButton>
            <IconButton
              color="primary"
              aria-label="restore"
              className={classes.iconButton}
              style={{ marginLeft: "10px" }}
              onClick={handleShowCanceledChanged}
            >
              <RestoreFromTrashIcon
                style={
                  filterData.showCanceled
                    ? { color: "#080" }
                    : { color: "#444" }
                }
              />
            </IconButton>
            {connectedUser.role === "admin" ||
            connectedUser.role === "doctor" ? (
              <div>
                {AppointmentsIsLoading ? (
                  <div style={{ margin: 5, padding: "12px" }}>
                    <CircularProgress size={25} color="primary" />
                  </div>
                ) : (
                  <IconButton
                    color="primary"
                    aria-label="add"
                    className={classes.iconButton}
                    onClick={handleClickOpen}
                  >
                    <AddIcon />
                  </IconButton>
                )}
              </div>
            ) : null}
          </div>
        </div>
        <div className={classes.flex}>
          <div className={classes.flex} style={{ justifyContent: "flex-end" }}>
            {connectedUser?.role !== "patient" && (
              <div className={classes.searchBar}>
                <Autocomplete
                  options={doctorsByEtab}
                  getOptionLabel={(doctor) => doctor.user?.name}
                  renderInput={(params) => (
                    <TextField {...params} placeholder="Tous les docteurs" />
                  )}
                  onChange={handleDoctorChanged}
                />
                <span
                  style={{
                    marginTop: "5px",
                    color: "#444",
                    display: "block",
                    fontSize: "12px",
                  }}
                >
                  Filtrer par medecins
                </span>
              </div>
            )}
            {connectedUser?.role !== "patient" && (
              <div className={classes.searchBar}>
                <Autocomplete
                  options={patients}
                  getOptionLabel={(patient) => patient.user?.name}
                  renderInput={(params) => (
                    <TextField {...params} placeholder="Tous les patients" />
                  )}
                  onChange={handlePatientChanged}
                />
                <span
                  style={{
                    marginTop: "5px",
                    color: "#444",
                    display: "block",
                    fontSize: "12px",
                  }}
                >
                  Filtrer par nom de patient
                </span>
              </div>
            )}
            <div className={classes.datePicker}>
              <DatePicker
                disableToolbar
                variant="inline"
                emptyLabel="Start Date"
                format="dd/MM/yyyy"
                value={filterData.startDate}
                onChange={handleDateChanged("startDate")}
                InputProps={{
                  endAdornment: filterData.startDate ? (
                    <IconButton
                      size="small"
                      onClick={handleClearDate("startDate")}
                    >
                      <ClearIcon />
                    </IconButton>
                  ) : (
                    <IconButton size="small">
                      <ArrowDropDownIcon />
                    </IconButton>
                  ),
                }}
              />
              <span
                style={{
                  marginTop: "5px",
                  color: "#444",
                  display: "block",
                  fontSize: "12px",
                }}
              >
                Filtrer par date
              </span>
            </div>
            <div className={classes.datePicker}>
              <DatePicker
                disableToolbar
                variant="inline"
                emptyLabel="End Date"
                format="dd/MM/yyyy"
                value={filterData.endDate}
                onChange={handleDateChanged("endDate")}
                InputProps={{
                  endAdornment: filterData.endDate ? (
                    <IconButton
                      size="small"
                      onClick={handleClearDate("endDate")}
                    >
                      <ClearIcon />
                    </IconButton>
                  ) : (
                    <IconButton size="small">
                      <ArrowDropDownIcon />
                    </IconButton>
                  ),
                }}
              />
              <span
                style={{
                  marginTop: "5px",
                  color: "#444",
                  display: "block",
                  fontSize: "12px",
                }}
              >
                Filtrer par interval de date
              </span>
            </div>
            <IconButton
              color="primary"
              aria-label="restore"
              className={classes.iconButton}
              onClick={() =>
                setFilterData({ page: 0, startDate: null, endDate: null })
              }
            >
              <DeleteIcon
                style={
                  filterData.showCanceled
                    ? { color: "#080" }
                    : { color: "#444" }
                }
              />
            </IconButton>
          </div>
        </div>
        <TableContainer sx={{ maxHeight: 440 }} className="ListeRDVTable">
          <Table stickyHeader aria-label="sticky table">
            <TableHead>
              <TableRow>
                <TableCell>Date</TableCell>
                <TableCell>Heure</TableCell>
                {connectedUser.role !== "patient" && (
                  <TableCell>Patient</TableCell>
                )}
                <TableCell>Doctor</TableCell>
                <TableCell align="center">Consultation</TableCell>
                {connectedUser.role !== "patient" && (
                  <TableCell align="center">Createur</TableCell>
                )}
                <TableCell align="center">Status</TableCell>
                {connectedUser.role !== "patient" && (
                  <TableCell>Actions</TableCell>
                )}
              </TableRow>
            </TableHead>
            <TableBody>
              {appointments && !AppointmentsIsLoading
                ? appointments.map((appointment) => (
                    <TableRow
                      key={appointment._id}
                      onClick={() => appointmentDetails(appointment)}
                    >
                      <TableCell>
                        {moment(appointment.start)?.format("DD/MM/YYYY")}
                      </TableCell>
                      <TableCell>
                        {moment(appointment.start)?.format("HH:mm")}
                      </TableCell>
                      {connectedUser.role !== "patient" && (
                        <TableCell>{appointment.patient?.user?.name}</TableCell>
                      )}
                      <TableCell>{appointment.doctor?.user?.name}</TableCell>
                      <TableCell align="center">
                        <span
                          className={classes.type}
                          style={{
                            background: `${
                              typesByEtab.find(
                                (row) =>
                                  row.type?.toLowerCase()?.trim() ===
                                  appointment.type?.toLowerCase()?.trim()
                              )?.color
                            }`,
                          }}
                        >
                          {appointment.type}
                        </span>
                      </TableCell>
                      {connectedUser.role !== "patient" && (
                        <TableCell align="center">
                          {appointment.createdBy.role === "patient" ? (
                            <Tooltip
                              title={`Internet @${appointment.createdBy?.name}`}
                              placement="bottom"
                            >
                              <PublicIcon />
                            </Tooltip>
                          ) : appointment.createdBy.role === "client" ? (
                            <div>
                              <Tooltip
                                title={`Docteur @${appointment.createdBy?.name}`}
                                placement="bottom"
                              >
                                <FaceIcon />
                              </Tooltip>
                            </div>
                          ) : appointment.createdBy?.role === "admin" ? (
                            <Tooltip
                              title={`Admin @${appointment.createdBy?.name}`}
                              placement="bottom"
                            >
                              <PersonIcon />
                            </Tooltip>
                          ) : (
                            <span>{appointment.createdBy?.name}</span>
                          )}
                        </TableCell>
                      )}
                      <TableCell align="center">
                        <span
                          className={classes.status}
                          style={{
                            background:
                              appointment.status === "Attente"
                                ? "#ffc107"
                                : appointment.status === "Confirmer"
                                ? "#4caf50"
                                : appointment.status === "Annuler"
                                ? "#f44336"
                                : "#eee",
                          }}
                        >
                          {appointment.status === "Attente"
                            ? "En attente"
                            : appointment.status === "Confirmer"
                            ? "Confirmé"
                            : appointment.status === "Annuler"
                            ? "Annulé"
                            : ""}
                        </span>
                      </TableCell>
                      {connectedUser?.role !== "patient" && (
                        <TableCell>
                          <EventAvailableIcon
                            onClick={() => {
                              localStorage.setItem(
                                "currentDate",
                                moment(appointment.start).format("YYYY-MM-DD")
                              );
                              history.push("/c/calendar");
                            }}
                            style={{
                              color: "rgb(119 184 194)",
                              cursor: "pointer",
                              fontSize: "1.4rem",
                              marginRight: "10px",
                            }}
                          />

                          <EditIcon
                            onClick={(e) => {
                              e.stopPropagation();
                              setSelectedAppointment(appointment);
                              setShowAddAppointment(true);
                            }}
                            style={{ color: "#1bb719", cursor: "pointer" }}
                          />
                          <DeleteForeverIcon
                            onClick={(e) => {
                              e.stopPropagation();
                              setSelectedAppointment(appointment);
                              setDeleteAppointmentConfirmation(true);
                            }}
                            style={{ color: "#b54827", cursor: "pointer" }}
                          />
                        </TableCell>
                      )}
                    </TableRow>
                  ))
                : null}
            </TableBody>
          </Table>
          <Pagination
            style={{
              display: "flex",
              justifyContent: "center",
              margin: "auto",
              padding: "30px",
            }}
            page={filterData.page + 1}
            count={numberOfPages}
            onChange={handlePageChanged}
          />
        </TableContainer>
        {AppointmentsIsLoading ? (
          <div
            style={{
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
              height: "100px",
            }}
          >
            <img
              width={60}
              height={60}
              src="/images/loading-36.gif"
              alt="loading"
            />
          </div>
        ) : (
          !appointments?.length && (
            <div
              style={{
                display: "flex",
                justifyContent: "center",
                alignItems: "center",
                height: "100px",
              }}
            >
              Pas de Rendez-vous
            </div>
          )
        )}
        <Dialog
          maxWidth={extendForm ? "lg" : "sm"}
          open={showAddAppointment}
          onClose={() => setShowAddAppointment(false)}
          style={{ transition: "all 0.6s ease-in-out" }}
          aria-labelledby="form-dialog-title"
        >
          <div
            style={
              extendForm
                ? {
                    display: "flex",
                    margin: "auto",
                    transition: "all 0.6s ease-in-out",
                  }
                : {
                    display: "block",
                    margin: "auto",
                    transition: "all 0.6s ease-in-out",
                  }
            }
          >
            <Paper
              className={classes.paper}
              style={extendForm ? { width: "50%" } : { width: "100%" }}
            >
              <AddAppointment
                appointment={selectedAppointment}
                calendarForm={null}
                show={showAddAppointment}
                close={() => setShowAddAppointment(false)}
                connectedUser={connectedUser}
                doctorsByEtab={doctorsByEtab}
                handleSetSelectedPatient={(thePatient) =>
                  setSelectedPatient(thePatient)
                }
                handleExtendForm={() => setExtendForm(!extendForm)}
                extendForm={extendForm}
                agendas={agendas}
              />
            </Paper>
            <Paper
              className={classes.paper}
              style={extendForm ? { width: "50%" } : { width: "100%" }}
            >
              <AddPatient
                patient={selectedPatient}
                show={extendForm}
                close={() => setExtendForm(false)}
                doctorsByEtab={doctorsByEtab}
              />
            </Paper>
          </div>
        </Dialog>
        <Dialog
          open={deleteAppointmentConfirmation}
          onClose={() => setDeleteAppointmentConfirmation(false)}
          aria-labelledby="appointment-title"
          aria-describedby="appointment-description"
        >
          <DialogTitle id="appointment-title">
            {"Supprimer un appointment ?"}
          </DialogTitle>
          <DialogContent>
            <DialogContentText id="appointment-description">
              Êtes-vous sûr de supprimer ce appointment ?
            </DialogContentText>
          </DialogContent>
          <DialogActions>
            <Button
              onClick={() => setDeleteAppointmentConfirmation(false)}
              color="primary"
            >
              Annuler
            </Button>
            <Button onClick={handleDeleteAppointment} color="primary" autoFocus>
              Supprimer
            </Button>
          </DialogActions>
        </Dialog>
        <AppointmentDetails
          showMe={detailsPageOpen}
          appointment={selectedAppointment}
          closeMe={() => setDetailsPageOpen(false)}
        />
      </div>
      <div style={{ display: "none" }} className="print">
        <PrintApp
          date={filterData.date}
          doctorsByEtab={doctorsByEtab}
          appointments={appointments}
        />
      </div>
    </Paper>
  );
}
