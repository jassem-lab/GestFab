import React from "react";

function AppointmentDetails() {
  return <div></div>;
}

export default AppointmentDetails;
