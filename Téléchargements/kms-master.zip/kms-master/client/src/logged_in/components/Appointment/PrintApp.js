import {
  makeStyles,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Tooltip,
} from "@material-ui/core";
import moment from "moment";
import React from "react";
import FaceIcon from "@material-ui/icons/Face";
import PublicIcon from "@material-ui/icons/Public";
import PersonIcon from "@material-ui/icons/Person";

const useStyles = makeStyles((theme) => ({
  iconButton: {
    margin: 5,
  },
  status: {
    padding: "7px 10px",
    borderRadius: "20px",
    boxShadow: "0px 0px 5px rgba(0,0,0,0.1)",
    background: "#EEE",
    fontWeight: "bold",
  },
  type: {
    padding: "7px 10px",
    borderRadius: "30px",
    boxShadow: "0px 0px 5px rgba(0,0,0,0.15)",
    fontSize: "0.8rem",
    fontWeight: "bold",
    opacity: 0.8,
  },
}));

function PrintApp(props) {
  const { appointments, doctorsByEtab, date } = props;
  const classes = useStyles();

  const findColorByTC = (TC, doctorId) => {
    const doctor = doctorsByEtab?.find((doctor) => doctor._id === doctorId);
    const table = doctor?.agenda?.template?.table;
    if (table) {
      const row = table.find((row) => row.type === TC);
      if (row) {
        return row.color;
      }
    }
    return "#eee";
  };
  return (
    <div className="print-container">
      <h2>
        Rendez-vous {date ? `Du ${moment(date).format("DD/MM/YYYY")}` : ""}
      </h2>
      <TableContainer>
        <Table stickyHeader aria-label="sticky table">
          <TableHead>
            <TableRow>
              <TableCell>Date</TableCell>
              <TableCell>Heure</TableCell>
              <TableCell>Patient</TableCell>
              <TableCell align="center">Consultation</TableCell>
              <TableCell align="center">Status</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {appointments?.map((appointment) => (
              <TableRow key={appointment._id}>
                <TableCell>
                  {moment(appointment.start)?.format("DD/MM/YYYY")}
                </TableCell>
                <TableCell>
                  {moment(appointment.start)?.format("HH:mm")}
                </TableCell>
                <TableCell>{appointment.patient?.user?.name}</TableCell>
                <TableCell align="center">
                  <span
                    className={classes.type}
                    style={{
                      background: `${findColorByTC(
                        appointment.type,
                        appointment.doctor._id
                      )}`,
                    }}
                  >
                    {appointment.type}
                  </span>
                </TableCell>
          
                <TableCell align="center">
                  <span
                    className={classes.status}
                    style={{
                      background:
                        appointment.status === "Attente"
                          ? "#ffc107"
                          : appointment.status === "Confirmer"
                          ? "#4caf50"
                          : appointment.status === "Annuler"
                          ? "#f44336"
                          : "#eee",
                    }}
                  >
                    {appointment.status === "Attente"
                      ? "En attente"
                      : appointment.status === "Confirmer"
                      ? "Confirmé"
                      : appointment.status === "Annuler"
                      ? "Annulé"
                      : ""}
                  </span>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>
    </div>
  );
}

export default PrintApp;
