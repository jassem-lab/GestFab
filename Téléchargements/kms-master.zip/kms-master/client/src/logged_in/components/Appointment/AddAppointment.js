import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import {
  Grid,
  makeStyles,
  TextField,
  Typography,
  Button,
  Select,
  MenuItem,
  FormControl,
} from "@material-ui/core";
import {
  createAppointment,
  editAppointment,
  addManyAppointments,
} from "../../../actions/appointments";
import moment from "moment";
import Autocomplete from "@material-ui/lab/Autocomplete";
import AddCircleOutlineIcon from "@material-ui/icons/AddCircleOutline";
import AssignmentIndIcon from "@material-ui/icons/AssignmentInd";
import BasicAlert from "../../../shared/components/Alert";

const useStyles = makeStyles((theme) => ({
  formControl: {
    minWidth: 120,
    height: 20,
  },
  saveButton: {
    paddingTop: 10,
  },
  loading: {
    width: "20px",
    marginLeft: "10px",
  },
  divider: {
    marginTop: "30px",
  },
  green: {
    background: "#080",
  },
  gray: {
    background: "#777",
  },
  rowContainer: {
    display: "flex",
    alignItems: "center",
    marginBottom: "0",
  },
  input: {
    marginRight: "5%",
    width: "65%",
  },
  label: {
    width: "30%",
    paddingTop: "5px",
  },
  patientIcon: {
    marginRight: "5%",
    fontSize: "2.5em",
    cursor: "pointer",
    transition: "all 0.5s ease-in-out",
    "&:hover": {
      transform: "scale(1.2)",
      color: "rgb(179,41,78)",
    },
  },
}));

export default function AddAppointment(props) {
  const {
    appointment,
    show,
    connectedUser,
    doctorsByEtab,
    calendarForm,
    agendas,
  } = props;
  const dispatch = useDispatch();
  const { AppointmentsIsLoading } = useSelector((state) => state.appointments);
  const { patients } = useSelector((state) => state.patients);
  const classes = useStyles();
  const [feedback, setFeedback] = useState(null);
  const now = moment().set({ hour: 0, minute: 0, second: 0, millisecond: 0 });
  const [typesByEtab, setTypesByEtab] = useState([]);
  const [selectedPatient, setSelectedPatient] = useState(null);

  // Available Types

  useEffect(() => {
    if (agendas.length > 0) {
      let types = [];
      agendas?.map((agenda) =>
        // eslint-disable-next-line array-callback-return
        agenda.consultationsTypes?.map((consultation) => {
          if (types.indexOf(consultation) === -1) {
            types.push(consultation);
          }
        })
      );
      setTypesByEtab(types);
    }
  }, [agendas]);

  const [formData, setFormData] = useState({
    createdAt: now.format("YYYY-MM-DD"),
    createdBy: connectedUser._id,
    doctor: doctorsByEtab[0]?._id,
    patient: "",
    start: now.format("YYYY-MM-DDTHH:mm"),
    duration: doctorsByEtab[0]?.agenda?.template?.durationPart || 0,
    type: "",
    motif: "",
    notes: "",
    status: "Attente",
    celluleId: null,
    agenda: null,
  });

  const clear = () => {
    setFormData({
      createdBy: connectedUser._id,
      doctor: doctorsByEtab[0]?._id,
      patient: "",
      start: now.format("YYYY-MM-DDTHH:mm"),
      createdAt: now.format("YYYY-MM-DD"),
      duration: doctorsByEtab[0]?.agenda?.template?.durationPart || 0,
      type: "",
      motif: "",
      notes: "",
      status: "Attente",
      celluleId: null,
      agenda: null,
    });
  };

  useEffect(() => {
    if (appointment) {
      setFormData({
        createdAt: appointment.createdAt,
        createdBy: appointment.createdBy,
        doctor: appointment.doctor?._id,
        patient: appointment.patient?._id,
        start: moment(appointment.start)?.format("YYYY-MM-DDTHH:mm"),
        duration: appointment.duration,
        type: appointment.type,
        motif: appointment.motif,
        notes: appointment.notes,
        status: appointment.status,
        celluleId: appointment.celluleId,
        agenda: appointment.agenda,
      });
      setSelectedPatient(
        patients?.find((patient) => patient._id === appointment.patient?._id)
      );
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [appointment]);

  useEffect(() => {
    if (calendarForm) {
      if (
        calendarForm.multipleDates &&
        calendarForm.multipleDates?.length > 0
      ) {
        setFormData({
          createdBy: moment(calendarForm.createdBy)?.format("YYYY-MM-DDTHH:mm"),
          doctor: calendarForm.doctor,
          patient: calendarForm.patient,
          start: null,
          duration: calendarForm.duration,
          type: calendarForm.type,
          motif: "",
          notes: "",
          status: calendarForm.status,
          celluleId: calendarForm.celluleId,
          agenda: calendarForm.agenda,
        });
      } else {
        if (calendarForm.isNewRdv) {
          setFormData({
            createdBy: calendarForm.createdBy,
            doctor: calendarForm.doctor,
            patient: "",
            start: moment(calendarForm.start)?.format("YYYY-MM-DDTHH:mm"),
            duration: calendarForm.duration,
            type: calendarForm.type,
            motif: "",
            notes: "",
            status: calendarForm.status,
            celluleId: calendarForm.celluleId,
            agenda: calendarForm.agenda,
          });
          setSelectedPatient(null);
        } else {
          setFormData({
            createdBy: calendarForm.createdBy,
            doctor: calendarForm.doctor,
            patient: calendarForm.patient,
            start: calendarForm.start,
            duration: calendarForm.duration,
            type: calendarForm.type,
            motif: calendarForm.motif,
            notes: calendarForm.notes,
            status: calendarForm.status,
            celluleId: calendarForm.celluleId,
            agenda: calendarForm.agenda,
          });
          setSelectedPatient(
            patients?.find((patient) => patient._id === calendarForm.patient)
          );
        }
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [calendarForm]);

  const handleSubmit = (e) => {
    e.preventDefault();

    if (!formData.doctor || formData.doctor?.length === 0) {
      setFeedback("Veuillez sélectionnez un médecin.");
      if (document.getElementById("feedback")) {
        document.getElementById("feedback").style.color = "red";
      }
      if (document.getElementById("doctor")) {
        document.getElementById("doctor").focus();
      }
      return;
    }

    if (!formData.patient || formData.patient?.length === 0) {
      setFeedback("Veuillez sélectionnez un patient.");
      if (document.getElementById("feedback")) {
        document.getElementById("feedback").style.color = "red";
      }
      if (document.getElementById("patient")) {
        document.getElementById("patient").focus();
      }
      return;
    }

    if (!calendarForm) {
      if (appointment) {
        dispatch(editAppointment(appointment._id, formData)).then(() => {
          setFeedback("Rendez-vous modifié");
        });
      } else {
        dispatch(createAppointment(formData)).then(() => {
          setFeedback("Rendez-vous ajouté");
          clear();
          props.close();
        });
      }
    } else {
      if (calendarForm.multipleDates && calendarForm.multipleDates.length > 0) {
        dispatch(
          addManyAppointments(calendarForm.multipleDates, formData)
        ).then(() => {
          setFeedback("Rendez-vous ajoutés");
          clear();
          // window?.location?.reload();
          props.close();
        });
      } else {
        if (calendarForm.isNewRdv) {
          dispatch(createAppointment(formData)).then(() => {
            setFeedback("Rendez-vous ajouté");
            clear();
            props.close();
          });
        } else {
          dispatch(editAppointment(calendarForm.id, formData)).then(() => {
            setFeedback("Rendez-vous modifié");
            props.close();
          });
        }
      }
    }
  };

  if (!show) return null;

  return (
    <form style={{ zIndex: 5 }}>
      <Grid container spacing={3} className="griditem">
        <Grid item xs={12}>
          <Typography variant="h4" style={{ marginTop: "10px" }}>
            {" "}
            {!calendarForm
              ? appointment
                ? "Modifier"
                : "Nouveau"
              : calendarForm.isNewRdv
              ? "Nouveau"
              : "Modifier"}{" "}
            Rendez-vous
          </Typography>
        </Grid>
        {appointment || calendarForm ? (
          <Grid item xs={12} className={classes.rowContainer}>
            <Typography className={classes.label}> Status : </Typography>
            <Select
              name="status"
              id="status"
              className={classes.input}
              value={formData?.status}
              onChange={(e) =>
                setFormData({ ...formData, status: e.target?.value })
              }
            >
              <MenuItem value="Attente">En Attente</MenuItem>
              <MenuItem value="Confirmer">Confirmer</MenuItem>
              <MenuItem value="Annuler">Annuler</MenuItem>
            </Select>
          </Grid>
        ) : null}
        <Grid
          item
          xs={12}
          style={{
            marginBottom: "25px",
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
          }}
        >
          <FormControl className={classes.formControl}>
            <Autocomplete
              id="patient"
              value={selectedPatient}
              onChange={(e, val) => {
                e.preventDefault();
                setSelectedPatient(val);
                setFormData({ ...formData, patient: val?._id });
                props.handleSetSelectedPatient(val);
              }}
              options={patients}
              getOptionLabel={(option) => option?.user?.name}
              style={{ width: 300, marginBottom: "10px" }}
              renderInput={(params) => (
                <TextField {...params} label="Patient" variant="outlined" />
              )}
            />
          </FormControl>
          {selectedPatient ? (
            <AssignmentIndIcon
              className={classes.patientIcon}
              onClick={() => {
                props.handleSetSelectedPatient(selectedPatient);
                props.handleExtendForm();
              }}
              style={
                props.extendForm
                  ? { color: "rgb(179,41,78)" }
                  : { color: "#333" }
              }
            />
          ) : (
            <AddCircleOutlineIcon
              className={classes.patientIcon}
              onClick={() => {
                props.handleSetSelectedPatient(null);
                props.handleExtendForm();
              }}
              style={
                props.extendForm
                  ? { color: "rgb(179,41,78)" }
                  : { color: "#333" }
              }
            />
          )}
        </Grid>

        <Grid item xs={12} className={classes.rowContainer}>
          <Typography className={classes.label}> Doctor : </Typography>
          <Select
            disabled={
              calendarForm?.multipleDates &&
              calendarForm.multipleDates.length > 0
            }
            name="doctor"
            id="doctor"
            className={classes.input}
            value={formData?.doctor}
            onChange={(e) =>
              setFormData({ ...formData, doctor: e.target?.value })
            }
          >
            {doctorsByEtab?.map((doctor) => (
              <MenuItem key={doctor._id} value={doctor._id}>
                {doctor.user?.name}
              </MenuItem>
            ))}
          </Select>
        </Grid>

        <Grid item xs={12} className={classes.rowContainer}>
          <Typography className={classes.label}> Type : </Typography>
          <Select
            disabled={
              calendarForm?.multipleDates &&
              calendarForm.multipleDates?.length > 0
            }
            name="type"
            id="type"
            className={classes.input}
            value={formData?.type}
            onChange={(e) =>
              setFormData({ ...formData, type: e?.target?.value })
            }
          >
            {typesByEtab?.map((type) => (
              <MenuItem key={type} value={type}>
                {type}
              </MenuItem>
            ))}
          </Select>
        </Grid>
        <Grid item xs={6} style={{ display: "flex", alignItems: "center" }}>
          <TextField
            disabled={
              calendarForm?.multipleDates &&
              calendarForm.multipleDates?.length > 0
            }
            type="datetime-local"
            id="datetime-local"
            name="startDate"
            value={formData.start}
            onChange={(e) =>
              setFormData({ ...formData, start: e.target.value })
            }
            InputLabelProps={{ shrink: true }}
          />
        </Grid>
        {calendarForm?.createdAt ? (
          <Grid item xs={6} className={classes.rowContainer}>
            <Typography className={classes.label}>
              {" "}
              Prise de Rendez-vous :{" "}
            </Typography>
            <Typography className={classes.label}>
              {" "}
              {calendarForm.createdAt}
            </Typography>
          </Grid>
        ) : null}

        <Grid item xs={6} style={{ display: "flex", alignItems: "center" }}>
          <Typography> Durée (min) : </Typography>
          <TextField
            type="number"
            style={{ width: "50px" }}
            name="duration"
            id="duration"
            value={formData.duration}
            onChange={(e) =>
              setFormData({ ...formData, duration: e.target.value })
            }
          />
        </Grid>
        <Grid item xs={12} style={{ display: "flex", alignItems: "center" }}>
          <TextField
            fullWidth
            label="Motif"
            name="motif"
            id="motif"
            value={formData.motif}
            onChange={(e) =>
              setFormData({ ...formData, motif: e.target.value })
            }
          />
        </Grid>
        <Grid item xs={12} style={{ display: "flex", alignItems: "center" }}>
          <TextField
            fullWidth
            multiline
            rows={4}
            label="Notes"
            name="notes"
            id="notes"
            value={formData.notes}
            onChange={(e) =>
              setFormData({ ...formData, notes: e.target.value })
            }
          />
        </Grid>
      </Grid>

      <Button
        style={{ marginTop: "50px", marginRight: "10px" }}
        variant="contained"
        color="secondary"
        type="submit"
        onClick={(e) => handleSubmit(e)}
      >
        Enregistrer
        {AppointmentsIsLoading ? (
          <img
            className={classes.loading}
            src="/images/loading.gif"
            alt="Loading"
          />
        ) : null}
      </Button>
      <Button
        onClick={props.close}
        style={{ marginTop: "50px" }}
        variant="contained"
        color="primary"
      >
        Annuler
      </Button>
      {feedback ? <BasicAlert message={feedback} /> : null}
    </form>
  );
}
