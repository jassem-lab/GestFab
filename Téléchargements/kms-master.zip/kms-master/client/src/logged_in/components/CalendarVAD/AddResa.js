import React, { useEffect, useState } from "react";
import { useDispatch } from "react-redux";
import {
  Grid,
  makeStyles,
  TextField,
  Typography,
  Button,
  Select,
  MenuItem,
} from "@material-ui/core";
import { createResa, editResa } from "../../../actions/resas";
import BasicAlert from "../../../shared/components/Alert";
const useStyles = makeStyles((theme) => ({
  formControl: {
    minWidth: 120,
    height: 20,
  },
  saveButton: {
    paddingTop: 10,
  },
  loading: {
    width: "20px",
    marginLeft: "10px",
  },
  divider: {
    marginTop: "30px",
  },
  green: {
    background: "#080",
  },
  gray: {
    background: "#777",
  },
  rowContainer: {
    display: "flex",
    alignItems: "center",
    marginBottom: "0",
  },
  input: {
    marginRight: "5%",
    width: "65%",
  },
  label: {
    width: "30%",
    paddingTop: "5px",
  },
  patientIcon: {
    marginRight: "5%",
    fontSize: "2.5em",
    cursor: "pointer",
    transition: "all 0.5s ease-in-out",
    "&:hover": {
      transform: "scale(1.2)",
      color: "rgb(179,41,78)",
    },
  },
}));

export default function AddResa(props) {
  const { resa, show, doctorsByEtab, agendas, types, startTime } = props;
  const dispatch = useDispatch();
  const classes = useStyles();
  const [feedback, setFeedback] = useState(null);
  const [selectedAgenda, setSelectedAgenda] = useState(null);

  const [formData, setFormData] = useState({
    doctor: "",
    start: "",
    type: "",
    color: "",
    status: "free",
    agenda: "",
  });

  const clear = () => {
    setFormData({
      doctor: "",
      start: "",
      type: "",
      color: "",
      status: "free",
      agenda: "",
    });
  };

  // Available Types

  useEffect(() => {
    if (startTime) {
      setFormData({
        ...formData,
        start: startTime,
      });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [startTime]);

  useEffect(() => {
    if (agendas) {
      setSelectedAgenda(agendas[0]);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [agendas]);

  useEffect(() => {
    if (resa) {
      setFormData({
        doctor: resa.doctor,
        start: resa.start,
        type: resa.type,
        color: resa.color,
        status: resa.status,
        agenda: resa.agenda,
      });
    }
  }, []);

  useEffect(() => {
    if (doctorsByEtab && selectedAgenda) {
      setFormData({
        ...formData,
        doctor: doctorsByEtab?.find((doc) =>
          doc.agendas?.includes(selectedAgenda)
        )?._id,
        agenda: selectedAgenda,
      });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [doctorsByEtab, selectedAgenda]);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!formData.agenda || formData.agenda === "") {
      setFeedback("Veuillez choisir un agenda");
      console.log(formData);
      return;
    }

    if (resa) {
      dispatch(editResa(resa._id, formData)).then(() => {
        setFormData(resa);
        setFeedback("Réservation modifié");
        console.log(formData);
        props.close();
      });
    } else {
      dispatch(createResa(formData)).then(() => {
        setFeedback("Réservation ajouté");
        clear();
        props.close();
      });
    }
  };

  if (!show) return null;

  // const removedValues = [
  //   "Salle",
  //   "Cabine",
  //   "NP",
  //   "URG",
  //   "Sur+ Salle",
  //   "Perso-PH",
  //   "Perso-Sa",
  // ];
  return (
    <form>
      <Grid container spacing={3} className="griditem">
        <Grid item xs={12}>
          <Typography variant="h4" style={{ marginTop: "10px" }}>
            {" "}
            {resa ? "Modifier" : "Nouveau"} Réservation
          </Typography>
        </Grid>
        {/* RESERVATION STATE ( STATUS ) CHANGE IMMEDIATLY AND PUSHED IMMEDIATLY INTO THE DATABASE */}
        {resa ? (
          <Grid item xs={12} className={classes.rowContainer}>
            <Typography className={classes.label}> Status : </Typography>

            <Select
              name="status"
              id="status"
              className={classes.input}
              value={formData?.status}
              onChange={(e) =>
                setFormData({ ...formData, status: e.target?.value })
              }
            >
              <MenuItem value="free">Libre</MenuItem>
              <MenuItem value="taked">Ocuppée</MenuItem>
            </Select>
          </Grid>
        ) : null}
        <Grid item xs={12} className={classes.rowContainer}>
          <Typography className={classes.label}> Type : </Typography>
          <Select
            name="type"
            id="type"
            className={classes.input}
            value={formData?.type}
            onChange={(e) =>
              setFormData({
                ...formData,
                type: e?.target?.value,
                color: types?.find(
                  (cs) =>
                    cs.type?.toLowerCase()?.trim() ===
                    e?.target?.value?.toLowerCase()?.trim()
                )?.color,
              })
            }
          >
            {console.log(types)}
            {types
              ?.filter((type) => type.type.match("VAD"))
              .map((type, index) => (
                <MenuItem key={index} value={type.type}>
                  {type.type}
                </MenuItem>
              ))}
          </Select>
        </Grid>
        <Grid item xs={12} className={classes.rowContainer}>
          <Typography className={classes.label}> Date & Heure : </Typography>
          <TextField
            className={classes.input}
            type="datetime-local"
            id="datetime-local"
            name="startDate"
            value={formData.start}
            onChange={(e) => setFormData({ start: e.target.value })}
          />
        </Grid>
        <Grid item xs={12} className={classes.rowContainer}>
          <Typography className={classes.label}> Agenda : </Typography>
          <Select
            name="agenda"
            id="agenda"
            className={classes.input}
            value={formData?.agenda}
            onChange={(e) => setSelectedAgenda(e.target.value)}
          >
            {agendas?.map((agenda) => (
              <MenuItem key={agenda._id} value={agenda._id}>
                {agenda.name}
              </MenuItem>
            ))}
          </Select>
        </Grid>
      </Grid>

      <Button
        style={{ marginTop: "50px", marginRight: "10px" }}
        variant="contained"
        color="secondary"
        type="submit"
        onClick={(e) => handleSubmit(e)}
      >
        Enregistrer
      </Button>
      <Button
        onClick={props.close}
        style={{ marginTop: "50px" }}
        variant="contained"
        color="primary"
      >
        Annuler
      </Button>
      {feedback ? <BasicAlert message={feedback} /> : null}
    </form>
  );
}
