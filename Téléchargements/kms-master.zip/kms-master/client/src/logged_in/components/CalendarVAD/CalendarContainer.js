import { Dialog, Grid, Paper } from "@material-ui/core";
import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { getResasByMonth } from "../../../actions/resas";
import AddResa from "./AddResa";
import Calendar from "./Calendar";
import FilterContainer from "./FilterContainer";
import DialogDeleteAppointment from "./DialogDeleteAppointment";
import DialogActionsSelect from "./DialogActionsSelect";
import DialogDeleteResa from "./DialogDeleteResa";
import useStyles from "./style";
import AddAppointment from "../Appointment/AddAppointment";
import AddPatient from "../Patients/AddPatient";
import moment from "moment";
import { getAppointmentsByMonth } from "../../../actions/appointments";

function CalendarContainerVAD(props) {
  var today = new Date();
  var date =
    today.getFullYear() + "-" + (today.getMonth() + 1) + "-" + today.getDate();
  const {
    selectCalendarVAD,
    doctors,
    patients,
    settings,
    etablissement,
    agendas,
  } = props;
  const classes = useStyles();
  const connectedUser = JSON.parse(localStorage.getItem("profile"))?.user;
  const { appointments } = useSelector((state) => state.appointments);

  const [currentDate, setCurrentDate] = useState(date ? date : "2022-01-01");
  const [selectedPatient, setSelectedPatient] = useState(null);
  const dispatch = useDispatch();
  const [state, setState] = useState({
    types: [],
    data: [],
    selectedAppointment: null,
    selectedResa: null,
    selectedPatient: null,
    selectedTime: null,
    deleteAppointmentConfirmation: false,
    showActionsModal: false,
    openAddResa: false,
    confirmDeleteResa: false,
    extendForm: false,
    rdvsForm: false,
  });

  const [formData, setFormData] = useState({
    createdAt: null,
    isNewRdv: true,
    multipleDates: null,
    id: null,
    createdBy: connectedUser._id,
    doctor: null,
    patient: "",
    start: null,
    duration: 0,
    type: "",
    motif: "",
    notes: "",
    status: "Attente",
    celluleId: null,
  });

  const handleSetFormData = (data) => {
    setFormData({
      ...formData,
      createdAt: moment(data.createdAt).format("DD-MM-YYYY").replace("T", " "),
      isNewRdv: true,
      multipleDates: null,
      id: null,
      patient: "",
      motif: "",
      doctor: data.doctor,
      start: data.start,
      duration: data.duration,
      type: data.type,
      celluleId: data.celluleId,
    });
    setState({ ...state, rdvsForm: true });
  };

  const handleSelectAppointment = (data) => {
    const selected = appointments?.find((app) => app._id === data);
    setFormData({
      ...formData,
      isNewRdv: false,
      multipleDates: null,
      id: data,
      createdBy: connectedUser._id,
      doctor: selected.doctor,
      patient: selected.patient,
      start: selected.start,
      duration: selected.duration,
      type: selected.type,
      motif: selected.motif,
      notes: selected.notes,
      status: selected.status,
      celluleId: selected.celluleId,
      createdAt: moment(selected.createdAt)
        .format("DD-MM-YYYY")
        .replace("T", " "),
    });
    setState({ ...state, rdvsForm: true });
  };
  const handleConfirmDeleteAppointment = (data) => {
    setState({
      ...state,
      selectedAppointment: appointments.find((app) => app._id === data),
      selectedResa: data,
      deleteAppointmentConfirmation: true,
    });
  };

  const handleSelectResaData = (data) => {
    setState({ ...state, selectedResa: data, openAddResa: true });
  };

  const handleConfirmDeleteResa = (data) => {
    setState({ ...state, selectedResa: data, confirmDeleteResa: true });
  };

  const handleAddResa = (data) => {
    setState({
      ...state,
      selectedTime: data.date,
      selectedResa: null,
      openAddResa: true, // Open Add Reservation doesnt work and showing error message after deleting the old reservation
    });
  };

  const handleChangeCurrentDate = (data) => {
    setCurrentDate(data);
  };

  const handleSelectPatient = (data) => {
    setSelectedPatient(data);
  };

  useEffect(() => {
    if (selectedPatient) {
      setState({ ...state, selectedPatient: selectedPatient });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedPatient]);

  const handleExtendForm = () => {
    setState({ ...state, extendForm: !state.extendForm });
  };

  // get Resas by agendas
  /*  useEffect(() => {
        if (agendas && agendas.length > 0) {
            let ids = [];
            if (agendas?.length > 0) {
            agendas?.forEach(agenda => {
                ids.push(agenda._id);
            })
            }
          dispatch(getResasByAgendas(ids));
        }
      }, [agendas, dispatch]) */

  // Get resa by month
  useEffect(() => {
    if (currentDate) {
      dispatch(getResasByMonth(moment(currentDate).format("YYYY-MM-DD")));
      dispatch(
        getAppointmentsByMonth(moment(currentDate).format("YYYY-MM-DD"))
      );
    }
  }, [currentDate, dispatch]);
  const removedValues = [
    "Salle",
    "Cabine",
    "NP",
    "URG",
    "Sur+Salle",
    "Perso-PH",
    "Perso-Sa",
  ];
  // Set Data from DB

  useEffect(() => {
    if (appointments && appointments.length > 0) {
      setState({
        ...state,
        data: appointments?.filter(
          (appointment) =>
            appointment.status !== "Annuler" && appointment.type.match("VAD")
        ),
      });
    }

    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [appointments]);

  // get types by agendas
  useEffect(() => {
    // WE MUST HAVE A LOOP HERE TO MAP ALL AGENDA TEMPLATE TABLES INTO TYPES AND PUSH THEM TO ADDRESA COMPONENT THAT WAY WE GET THE SAME COLOR IN EVERY RESA AS AGENDA TYPE CONSULTATION TYPE

    if (agendas?.length > 0) {
      var types = [];
      // eslint-disable-next-line array-callback-return
      agendas
        ?.filter((ag) => ag !== undefined)
        ?.map((agenda) => {
          if (agenda?.template?.table) {
            // eslint-disable-next-line array-callback-return
            agenda?.template?.table?.map((consultation) => {
              if (
                types?.filter(
                  (cs) =>
                    cs.type?.toLowerCase()?.trim() ===
                    consultation.type?.toLowerCase()?.trim()
                )?.length === 0
              ) {
                types?.push({
                  type: consultation.type,
                  color: consultation.color,
                  doctor: doctors?.find((doc) =>
                    doc.agendas.includes(agenda._id)
                  )?.user?.name,
                  doctorId: doctors?.find((doc) =>
                    doc.agendas.includes(agenda._id)
                  )?._id,
                });
              }

              console.log(agenda);
            });
          } else {
            // eslint-disable-next-line array-callback-return

            agenda?.consultationsTypes?.map((consultation) => {
              if (
                types?.filter(
                  (cs) =>
                    cs.type?.toLowerCase()?.trim() ===
                    consultation?.toLowerCase()?.trim()
                )?.length === 0
              ) {
                types?.push({
                  type: consultation,
                });
              }
            });
          }
        });

      setState({ ...state, types: types });
      console.log(types);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [agendas, doctors]);

  // Select Calendar Tab
  useEffect(selectCalendarVAD, [selectCalendarVAD]);

  return (
    <Paper>
      <Grid container>
        <Grid item xs={10}>
          <Calendar
            myData={state.data}
            doctors={doctors}
            patients={patients}
            settings={settings}
            etablissement={etablissement}
            agendas={agendas}
            typesByEtab={state.types}
            handleSelectAppointment={(data) => handleSelectAppointment(data)}
            handleSetFormData={(data) => handleSetFormData(data)}
            handleConfirmDeleteAppointment={(data) =>
              handleConfirmDeleteAppointment(data)
            }
            handleSelectResaData={(data) => handleSelectResaData(data)}
            handleAddResa={(data) => handleAddResa(data)}
            handleConfirmDeleteResa={(data) => handleConfirmDeleteResa(data)}
            handleChangeCurrentDate={(data) => handleChangeCurrentDate(data)}
          />
        </Grid>
        <Grid item xs={2}>
          <FilterContainer
            currentDate={currentDate}
            typesByEtab={state.types}
          />
        </Grid>
      </Grid>
      <DialogDeleteAppointment
        open={state.deleteAppointmentConfirmation}
        close={() =>
          setState({ ...state, deleteAppointmentConfirmation: false })
        }
        selectedAppointment={state.selectedAppointment}
        connectedUser={connectedUser}
      />
      <DialogActionsSelect
        open={state.showActionsModal}
        close={() => setState({ ...state, showActionsModal: false })}
      />
      <DialogDeleteResa
        open={state.confirmDeleteResa}
        close={() => setState({ ...state, confirmDeleteResa: false })}
        selectedResa={state.selectedResa}
      />
      <Dialog
        maxWidth={state.extendForm ? "lg" : "sm"}
        open={state.rdvsForm}
        onClose={() => setState({ ...state, rdvsForm: false })}
        style={{ transition: "all 0.6s ease-in-out" }}
        aria-labelledby="form-dialog-title"
      >
        <div
          style={
            state.extendForm
              ? {
                  display: "flex",
                  margin: "auto",
                  transition: "all 0.6s ease-in-out",
                }
              : {
                  display: "block",
                  margin: "auto",
                  transition: "all 0.6s ease-in-out",
                }
          }
        >
          <Paper
            className={classes.paper}
            style={state.extendForm ? { width: "50%" } : { width: "100%" }}
          >
            <AddAppointment
              appointment={null}
              calendarForm={formData}
              show={state.rdvsForm}
              close={() => setState({ ...state, rdvsForm: false })}
              connectedUser={connectedUser}
              doctorsByEtab={doctors}
              handleSetSelectedPatient={(data) => handleSelectPatient(data)}
              handleExtendForm={() => handleExtendForm()}
              extendForm={state.extendForm}
              agendas={agendas}
            />
          </Paper>
          <Paper
            className={classes.paper}
            style={state.extendForm ? { width: "50%" } : { width: "100%" }}
          >
            <AddPatient
              patient={selectedPatient}
              show={state.extendForm}
              close={() => setState({ ...state, extendForm: false })}
              doctorsByEtab={doctors}
              etablissement={etablissement}
            />
          </Paper>
        </div>
      </Dialog>
      <Dialog
        maxWidth={"sm"}
        open={state.openAddResa}
        onClose={() => setState({ ...state, openAddResa: false })}
        style={{ transition: "all 0.4s ease-in-out" }}
        aria-labelledby="form-dialog-title"
      >
        <div
          style={{
            display: "block",
            margin: "auto",
            transition: "all 0.4s ease-in-out",
          }}
        >
          <Paper className={classes.paper} style={{ width: "100%" }}>
            <AddResa
              resa={state.selectedResa}
              show={state.openAddResa}
              close={() => setState({ ...state, openAddResa: false })}
              doctorsByEtab={doctors}
              agendas={agendas}
              startTime={state.selectedTime}
              types={state.types}
            />
          </Paper>
        </div>
      </Dialog>
    </Paper>
  );
}

export default CalendarContainerVAD;
