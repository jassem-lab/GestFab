import {
  Button,
  Checkbox,
  Chip,
  FormControlLabel,
  Paper,
  TextField,
} from "@material-ui/core";
import { Autocomplete, TreeItem, TreeView } from "@material-ui/lab";
import ExpandMoreIcon from "@material-ui/icons/ExpandMore";
import ChevronRightIcon from "@material-ui/icons/ChevronRight";
import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import useStyles from "./style";
import DialogScheduleAppointments from "./DialogScheduleAppointments";
import { fetchUpcomingFreeResas } from "../../../api";
import { getResasByMonth } from "../../../actions/resas";
import moment from "moment";
import { getAppointmentsByMonth } from "../../../actions/appointments";

function FilterContainer(props) {
  const { typesByEtab, currentDate } = props;
  const classes = useStyles();
  const dispatch = useDispatch();

  // Get Data From Redux store

  const { agendas } = useSelector((state) => state.agendas);
  const { doctors, doctorsMap } = useSelector((state) => state.doctors);
  const { patients } = useSelector((state) => state.patients);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [freeResasLoading, setFreeResasLoading] = useState(false);
  const [freeResas, setFreeResas] = useState({});
  const [selectedResas, setSelectedResas] = useState({});
  const [resasFilterData, setResasFilterData] = useState({
    types: [],
    patient: undefined,
    patientName: undefined,
    doctors: [],
  });

  useEffect(() => {
    if (resasFilterData.doctors.length && resasFilterData.types.length) {
      setFreeResasLoading(true);
      fetchUpcomingFreeResas(resasFilterData).then((response) => {
        setFreeResas(
          response.data.reduce((prev, curr) => {
            const [date] = curr.start.split("T");

            return {
              ...prev,
              [date]: [...(prev?.[date] ?? []), curr],
            };
          }, {})
        );
        setFreeResasLoading(false);
     
      });
    } else {
      setFreeResas({});
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [resasFilterData]);

  const getTypeColor = (type) =>
    typesByEtab.find((t) => t.type === type)?.color ?? "#fff";

  const handleDoctorsSelected = (_, value) =>
    setResasFilterData({
      ...resasFilterData,
      doctors: value.map((doctor) => doctor._id),
    });

  const handlePatientSelected = (_, value) =>
    setResasFilterData({
      ...resasFilterData,
      patient: value?._id,
      patientName: value?.user?.name,
    });

  const handleTypesSelected = (_, value) =>
    setResasFilterData({
      ...resasFilterData,
      types: value.map((type) => type.type),
    });

  const handleResaSelected =
    (resa) =>
    ({ target: { checked } }) => {
      if (checked) {
        selectedResas[resa._id] = resa;
      } else {
        delete selectedResas[resa._id];
      }
      setSelectedResas({ ...selectedResas });
    };

  const clearAll = () => {
    setResasFilterData({
      types: [],
      patient: undefined,
      patientName: undefined,
      doctors: [],
    });
    setFreeResas([]);
  };

  const handleOnCloseScheduleAppointments = () => {
    setDialogOpen(false);
    clearAll();
    dispatch(getResasByMonth(moment(currentDate).format("YYYY-MM-DD")));
    dispatch(getAppointmentsByMonth(moment(currentDate).format("YYYY-MM-DD")));
  };
  const removedValues = [
    "Salle",
    "Cabine",
    "NP",
    "URG",
    "Sur+Salle",
    "Perso-PH",
    "Perso-Sa",
  ];
  return (
    <Paper className={classes.filterContainer}>
      <h3 className={classes.filterTitle}>Filter</h3>
      <div>
        <Autocomplete
          options={doctors}
          getOptionLabel={(doctor) => doctor.user?.name}
          value={doctors.filter((doctor) =>
            resasFilterData.doctors.includes(doctor._id)
          )}
          renderInput={(params) => (
            <TextField {...params} placeholder="Filtrer par médecins" />
          )}
          multiple
          onChange={handleDoctorsSelected}
          disabled={freeResasLoading}
        />
        <span
          style={{
            marginTop: "5px",
            color: "#444",
            display: "block",
            fontSize: "12px",
          }}
        >
          Filtrer par médecins
        </span>
      </div>
      <div>
        <Autocomplete
          options={patients}
          getOptionLabel={(patient) => patient.user?.name}
          value={
            patients.find(
              (patient) => resasFilterData.patient === patient._id
            ) ?? null
          }
          renderInput={(params) => (
            <TextField {...params} placeholder="Filtrer par nom de patient" />
          )}
          disabled={freeResasLoading}
          onChange={handlePatientSelected}
        />
        <span
          style={{
            marginTop: "5px",
            color: "#444",
            display: "block",
            fontSize: "12px",
          }}
        >
          Filtrer par nom de patient
        </span>
      </div>
      <div>
        <Autocomplete
          options={typesByEtab.filter((type) => type.type.match("VAD"))}
          getOptionLabel={(type) => type.type}
          value={typesByEtab?.filter((type) =>
            resasFilterData.types.includes(type.type)
          )}
          renderInput={(params) => (
            <TextField {...params} placeholder="Filtrer par types" />
          )}
          multiple
          disabled={freeResasLoading}
          onChange={handleTypesSelected}
          renderTags={(values, getTagProps) =>
            values.map((value, index) => (
              <Chip
                key={index}
                label={value.type}
                onDelete={getTagProps({ index }).onDelete}
                style={{ margin: "0.2rem", backgroundColor: value.color }}
                disabled={freeResasLoading}
              />
            ))
          }
        />
        <span
          style={{
            marginTop: "5px",
            color: "#444",
            display: "block",
            fontSize: "12px",
          }}
        >
          Filtrer par type
        </span>
      </div>
      <Button
        disabled={
          freeResasLoading ||
          !Object.keys(selectedResas).length ||
          !resasFilterData.patient
        }
        variant="contained"
        color="primary"
        onClick={() => setDialogOpen(true)}
      >
        Ajouter
      </Button>
      <Button variant="contained" color="default" onClick={clearAll}>
        Effacer les filtres
      </Button>
      <div>
        <TreeView
          defaultCollapseIcon={<ExpandMoreIcon />}
          defaultExpandIcon={<ChevronRightIcon />}
        >
          {Object.entries(freeResas).map(([date, resas]) => (
            <TreeItem nodeId={date} label={date}>
              {resas.map((resa) => {
                const [, time] = resa.start.split("T");
                const doctorName =
                  doctorsMap[resa.doctor]?.user?.name?.split(" ") ?? [];
                doctorName.pop();

                return (
                  <TreeItem
                    className={classes.resaType}
                    style={{ backgroundColor: getTypeColor(resa.type) }}
                    nodeId={resa._id}
                    label={
                      <FormControlLabel
                        control={
                          <Checkbox
                            checked={!!selectedResas[resa._id]}
                            onChange={handleResaSelected(resa)}
                          />
                        }
                        label={
                          <div>
                            {resa.type} à {time} avec {doctorName.join(" ")}
                          </div>
                        }
                      />
                    }
                  />
                );
              })}
            </TreeItem>
          ))}
        </TreeView>
      </div>
      <DialogScheduleAppointments
        open={dialogOpen}
        close={handleOnCloseScheduleAppointments}
        resas={Object.values(selectedResas)}
        patientId={resasFilterData.patient}
        patientName={resasFilterData.patientName}
      />
    </Paper>
  );
}

export default FilterContainer;
