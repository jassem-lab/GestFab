import {
  IconButton,
  makeStyles,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TextField,
  Tooltip,
} from "@material-ui/core";
import React, { useEffect, useState } from "react";
import ClearIcon from "@material-ui/icons/Clear";
import DeleteIcon from "@material-ui/icons/Delete";
import ArrowDropDownIcon from "@material-ui/icons/ArrowDropDown";
import AddBoxIcon from "@material-ui/icons/AddBox";
import EditIcon from "@material-ui/icons/Edit";
import DeleteForeverIcon from "@material-ui/icons/DeleteForever";
import UpdateClockIcon from "@material-ui/icons/Update";
import HelpOutlineIcon from "@material-ui/icons/HelpOutline";
import { useDispatch, useSelector } from "react-redux";
import moment from "moment";
import { Autocomplete, Pagination } from "@material-ui/lab";
import { DatePicker } from "@material-ui/pickers";
import { filterEvents } from "../../../actions/events";
import { ListUsers } from "../../../actions/users";
import PublicIcon from "@material-ui/icons/Public";
import FaceIcon from "@material-ui/icons/Face";
import PersonIcon from "@material-ui/icons/Person";

const useStyles = makeStyles((theme) => ({
  iconButton: {
    margin: 5,
  },
  flex: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    padding: "10px 20px",
  },
  searchBar: {
    minWidth: "200px",
    margin: "0 10px",
  },
  datePicker: {
    width: "200px",
    margin: "0 10px",
  },
  appointmentType: {
    padding: "7px 10px",
    borderRadius: "30px",
    boxShadow: "0px 0px 5px rgba(0,0,0,0.15)",
    fontSize: "0.8rem",
    fontWeight: "bold",
    opacity: 0.8,
  },
  eventType: {
    display: "flex",
    gap: ".5rem",
    justifyContent: "center",
  },
}));

const eventTypes = {
  CREATE: {
    text: "Ajouté",
    Icon: AddBoxIcon,
    color: "#4caf50",
  },
  TRANSFER: {
    text: "Reporté",
    Icon: UpdateClockIcon,
    color: "#2196f3",
  },
  UPDATE: {
    text: "Modifié",
    Icon: EditIcon,
    color: "#ff9800",
  },
  CANCEL: {
    text: "Annulé",
    Icon: DeleteForeverIcon,
    color: "#f44336",
  },
  DELETE: {
    text: "Supprimé",
    Icon: DeleteForeverIcon,
    color: "#f44336",
  },
};

export default function Events(props) {
  const { selectEvents } = props;
  const classes = useStyles();
  const dispatch = useDispatch();
  const { patients } = useSelector((state) => state.patients);
  const { doctors } = useSelector((state) => state.doctors);

  const { events, numberOfPages, EventsIsLoading } = useSelector(
    (state) => state.events
  );
  const [filterData, setFilterData] = useState({
    page: 0,
    patientId: undefined,
    doctorId: undefined,
    startDate: null,
    endDate: null,
  });

  useEffect(selectEvents, [selectEvents]);

  useEffect(() => {
    if (filterData.page >= numberOfPages) {
      setFilterData((filterData) => ({ ...filterData, page: 0 }));
    }
  }, [numberOfPages, filterData.page]);

  useEffect(() => {
    dispatch(ListUsers());
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    dispatch(filterEvents(filterData));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [filterData]);

  const handlePatientChanged = (_, value) =>
    setFilterData({ ...filterData, page: 0, patientId: value?._id });

  const handleDoctorChanged = (_, value) =>
    setFilterData({ ...filterData, page: 0, doctorId: value?._id });

  const handleDateChanged = (field) => (value) =>
    setFilterData({
      ...filterData,
      page: 0,
      [field]: value && moment(value).format("YYYY-MM-DD"),
    });

  const handleClearDate = (field) => (event) => {
    event.stopPropagation();
    handleDateChanged(field)(null);
  };

  const handlePageChanged = (_, newPage) =>
    setFilterData({ ...filterData, page: newPage - 1 });

  return (
    <Paper sx={{ width: "100%", overflow: "hidden" }}>
      <div className="noprint">
        <div className={classes.flex}>
          <h5 style={{ fontSize: "18px" }}>Journal des événements</h5>
        </div>
        <div className={classes.flex}>
          <div className={classes.flex}></div>
          <div className={classes.flex} style={{ justifyContent: "flex-end" }}>
            {
              <div className={classes.searchBar}>
                <Autocomplete
                  options={patients}
                  getOptionLabel={(item) => item.user?.name}
                  renderInput={(params) => (
                    <TextField {...params} placeholder="Tous les patients" />
                  )}
                  onChange={handlePatientChanged}
                />
                <span
                  style={{
                    marginTop: "5px",
                    color: "#444",
                    display: "block",
                    fontSize: "12px",
                  }}
                >
                  Filtrer par patient
                </span>
              </div>
            }
            {
              <div className={classes.searchBar}>
                <Autocomplete
                  options={doctors}
                  getOptionLabel={(item) => item.user?.name}
                  renderInput={(params) => (
                    <TextField {...params} placeholder="Tous les medecins" />
                  )}
                  onChange={handleDoctorChanged}
                />
                <span
                  style={{
                    marginTop: "5px",
                    color: "#444",
                    display: "block",
                    fontSize: "12px",
                  }}
                >
                  Filtrer par medecin
                </span>
              </div>
            }
            <div className={classes.datePicker}>
              <DatePicker
                disableToolbar
                variant="inline"
                emptyLabel="Start Date"
                format="dd/MM/yyyy"
                value={filterData.startDate}
                onChange={handleDateChanged("startDate")}
                InputProps={{
                  endAdornment: filterData.startDate ? (
                    <IconButton
                      size="small"
                      onClick={handleClearDate("startDate")}
                    >
                      <ClearIcon />
                    </IconButton>
                  ) : (
                    <IconButton size="small">
                      <ArrowDropDownIcon />
                    </IconButton>
                  ),
                }}
              />
              <span
                style={{
                  marginTop: "5px",
                  color: "#444",
                  display: "block",
                  fontSize: "12px",
                }}
              >
                Filtrer par date
              </span>
            </div>
            <div className={classes.datePicker}>
              <DatePicker
                disableToolbar
                variant="inline"
                emptyLabel="End Date"
                format="dd/MM/yyyy"
                value={filterData.endDate}
                onChange={handleDateChanged("endDate")}
                InputProps={{
                  endAdornment: filterData.endDate ? (
                    <IconButton
                      size="small"
                      onClick={handleClearDate("endDate")}
                    >
                      <ClearIcon />
                    </IconButton>
                  ) : (
                    <IconButton size="small">
                      <ArrowDropDownIcon />
                    </IconButton>
                  ),
                }}
              />
              <span
                style={{
                  marginTop: "5px",
                  color: "#444",
                  display: "block",
                  fontSize: "12px",
                }}
              >
                Filtrer par interval de date
              </span>
            </div>
            <IconButton
              color="primary"
              aria-label="restore"
              className={classes.iconButton}
              onClick={() =>
                setFilterData({ page: 0, startDate: null, endDate: null })
              }
            >
              <DeleteIcon
                style={
                  filterData.showCanceled
                    ? { color: "#080" }
                    : { color: "#444" }
                }
              />
            </IconButton>
          </div>
        </div>
        <TableContainer sx={{ maxHeight: 440 }}>
          <Table stickyHeader aria-label="sticky table">
            <TableHead>
              <TableRow>
                <TableCell align="center">Date de modification</TableCell>
                <TableCell>Heure</TableCell>
                <TableCell>Patient</TableCell>
                <TableCell>Docteur</TableCell>
                <TableCell align="center">Consultation</TableCell>
                <TableCell align="center">Acteur</TableCell>
                <TableCell align="center">Motif</TableCell>
                <TableCell align="center">Notes</TableCell>
                <TableCell align="center">Type</TableCell>
                <TableCell>Date</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {events && !EventsIsLoading
                ? events.map((event) => {
                    const { Icon, color, text } = eventTypes[
                      event.eventType ?? event.type
                    ] ?? {
                      Icon: HelpOutlineIcon,
                      color: "grey",
                      text: "Inconnue",
                    };

                    if (!event.actorName) {
                      event.actorName = event.actor?.name;
                    }

                    if (!event.actorRole) {
                      event.actorRole = event.actor?.role;
                    }
                    return (
                      <TableRow key={event._id}>
                        {event.description ? (
                          <TableCell colSpan={5}>
                            <b>Description: </b>
                            {event.description}
                          </TableCell>
                        ) : (
                          <>
                            <TableCell align="center">
                              {moment(event.createdAt)?.format(
                                "DD/MM/YYYY [à] HH:mm"
                              )}
                            </TableCell>

                            <TableCell>
                              {moment(event.appointmentDate)?.format("HH:mm")}
                            </TableCell>
                            <TableCell>{event.patientName}</TableCell>
                            <TableCell>{event.doctorName}</TableCell>
                            <TableCell align="center">
                              <span
                                className={classes.appointmentType}
                                style={{
                                  background: event.appointmentTypeColor,
                                }}
                              >
                                {event.appointmentType}
                              </span>
                            </TableCell>
                          </>
                        )}
                        <TableCell align="center">
                          {event.actorRole === "patient" ? (
                            <Tooltip
                              title={`Internet @${event.actorName}`}
                              placement="bottom"
                            >
                              <PublicIcon />
                            </Tooltip>
                          ) : event.actorRole === "client" ? (
                            <Tooltip
                              title={`Docteur @${event.actorName}`}
                              placement="bottom"
                            >
                              <FaceIcon />
                            </Tooltip>
                          ) : event.actorRole === "admin" ? (
                            <Tooltip
                              title={`Admin @${event.actorName}`}
                              placement="bottom"
                            >
                              <PersonIcon />
                            </Tooltip>
                          ) : (
                            <span>{event.actorName}</span>
                          )}
                        </TableCell>
                        <TableCell>{event.motif}</TableCell>

                        <TableCell>{event.notes}</TableCell>
                        <TableCell>
                          <div className={classes.eventType} style={{ color }}>
                            <Icon />
                            {text}
                          </div>
                        </TableCell>
                        <TableCell>
                          {moment(event.appointmentDate)?.format("DD/MM/YYYY")}
                        </TableCell>
                      </TableRow>
                    );
                  })
                : null}
            </TableBody>
          </Table>
        </TableContainer>
        <Pagination
          style={{
            display: "flex",
            justifyContent: "center",
            margin: "auto",
            padding: "30px",
          }}
          page={filterData.page + 1}
          count={numberOfPages}
          onChange={handlePageChanged}
        />
        {EventsIsLoading ? (
          <div
            style={{
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
              height: "100px",
            }}
          >
            <img
              width={60}
              height={60}
              src="/images/loading-36.gif"
              alt="loading"
            />
          </div>
        ) : (
          !events?.length && (
            <div
              style={{
                display: "flex",
                justifyContent: "center",
                alignItems: "center",
                height: "100px",
              }}
            >
              Pas d'événements
            </div>
          )
        )}
      </div>
    </Paper>
  );
}
