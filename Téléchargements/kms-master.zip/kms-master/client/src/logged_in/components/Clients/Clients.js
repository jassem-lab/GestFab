import React, { useEffect } from "react";

export default function Clients(props) {
  const { selectClients } = props;

  useEffect(selectClients, [selectClients]);

  return <div></div>;
}
