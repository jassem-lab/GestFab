import {
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  DialogContentText,
  DialogTitle,
  IconButton,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TextField,
} from "@material-ui/core";
import React, { useEffect, useState } from "react";
import AddIcon from "@material-ui/icons/Add";
import EditIcon from "@material-ui/icons/Edit";
import DeleteForeverIcon from "@material-ui/icons/DeleteForever";
import {
  deletePatient,
  blockPatient,
  filterPatients,
} from "../../../actions/patients";
import { useDispatch, useSelector } from "react-redux";
import AddPatient from "./AddPatient";
import BlockIcon from "@material-ui/icons/Block";
import FichePatient from "./FichePatient";
import RestoreIcon from "@material-ui/icons/Restore";
import FiberManualRecordIcon from "@material-ui/icons/FiberManualRecord";
import moment from "moment";
import useStyles from "./style";
import { Pagination } from "@material-ui/lab";

export default function Patients(props) {
  const { selectPatients, etablissement } = props;
  const dispatch = useDispatch();
  const { patientsPage, numberOfPages, PatientsIsLoading } = useSelector(
    (state) => state.patients
  );

  const [showAddPatient, setShowAddPatient] = useState(false);
  const [selectedPatient, setSelectedPatient] = useState(null);
  const [deletePatientConfirmation, setDeletePatientConfirmation] =
    useState(false);
  const [blockPatientConfirmation, setBlockPatientConfirmation] =
    useState(false);
  const classes = useStyles();
  const [ficheOpen, setFicheOpen] = useState(false);
  const [filterData, setFilterData] = useState({
    page: 0,
    search: "",
    phone: "",
  });
  useEffect(selectPatients, [selectPatients]);

  useEffect(() => {
    if (filterData.page && filterData.page >= numberOfPages) {
      setFilterData((filterData) => ({ ...filterData, page: 0 }));
    }
  }, [numberOfPages, filterData.page]);

  useEffect(() => {
    dispatch(filterPatients(filterData));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [filterData]);

  const handleClickOpen = () => {
    setSelectedPatient(null);
    setShowAddPatient(true);
  };

  const handleClose = () => {
    setShowAddPatient(false);
  };

  const handleDeletePatient = () => {
    dispatch(deletePatient(selectedPatient._id));
    setDeletePatientConfirmation(false);
  };

  const handleBlockPatient = () => {
    dispatch(blockPatient(selectedPatient._id, !selectedPatient.blacklist));
    setBlockPatientConfirmation(false);
  };

  const fichePatient = (patient) => {
    setSelectedPatient(patient);
    setFicheOpen(true);
  };

  const handleSearch = (event) =>
    setFilterData({ page: 0, search: event.target.value });
  const handleSearchPhone = (event) =>
    setFilterData({ page: 0, phone: event.target.value });
  const handlePageChanged = (_, newPage) =>
    setFilterData({ ...filterData, page: newPage - 1 });

  return (
    <Paper sx={{ width: "100%", overflow: "hidden" }}>
      <div className={classes.flex}>
        <h5 style={{ fontSize: "18px" }}>
          Patients de :
          <strong style={{ color: "rgb(72,41,178)" }}>
            &nbsp;{etablissement?.name}
          </strong>
        </h5>
        <IconButton
          color="primary"
          aria-label="add"
          className={classes.iconButton}
          onClick={handleClickOpen}
        >
          <AddIcon />
        </IconButton>
      </div>
      <div className={classes.flex}>
        <div>
          <TextField
            value={filterData.search}
            onChange={handleSearch}
            label="Recherche patient"
            className={classes.searchBar}
            style={{ marginRight: "20px" }}
          />
          <TextField
            value={filterData.phone}
            onChange={handleSearchPhone}
            label="Recherche téléphone"
            className={classes.searchBar}
          />
        </div>
      </div>
      <TableContainer sx={{ maxHeight: 440 }}>
        <Table stickyHeader aria-label="sticky table">
          <TableHead>
            <TableRow>
              <TableCell>Genre</TableCell>
              <TableCell>Nom</TableCell>
              <TableCell>Email</TableCell>
              <TableCell>Age</TableCell>
              <TableCell>Télephone</TableCell>
              <TableCell>Rdv. Int.</TableCell>
              <TableCell>Actions</TableCell>
            </TableRow>
          </TableHead>

          <TableBody>
            {!PatientsIsLoading &&
              patientsPage?.map((patient) => (
                <TableRow
                  key={patient._id}
                  className={patient.blacklist ? classes.gray : classes.white}
                  onClick={() => fichePatient(patient)}
                >
                  <TableCell>{patient.user?.gender}</TableCell>
                  <TableCell>{patient.user?.name}</TableCell>
                  <TableCell style={{ fontSize: "12px" }}>
                    {patient.user?.email}
                  </TableCell>
                  <TableCell>
                    {moment(patient.birthday).isValid()
                      ? moment().diff(patient.birthday, "years")
                      : "-"}
                  </TableCell>
                  <TableCell>{patient.user?.phone}</TableCell>
                  <TableCell>
                    {patient.rdv ? (
                      <FiberManualRecordIcon style={{ color: "green" }} />
                    ) : (
                      <FiberManualRecordIcon style={{ color: "red" }} />
                    )}
                  </TableCell>
                  <TableCell>
                    <EditIcon
                      onClick={(e) => {
                        e.stopPropagation();
                        setSelectedPatient(patient);
                        setShowAddPatient(true);
                      }}
                      style={{ color: "#1bb719", cursor: "pointer" }}
                    />
                    <DeleteForeverIcon
                      onClick={(e) => {
                        e.stopPropagation();
                        setSelectedPatient(patient);
                        setDeletePatientConfirmation(true);
                      }}
                      style={{ color: "#b54827", cursor: "pointer" }}
                    />
                    {patient.blacklist ? (
                      <RestoreIcon
                        onClick={(e) => {
                          e.stopPropagation();
                          dispatch(
                            blockPatient(patient._id, !patient.blacklist)
                          );
                        }}
                        style={{ cursor: "pointer" }}
                      />
                    ) : (
                      <BlockIcon
                        onClick={(e) => {
                          e.stopPropagation();
                          setSelectedPatient(patient);
                          setBlockPatientConfirmation(true);
                        }}
                        style={{ cursor: "pointer" }}
                      />
                    )}
                  </TableCell>
                </TableRow>
              ))}
          </TableBody>
        </Table>
        <Pagination
          style={{
            display: "flex",
            justifyContent: "center",
            margin: "auto",
            padding: "30px",
          }}
          page={filterData.page + 1}
          count={numberOfPages}
          onChange={handlePageChanged}
        />
      </TableContainer>
      {PatientsIsLoading ? (
        <div
          style={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            height: "100px",
          }}
        >
          <img
            width={60}
            height={60}
            src="/images/loading-36.gif"
            alt="loading"
          />
        </div>
      ) : (
        !patientsPage?.length && (
          <div
            style={{
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
              height: "100px",
            }}
          >
            Pas de patient
          </div>
        )
      )}
      <Dialog
        open={showAddPatient}
        onClose={() => setShowAddPatient(false)}
        aria-labelledby="form-dialog-title"
      >
        <Paper className={classes.paper}>
          <AddPatient
            patient={selectedPatient}
            show={showAddPatient}
            close={handleClose}
            etablissement={etablissement}
          />
        </Paper>
      </Dialog>
      <Dialog
        open={deletePatientConfirmation}
        onClose={() => setDeletePatientConfirmation(false)}
        aria-labelledby="patient-title"
        aria-describedby="patient-description"
      >
        <DialogTitle id="patient-title">{"Supprimer un patient ?"}</DialogTitle>
        <DialogContent>
          <DialogContentText id="patient-description">
            Êtes-vous sûr de supprimer ce patient ?
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button
            onClick={() => setDeletePatientConfirmation(false)}
            color="primary"
          >
            Annuler
          </Button>
          <Button onClick={handleDeletePatient} color="primary" autoFocus>
            Supprimer
          </Button>
        </DialogActions>
      </Dialog>
      <Dialog
        open={blockPatientConfirmation}
        onClose={() => setBlockPatientConfirmation(false)}
        aria-labelledby="patient-title"
        aria-describedby="patient-description"
      >
        <DialogTitle id="patient-title">{"Bloquer un patient ?"}</DialogTitle>
        <DialogContent>
          <DialogContentText id="patient-description">
            Êtes-vous sûr de bloquer ce patient ?
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button
            onClick={() => setBlockPatientConfirmation(false)}
            color="primary"
          >
            Annuler
          </Button>
          <Button onClick={handleBlockPatient} color="primary" autoFocus>
            Bloquer
          </Button>
        </DialogActions>
      </Dialog>
      <FichePatient
        showMe={ficheOpen}
        patient={selectedPatient}
        closeMe={() => setFicheOpen(false)}
      />
    </Paper>
  );
}
