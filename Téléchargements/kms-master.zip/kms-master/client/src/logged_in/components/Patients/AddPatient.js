import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import {
  Divider,
  Grid,
  makeStyles,
  TextField,
  Typography,
  Button,
  FormControl,
  MenuItem,
  Select,
} from "@material-ui/core";
import { createPatient, editPatient } from "../../../actions/patients";
import InputLabel from "@material-ui/core/InputLabel";

const useStyles = makeStyles((theme) => ({
  formControl: {
    minWidth: 120,
    height: 20,
  },
  saveButton: {
    paddingTop: 10,
  },
  loading: {
    width: "20px",
    marginLeft: "10px",
  },
  divider: {
    marginTop: "30px",
  },
  green: {
    background: "#080",
  },
  gray: {
    background: "#777",
  },
  rowContainer: {
    display: "flex",
    alignItems: "center",
  },
  input: {
    marginRight: "5%",
    width: "65%",
  },
  label: {
    width: "30%",
    paddingTop: "5px",
  },
}));

export default function AddPatient(props) {
  const { patient, show, etablissement } = props;
  const dispatch = useDispatch();
  const { PatientsIsLoading } = useSelector((state) => state.patients);
  const { doctor } = useSelector((state) => state.doctors);
  const classes = useStyles();
  const [feedback, setFeedback] = useState(null);

  const [formData, setFormData] = useState({
    assignedEtab: etablissement?._id,
    name: "",
    phone: "",
    email: "",
    password: "12345678",
    securityNumber: "",
    paymentCenter: "",
    birthday: "",
    fixeNumber: "",
    address: "",
    access: "",
    cp: "",
    city: "",
    information: "",
    rdv: true,
    treatingDoctor: false,
    ame: false,
    cmu: false,
    blacklist: false,
  });

  const clear = () => {
    setFormData({
      assignedEtab: etablissement?._id,
      name: "",
      phone: "",
      email: "",
      password: "12345678",
      securityNumber: "",
      paymentCenter: "",
      birthday: "",
      fixeNumber: "",
      address: "",
      access: "",
      cp: "",
      city: "",
      information: "",
      rdv: true,
      treatingDoctor: false,
      ame: false,
      cmu: false,
      blacklist: false,
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (patient) {
      dispatch(editPatient(patient._id, formData)).then(() => {
        setFeedback("Patient modifié");
      });
    } else {
      dispatch(createPatient(formData)).then(() => {
        setFeedback("Patient ajouté");
        clear();
        props.close();
      });
    }
  };


  useEffect(() => {
    if (patient) {
      setFormData({
        assignedEtab: patient.assignedEtab?._id || patient.assignedEtab,
        name: patient.user?.name,
        phone: patient.user?.phone,
        email: patient.user?.email,
        gender: patient.user.gender,
        password: "",
        securityNumber: patient.securityNumber,
        paymentCenter: patient.paymentCenter,
        birthday: patient.birthday,
        fixeNumber: patient.fixeNumber,
        address: patient.address,
        access: patient.access,
        cp: patient.cp,
        city: patient.city,
        information: patient.information,
        rdv: patient.rdv,
        treatingDoctor: patient.treatingDoctor,
        ame: patient.ame,
        cmu: patient.cmu,
        blacklist: patient.blacklist,
      });
    } else {
      clear();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [patient, doctor]);

  if (!show) return null;

  return (
    <form>
      <Grid container spacing={3} className="griditem">
        <Grid item xs={12}>
          <Typography variant="h4" style={{ marginTop: "10px" }}>
            {" "}
            {patient ? "Modification" : "Ajout"} de patient{" "}
          </Typography>
        </Grid>
        <Grid item xs={12} className={classes.rowContainer}>
          <Typography className={classes.label}> Etablissement : </Typography>
          <TextField
            fullWidth
            name="etab"
            id="etab"
            label="Etablissement"
            value={etablissement?.name}
            disabled={true}
          />
        </Grid>
        <Grid item xs={2}>
          <Select
            fullWidth
            name="Gender"
            id="patientgender"
            label="Gender"
            value={formData.gender}
            onChange={(e) =>
              setFormData({ ...formData, gender: e.target.value })
            }
          >
            <option value="Mr">Mr</option>
            <option value="Mme">Mme</option>
            <option value="Dr">Dr</option>
            <option value="Perso">Perso</option>
            <option value="Enfant">Enfant</option>
            <option value="Labo">Labo</option>
          </Select>
        </Grid>
        <Grid item xs={6}></Grid>
        <Grid item xs={6}>
          <TextField
            fullWidth
            name="name"
            id="patientname"
            label="Nom"
            value={formData.name}
            onChange={(e) => setFormData({ ...formData, name: e.target.value })}
          />
        </Grid>
        <Grid item xs={6}>
          <TextField
            fullWidth
            name="num_securite"
            id="num_securite"
            label="N. Sécurité sociale"
            value={formData.securityNumber}
            onChange={(e) =>
              setFormData({ ...formData, securityNumber: e.target.value })
            }
          />
        </Grid>
        <Grid item xs={6}>
          <Typography style={{ marginTop: "10px" }}>
            Date de naissance
          </Typography>
          <TextField
            fullWidth
            name="birthday"
            type="date"
            id="birthday"
            value={formData.birthday}
            onChange={(e) =>
              setFormData({ ...formData, birthday: e.target.value })
            }
          />
        </Grid>
        <Grid item xs={6}>
          <TextField
            autoComplete={false}
            fullWidth
            name="paymentCenter"
            id="paymentCenter"
            label="Centre payeur"
            value={formData.paymentCenter}
            onChange={(e) =>
              setFormData({ ...formData, paymentCenter: e.target.value })
            }
          />
        </Grid>
        <Divider className={classes.divider} />
        <Grid item xs={6}>
          <TextField
            fullWidth
            type="email"
            autoComplete="off"
            name="email"
            id="patientemail"
            label="E-mail"
            value={formData.email}
            onChange={(e) =>
              setFormData({ ...formData, email: e.target.value })
            }
          />
        </Grid>
        <Grid item xs={6}>
          <TextField
            fullWidth
            type="password"
            autoComplete="off"
            name="password"
            id="patientpassword"
            label="Mot de passe (defaut: 12345678)"
            value={formData.password}
            onChange={(e) =>
              setFormData({ ...formData, password: e.target.value })
            }
          />
        </Grid>
        <Grid item xs={6}>
          <TextField
            fullWidth
            name="fixeNumber"
            id="fixeNumber"
            label="Tél. fixe"
            value={formData.fixeNumber}
            onChange={(e) =>
              setFormData({ ...formData, fixeNumber: e.target.value })
            }
          />
        </Grid>
        <Grid item xs={6}>
          <TextField
            fullWidth
            name="phone"
            id="phone"
            label="Tél. mobile"
            value={formData.phone}
            onChange={(e) =>
              setFormData({ ...formData, phone: e.target.value })
            }
          />
        </Grid>
        <Divider className={classes.divider} />
        <Grid item xs={6}>
          <TextField
            fullWidth
            name="address"
            id="address"
            label="Adresse"
            value={formData.address}
            onChange={(e) =>
              setFormData({ ...formData, address: e.target.value })
            }
          />
        </Grid>
        <Grid item xs={6}>
          <TextField
            fullWidth
            name="access"
            id="access"
            label="Accès (digicode...)"
            value={formData.access}
            onChange={(e) =>
              setFormData({ ...formData, access: e.target.value })
            }
          />
        </Grid>
        <Grid item xs={6}>
          <TextField
            fullWidth
            name="cp"
            id="cp"
            label="CP"
            value={formData.cp}
            onChange={(e) => setFormData({ ...formData, cp: e.target.value })}
          />
        </Grid>
        <Grid item xs={6}>
          <TextField
            fullWidth
            name="city"
            id="city"
            label="Ville"
            value={formData.city}
            onChange={(e) => setFormData({ ...formData, city: e.target.value })}
          />
        </Grid>
        <Grid item xs={12}>
          <TextField
            multiline
            rows={4}
            fullWidth
            name="information"
            id="information"
            label="Informations, habitudes..."
            value={formData.information}
            onChange={(e) =>
              setFormData({ ...formData, information: e.target.value })
            }
          />
        </Grid>
        <Grid item xs={3}>
          <Button
            fullWidth
            name="treatingDoctor"
            id="treatingDoctor"
            onClick={(e) => {
              setFormData({
                ...formData,
                treatingDoctor: !formData.treatingDoctor,
              });
            }}
            className={formData.treatingDoctor ? classes.green : classes.gray}
          >
            Med. Trait.
          </Button>
        </Grid>
        <Grid item xs={3}>
          <Button
            fullWidth
            name="ame"
            id="ame"
            onClick={(e) => setFormData({ ...formData, ame: !formData.ame })}
            className={formData.ame ? classes.green : classes.gray}
          >
            AME
          </Button>
        </Grid>
        <Grid item xs={3}>
          <Button
            fullWidth
            name="cmu"
            id="cmu"
            onClick={(e) => setFormData({ ...formData, cmu: !formData.cmu })}
            className={formData.cmu ? classes.green : classes.gray}
          >
            CMU
          </Button>
        </Grid>
        <Grid item xs={3}>
          <Button
            fullWidth
            name="blacklist"
            id="blacklist"
            onClick={(e) =>
              setFormData({ ...formData, blacklist: !formData.blacklist })
            }
            className={formData.blacklist ? classes.green : classes.gray}
          >
            Blacklist
          </Button>
        </Grid>
        <Grid item xs={6}>
          <Button
            fullWidth
            name="rdv"
            id="rdv"
            onClick={() => setFormData({ ...formData, rdv: !formData.rdv })}
            className={formData.rdv ? classes.green : classes.gray}
          >
            Rdv. par internet
          </Button>
        </Grid>
      </Grid>

      <Button
        style={{ marginTop: "50px", marginRight: "10px" }}
        variant="contained"
        color="secondary"
        type="submit"
        onClick={(e) => handleSubmit(e)}
      >
        Enregistrer
        {PatientsIsLoading ? (
          <img
            className={classes.loading}
            src="/images/loading.gif"
            alt="Loading"
          />
        ) : null}
      </Button>
      <Button
        onClick={props.close}
        style={{ marginTop: "50px" }}
        variant="contained"
        color="primary"
      >
        Annuler
      </Button>
      {feedback ? (
        <p style={{ color: "#080", marginTop: "15px" }}>{feedback}</p>
      ) : null}
    </form>
  );
}
