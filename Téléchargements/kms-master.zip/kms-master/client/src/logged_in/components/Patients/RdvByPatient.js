import {
  Table,
  TableBody,
  TableCell,
  TableContainer,
  makeStyles,
  TableRow,
  TableHead,
  Dialog,
  Tooltip,
} from "@material-ui/core";
import { Pagination } from "@material-ui/lab";

import FaceIcon from "@material-ui/icons/Face";
import PublicIcon from "@material-ui/icons/Public";
import PersonIcon from "@material-ui/icons/Person";
import moment from "moment";

import React, { useEffect, useState } from "react";
import { API } from "../../../api/index";
import { useStyles } from "@material-ui/pickers/views/Calendar/SlideTransition";

export const RdvByPatient = (props) => {
  const useStyles = makeStyles((theme) => ({
    iconButton: {
      margin: 5,
    },
    paper: {
      flexGrow: 1,
      padding: 30,
    },
    flex: {
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center",
      padding: "10px 20px",
    },
    white: {
      background: "#FFF",
    },
    gray: {
      background: "#de5b5b7d",
    },
    searchBar: {
      minWidth: "200px",
      margin: "0 10px",
    },
    datePicker: {
      width: "200px",
      margin: "0 10px",
    },
    status: {
      padding: "7px 10px",
      borderRadius: "20px",
      boxShadow: "0px 0px 5px rgba(0,0,0,0.1)",
      background: "#EEE",
      fontWeight: "bold",
    },
    type: {
      padding: "7px 10px",
      borderRadius: "30px",
      boxShadow: "0px 0px 5px rgba(0,0,0,0.15)",
      fontSize: "0.8rem",
      fontWeight: "bold",
      opacity: 0.8,
    },
  }));
  const classes = useStyles();
  const connectedUser = JSON.parse(localStorage.getItem("profile"))?.user;
  const { showMe, patient, selectPatients } = props;
  const [appointments, setAppointments] = useState([]);
  console.log(connectedUser);

  var id = patient?.user?._id;
  useEffect(() => {
    try {
      if (id) {
        API.get(`/api/patients/getMyAppointmentsByPatients/${id}`).then(
          (response) => {
            var myData = response.data;
            setAppointments(myData);
          }
        );
      } else {
        console.log("doesnt work");
      }
    } catch (error) {
      console.log(error);
    }
  }, []);

  return (
    <TableContainer sx={{ maxHeight: 440 }}>
      <Table stickyHeader aria-label="sticky table">
        <TableHead>
          <TableRow>
            <TableCell>Date</TableCell>
            <TableCell>Heure</TableCell>
            <TableCell>Doctor</TableCell>
            <TableCell align="center">Consultation</TableCell>
            {connectedUser.role !== "patient" && (
              <TableCell align="center">Createur</TableCell>
            )}
            <TableCell align="center">Status</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {appointments
            ? appointments.map((appointment) => (
                <TableRow
                  key={appointment._id}
                  // onClick={() => appointmentDetails(appointment)}
                >
                  <TableCell>
                    {moment(appointment.start)?.format("DD/MM/YYYY")}
                  </TableCell>
                  <TableCell>
                    {moment(appointment.start)?.format("HH:mm")}
                  </TableCell>
                  {/* {connectedUser.role !== "patient" && (
                    <TableCell>{appointment.patient?.user?.name}</TableCell>
                  )} */}
                  <TableCell>{appointment.doctor?.user?.name}</TableCell>
                  <TableCell align="center">
                    <span
                      className={classes.type}
                      style={{
                        background: appointment.color,
                      }}
                    >
                      {appointment.type}
                    </span>
                  </TableCell>
                  {connectedUser.role !== "patient" && (
                    <TableCell align="center">
                      {appointment.createdBy.role === "patient" ? (
                        <Tooltip
                          title={`Internet @${appointment.createdBy?.name}`}
                          placement="bottom"
                        >
                          <PublicIcon />
                        </Tooltip>
                      ) : appointment.createdBy.role === "client" ? (
                        <div>
                          <Tooltip
                            title={`Docteur @${appointment.createdBy?.name}`}
                            placement="bottom"
                          >
                            <FaceIcon />
                          </Tooltip>
                        </div>
                      ) : (
                        <Tooltip
                          title={`Admin @${connectedUser.name}`}
                          placement="bottom"
                        >
                          <PersonIcon />
                        </Tooltip>
                      )}
                    </TableCell>
                  )}
                  <TableCell align="center" style={{ width: "120px" }}>
                    <span
                      className={classes.status}
                      style={{
                        background:
                          appointment.status === "Attente"
                            ? "#ffc107"
                            : appointment.status === "Confirmer"
                            ? "#4caf50"
                            : appointment.status === "Annuler"
                            ? "#f44336"
                            : "#eee",
                      }}
                    >
                      {appointment.status === "Attente"
                        ? "En attente"
                        : appointment.status === "Confirmer"
                        ? "Confirmé"
                        : appointment.status === "Annuler"
                        ? "Annulé"
                        : ""}
                    </span>
                  </TableCell>
                  {/* {connectedUser?.role !== "patient" && (
                    <TableCell>
                      <EventAvailableIcon
                          onClick={() => {
                            localStorage.setItem(
                              "currentDate",
                              moment(appointment.start).format("YYYY-MM-DD")
                            );
                            history.push("/c/calendar");
                          }}
                          style={{
                            color: "rgb(119 184 194)",
                            cursor: "pointer",
                            fontSize: "1.4rem",
                            marginRight: "10px",
                          }}
                        />

                        <EditIcon
                          onClick={(e) => {
                            e.stopPropagation();
                            setSelectedAppointment(appointment);
                            setShowAddAppointment(true);
                          }}
                          style={{ color: "#1bb719", cursor: "pointer" }}
                        />
                        <DeleteForeverIcon
                          onClick={(e) => {
                            e.stopPropagation();
                            setSelectedAppointment(appointment);
                            setDeleteAppointmentConfirmation(true);
                          }}
                          style={{ color: "#b54827", cursor: "pointer" }}
                        />
                    </TableCell>
                  )} */}
                </TableRow>
              ))
            : null}
        </TableBody>
      </Table>
    </TableContainer>
  );
};
