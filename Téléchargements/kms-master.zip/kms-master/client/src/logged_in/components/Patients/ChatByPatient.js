import React, { useEffect, useState } from "react";
import { API } from "../../../api/index";
import { useSelector } from "react-redux";
import {
  Divider,
  Grid,
  makeStyles,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Typography,
} from "@material-ui/core";
import moment from "moment";
import axios from "axios";

export const ChatByPatient = (props) => {
  const useStyles = makeStyles((theme) => ({
    iconButton: {
      margin: 5,
    },
    paper: {
      flexGrow: 1,
      padding: 30,
    },
    flex: {
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center",
      padding: "10px 20px",
    },
    white: {
      background: "#FFF",
    },
    gray: {
      background: "#de5b5b7d",
    },
    searchBar: {
      minWidth: "200px",
      margin: "0 10px",
    },
    datePicker: {
      width: "200px",
      margin: "0 10px",
    },
    status: {
      padding: "7px 10px",
      borderRadius: "20px",
      boxShadow: "0px 0px 5px rgba(0,0,0,0.1)",
      background: "#EEE",
      fontWeight: "bold",
    },
    type: {
      padding: "7px 10px",
      borderRadius: "30px",
      boxShadow: "0px 0px 5px rgba(0,0,0,0.15)",
      fontSize: "0.8rem",
      fontWeight: "bold",
      opacity: 0.8,
    },
  }));
  const classes = useStyles();
  // const connectedUser = JSON.parse(localStorage.getItem("profile"))?.user;
  const { patient } = props;
  const [chat, setChat] = useState([]);
  // const { chats } = useSelector((state) => state.chats);

  const id = patient._id;
  useEffect(() => {
    try {
      if (id) {
        API.get(`/api/patients/getChatsByPatient/${id}`).then((response) => {
          var myData = response.data;
          console.log(response.data);
          setChat(myData);
        });
      } else {
        console.log("doesnt work");
      }
    } catch (error) {
      console.log(error);
    }
  }, []);
  return (
    <div>
      <TableContainer sx={{ maxHeight: 440 }}>
        <Table stickyHeader sx={{ minWidth: 650 }} aria-label="simple table">
          <TableHead>
            <TableRow>
              <TableCell align="left">Date</TableCell>
              <TableCell align="left">Heure</TableCell>
              <TableCell align="left">De</TableCell>
              <TableCell align="left">A</TableCell>
              <TableCell align="left">Objet</TableCell>
              <TableCell align="left">Message</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {chat.reverse()?.map((chat) => (
              <TableRow
                key={chat._id}
                className={
                  chat.from?.role === "client"
                    ? classes.doctorMessage
                    : classes.adminMessage
                }
                style={!chat.seen ? { opacity: "1" } : { opacity: "0.7" }}
                sx={{
                  "&:last-child td, &:last-child th": { border: 0 },
                }}
              >
                <TableCell align="left">
                  {moment(chat.createdAt).format("DD/MM/YYYY")}
                </TableCell>
                <TableCell align="left">
                  {moment(chat.createdAt).format("HH:mm")}
                </TableCell>
                <TableCell align="left">{chat.from?.name}</TableCell>
                <TableCell align="left">{chat.to?.name}</TableCell>
                <TableCell align="left">{chat.object}</TableCell>
                <TableCell align="left">{chat.message}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>
    </div>
  );
};
