import React, { useEffect, useState } from "react";
import Button from "@material-ui/core/Button";
import Dialog from "@material-ui/core/Dialog";
import DialogActions from "@material-ui/core/DialogActions";
import DialogContent from "@material-ui/core/DialogContent";
import { Divider, Grid, Paper, Typography } from "@material-ui/core";
import MailOutlineIcon from "@material-ui/icons/MailOutline";
import PhoneAndroidIcon from "@material-ui/icons/PhoneAndroid";
import CakeIcon from "@material-ui/icons/Cake";
import CallEndIcon from "@material-ui/icons/CallEnd";
import ShortTextIcon from "@material-ui/icons/ShortText";
import AccountBalanceIcon from "@material-ui/icons/AccountBalance";
import HomeIcon from "@material-ui/icons/Home";
import InfoIcon from "@material-ui/icons/Info";
import MarkunreadMailboxIcon from "@material-ui/icons/MarkunreadMailbox";
import LocationCityIcon from "@material-ui/icons/LocationCity";
import LanguageIcon from "@material-ui/icons/Language";
import PersonIcon from "@material-ui/icons/Person";
import BusinessIcon from "@material-ui/icons/Business";
import PublicIcon from "@material-ui/icons/Public";
import BlockIcon from "@material-ui/icons/Block";
import FiberManualRecordIcon from "@material-ui/icons/FiberManualRecord";
import { API } from "../../../api/index";
import { RdvByPatient } from "./RdvByPatient";

export default function FichePatient(props) {
  const { showMe, patient } = props;
  const [chat, setChat] = useState([]);
  const [selectedPatient, setSelectedPatient] = useState(null);
  const [historyOpen, setHistoryOpen] = useState(false);
  console.log(patient);
  const rdvHistory = (patient) => {
    setSelectedPatient(patient);
    setHistoryOpen(true);
  };

  //   useEffect(() => {
  //     const getData = () => {
  //       var id = patient?.user?._id;
  //       console.log(id);
  //       try {
  //         API.get(`/api/chats/getChatsByPatient/:${id}`).then((response) => {
  //           var myData = response.data;
  //           setChat(myData);
  //         });
  //       } catch (error) {
  //         console.log(error);
  //       }
  //     };
  //     getData();
  //     console.log(chat);
  //   }, [chat]);

  //   {
  //     chat.map((chat) => {
  //       const chatReceiver = chat.to;
  //       console.log(chatReceiver);
  //     });
  //   }
  //   console.log(chat);

  // if(chat.to?._id === patient.user?._id){

  // }

  if (!showMe || !patient) return null;

  return (
    <Dialog
      open={showMe}
      onClose={props.closeMe}
      aria-labelledby="form-dialog-title"
    >
      <div
        style={{
          backgroundColor: "#b3294e",
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
        }}
      >
        <Typography style={{ marginTop: "30px", color: "#fff" }}>
          Fiche Patient
        </Typography>
        <Typography
          variant="h4"
          style={{ marginBottom: "10px", color: "#fff" }}
        >
          {patient?.user.name}
        </Typography>
        <button onClick={rdvHistory(patient)}></button>
      </div>
      <div className="patient_messages"></div>
      <DialogContent>
        <Grid container spacing={3} style={{ marginTop: "15px" }}>
          <Grid item xs={6}>
            <Typography
              style={{ marginLeft: "5px", fontSize: "17px", color: "#4829B2" }}
            >
              {" "}
              Email
            </Typography>
            <Paper elevation={0} style={{ display: "flex", padding: "10px" }}>
              <MailOutlineIcon
                style={{ marginRight: "3px", color: "#b3294e" }}
              />
              <Divider orientation="vertical" flexItem />
              <Typography style={{ marginLeft: "5px" }}>
                <a href={`mail:to ${patient?.user.email}`}>Send a mail</a>
              </Typography>
            </Paper>
          </Grid>
          <Grid item xs={6}>
            <Typography
              style={{ marginLeft: "5px", fontSize: "17px", color: "#4829B2" }}
            >
              {" "}
              Genre
            </Typography>
            <Paper elevation={0} style={{ display: "flex", padding: "10px" }}>
              <Divider orientation="vertical" flexItem />
              <Typography style={{ marginLeft: "5px" }}>
                {patient.user?.gender}
              </Typography>
            </Paper>
          </Grid>
          <Grid item xs={6}>
            <Typography
              style={{ marginLeft: "5px", fontSize: "17px", color: "#4829B2" }}
            >
              {" "}
              Téléphone
            </Typography>
            <Paper elevation={0} style={{ display: "flex", padding: "10px" }}>
              <PhoneAndroidIcon
                style={{ marginRight: "3px", color: "#b3294e" }}
              />
              <Divider orientation="vertical" flexItem />
              <Typography style={{ marginLeft: "5px" }}>
                {patient?.user.phone || patients?.fixeNumber}
              </Typography>
            </Paper>
          </Grid>
          <Grid item xs={6}>
            <Typography
              style={{ marginLeft: "5px", fontSize: "17px", color: "#4829B2" }}
            >
              {" "}
              Date de naissance
            </Typography>
            <Paper elevation={0} style={{ display: "flex", padding: "10px" }}>
              <CakeIcon style={{ marginRight: "3px", color: "#b3294e" }} />
              <Divider orientation="vertical" flexItem />
              <Typography style={{ marginLeft: "5px" }}>
                {patient?.birthday}
              </Typography>
            </Paper>
          </Grid>
          <Grid item xs={6}>
            <Typography
              style={{ marginLeft: "5px", fontSize: "17px", color: "#4829B2" }}
            >
              {" "}
              Téléphone fixe
            </Typography>
            <Paper elevation={0} style={{ display: "flex", padding: "10px" }}>
              <CallEndIcon style={{ marginRight: "3px", color: "#b3294e" }} />
              <Divider orientation="vertical" flexItem />
              <Typography style={{ marginLeft: "5px" }}>
                {patient?.fixeNumber}
              </Typography>
            </Paper>
          </Grid>
          <Grid item xs={6}>
            <Typography
              style={{ marginLeft: "5px", fontSize: "17px", color: "#4829B2" }}
            >
              {" "}
              N. Sécurite sociale
            </Typography>
            <Paper elevation={0} style={{ display: "flex", padding: "10px" }}>
              <ShortTextIcon style={{ marginRight: "3px", color: "#b3294e" }} />
              <Divider orientation="vertical" flexItem />
              <Typography style={{ marginLeft: "5px" }}>
                {patient?.securityNumber}
              </Typography>
            </Paper>
          </Grid>
          <Grid item xs={6}>
            <Typography
              style={{ marginLeft: "5px", fontSize: "17px", color: "#4829B2" }}
            >
              {" "}
              Centre Payeur
            </Typography>
            <Paper elevation={0} style={{ display: "flex", padding: "10px" }}>
              <AccountBalanceIcon
                style={{ marginRight: "3px", color: "#b3294e" }}
              />
              <Divider orientation="vertical" flexItem />
              <Typography style={{ marginLeft: "5px" }}>
                {patient?.paymentCenter}
              </Typography>
            </Paper>
          </Grid>
          <Grid item xs={6}>
            <Typography
              style={{ marginLeft: "5px", fontSize: "17px", color: "#4829B2" }}
            >
              {" "}
              Adresse
            </Typography>
            <Paper elevation={0} style={{ display: "flex", padding: "10px" }}>
              <HomeIcon style={{ marginRight: "3px", color: "#b3294e" }} />
              <Divider orientation="vertical" flexItem />
              <Typography style={{ marginLeft: "5px" }}>
                {patient?.address}
              </Typography>
            </Paper>
          </Grid>
          <Grid item xs={6}>
            <Typography
              style={{ marginLeft: "5px", fontSize: "17px", color: "#4829B2" }}
            >
              {" "}
              Accès
            </Typography>
            <Paper elevation={0} style={{ display: "flex", padding: "10px" }}>
              <InfoIcon style={{ marginRight: "3px", color: "#b3294e" }} />
              <Divider orientation="vertical" flexItem />
              <Typography style={{ marginLeft: "5px" }}>
                {patient?.access}
              </Typography>
            </Paper>
          </Grid>
          <Grid item xs={6}>
            <Typography
              style={{ marginLeft: "5px", fontSize: "17px", color: "#4829B2" }}
            >
              {" "}
              Code Postale
            </Typography>
            <Paper elevation={0} style={{ display: "flex", padding: "10px" }}>
              <MarkunreadMailboxIcon
                style={{ marginRight: "3px", color: "#b3294e" }}
              />
              <Divider orientation="vertical" flexItem />
              <Typography style={{ marginLeft: "5px" }}>
                {patient?.cp}
              </Typography>
            </Paper>
          </Grid>
          <Grid item xs={6}>
            <Typography
              style={{ marginLeft: "5px", fontSize: "17px", color: "#4829B2" }}
            >
              {" "}
              Ville
            </Typography>
            <Paper elevation={0} style={{ display: "flex", padding: "10px" }}>
              <LocationCityIcon
                style={{ marginRight: "3px", color: "#b3294e" }}
              />
              <Divider orientation="vertical" flexItem />
              <Typography style={{ marginLeft: "5px" }}>
                {patient?.city}
              </Typography>
            </Paper>
          </Grid>
          <Grid item xs={12}>
            <Typography
              style={{ marginLeft: "5px", fontSize: "17px", color: "#4829B2" }}
            >
              {" "}
              RDV. par Int.
            </Typography>
            <Paper elevation={0} style={{ display: "flex", padding: "10px" }}>
              <LanguageIcon style={{ marginRight: "3px", color: "#b3294e" }} />
              <Divider orientation="vertical" flexItem />
              <Typography style={{ marginLeft: "5px" }}>
                {patient?.rdv ? "Oui" : "Non"}
              </Typography>
            </Paper>
          </Grid>
          <Grid item xs={3}>
            <Typography
              style={{ marginLeft: "5px", fontSize: "17px", color: "#4829B2" }}
            >
              {" "}
              Med. Trait.{" "}
            </Typography>
            <Paper elevation={0} style={{ display: "flex", padding: "10px" }}>
              <PersonIcon style={{ marginRight: "3px", color: "#b3294e" }} />
              <Divider orientation="vertical" flexItem />
              {patient.treatingDoctor ? (
                <FiberManualRecordIcon style={{ color: "green" }} />
              ) : (
                <FiberManualRecordIcon style={{ color: "red" }} />
              )}
            </Paper>
          </Grid>
          <Grid item xs={3}>
            <Typography
              style={{ marginLeft: "5px", fontSize: "17px", color: "#4829B2" }}
            >
              {" "}
              AME
            </Typography>
            <Paper elevation={0} style={{ display: "flex", padding: "10px" }}>
              <BusinessIcon style={{ marginRight: "3px", color: "#b3294e" }} />
              <Divider orientation="vertical" flexItem />
              {patient.ame ? (
                <FiberManualRecordIcon style={{ color: "green" }} />
              ) : (
                <FiberManualRecordIcon style={{ color: "red" }} />
              )}
            </Paper>
          </Grid>
          <Grid item xs={3}>
            <Typography
              style={{ marginLeft: "5px", fontSize: "17px", color: "#4829B2" }}
            >
              {" "}
              CMU
            </Typography>
            <Paper elevation={0} style={{ display: "flex", padding: "10px" }}>
              <PublicIcon style={{ marginRight: "3px", color: "#b3294e" }} />
              <Divider orientation="vertical" flexItem />
              {patient.cmu ? (
                <FiberManualRecordIcon style={{ color: "green" }} />
              ) : (
                <FiberManualRecordIcon style={{ color: "red" }} />
              )}
            </Paper>
          </Grid>
          <Grid item xs={3}>
            <Typography
              style={{ marginLeft: "5px", fontSize: "17px", color: "#4829B2" }}
            >
              {" "}
              Blacklist
            </Typography>
            <Paper elevation={0} style={{ display: "flex", padding: "10px" }}>
              <BlockIcon style={{ marginRight: "3px", color: "#b3294e" }} />
              <Divider orientation="vertical" flexItem />
              {patient.blacklist ? (
                <FiberManualRecordIcon style={{ color: "green" }} />
              ) : (
                <FiberManualRecordIcon style={{ color: "red" }} />
              )}
            </Paper>
          </Grid>
        </Grid>
      </DialogContent>
      <DialogActions>
        <Button onClick={props.closeMe} color="primary">
          Cancel
        </Button>
      </DialogActions>
      <RdvByPatient
        showMe={historyOpen}
        patient={selectedPatient}
        closeMe={() => setHistoryOpen(false)}
      />
    </Dialog>
  );
}
