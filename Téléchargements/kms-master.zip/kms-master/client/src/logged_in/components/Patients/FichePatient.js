import React, { useEffect, useState } from "react";
import Button from "@material-ui/core/Button";
import Dialog from "@material-ui/core/Dialog";
import DialogActions from "@material-ui/core/DialogActions";
import DialogContent from "@material-ui/core/DialogContent";
import EventIcon from "@material-ui/icons/Event";
import {
  Divider,
  Grid,
  makeStyles,
  Paper,
  Select,
  Typography,
} from "@material-ui/core";
import MailOutlineIcon from "@material-ui/icons/MailOutline";
import PhoneAndroidIcon from "@material-ui/icons/PhoneAndroid";
import CakeIcon from "@material-ui/icons/Cake";
import CallEndIcon from "@material-ui/icons/CallEnd";
import ShortTextIcon from "@material-ui/icons/ShortText";
import AccountBalanceIcon from "@material-ui/icons/AccountBalance";
import HomeIcon from "@material-ui/icons/Home";
import InfoIcon from "@material-ui/icons/Info";
import MarkunreadMailboxIcon from "@material-ui/icons/MarkunreadMailbox";
import LocationCityIcon from "@material-ui/icons/LocationCity";
import LanguageIcon from "@material-ui/icons/Language";
import PersonIcon from "@material-ui/icons/Person";
import BusinessIcon from "@material-ui/icons/Business";
import PublicIcon from "@material-ui/icons/Public";
import BlockIcon from "@material-ui/icons/Block";
import FiberManualRecordIcon from "@material-ui/icons/FiberManualRecord";
import { ChatByPatient } from "./ChatByPatient";
import { RdvByPatient } from "./RdvByPatient";
import { Route } from "react-router-dom";
import ForumIcon from "@material-ui/icons/Forum";
import "react-responsive-carousel/lib/styles/carousel.min.css";
import { Carousel } from "react-responsive-carousel";
import { motion, AnimatePresence } from "framer-motion";
import "./fichePatient.css";

const useStyles = makeStyles((theme) => ({
  row: {
    cursor: "pointer",
    transition: "all 0.3s ease-in-out",
    "&:hover": {
      backgroundColor: "#f5f5f5",
    },
  },
  seen: {
    cursor: "pointer",
    transition: "all 0.3s ease-in-out",
    backgroundColor: "#CCC",
    "&:hover": {
      backgroundColor: "#f5f5f5",
    },
  },
  tabHeader: {
    backgroundColor: "#b3294e",
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    padding: "0 2rem 1rem",
  },
  displayRows: {
    cursor: "pointer",
    fontSize: "2rem",
    color: "#fff",
    transition: "all 0.3s ease-in-out",
    "&:hover": {
      color: "#CCC",
    },
  },
  displayMessenger: {
    cursor: "pointer",
    fontSize: "2rem",
    color: "#080",
    transition: "all 0.3s ease-in-out",
    "&:hover": {
      color: "#CCC",
    },
  },
  doctorMessage: {
    cursor: "pointer",
    transition: "all 0.5s",
    background: "#b2bce1",
  },
  adminMessage: {
    cursor: "pointer",
    transition: "all 0.5s",
    background: "#e6a2ad",
  },
}));
export default function FichePatient(props) {
  const { showMe, patient } = props;
  const classes = useStyles();
  const [displayRows, setDisplayRows] = useState(true);

  const tabs = [
    {
      label: "RDV",
    },
    {
      label: "FICHE",
    },
    {
      label: "MSG",
    },
  ];
  const [selectedTab, setSelectedTab] = useState(tabs[0]);

  return (
    <div className="fichePatient">
      <Dialog
        open={showMe}
        onClose={props.closeMe}
        aria-labelledby="form-dialog-title"
      >
        <div
          style={{
            backgroundColor: "#b3294e",
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
          }}
        >
          <Typography style={{ marginTop: "30px", color: "#fff" }}>
            Fiche Patient
          </Typography>
          <Typography
            variant="h4"
            style={{ marginBottom: "10px", color: "#fff" }}
          >
            {patient?.user.name}
          </Typography>
          <div style={{ display: "flex", justifyContent: "space-around" }}>
            <nav>
              <ul className="tabs__ul">
                {tabs.map((item) => (
                  <li
                    key={item.label}
                    className={item === selectedTab ? "selected" : "tabs__list"}
                    onClick={() => setSelectedTab(item)}
                  >
                    {`${item.label}`}
                    {item === selectedTab ? (
                      <motion.div className="underline" layoutId="underline" />
                    ) : null}
                  </li>
                ))}
              </ul>
            </nav>
          </div>
        </div>

        <div className="window">
          <main className="mainFiche">
            <AnimatePresence exitBeforeEnter>
              <motion.div
                key={selectedTab ? selectedTab.label : "empty"}
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.014 }}
              >
                {selectedTab.label === "Fiche" ? (
                  <DialogContent>
                    <Grid container spacing={3} style={{ marginTop: "15px" }}>
                      <Grid item xs={6}>
                        <Typography
                          style={{
                            display: "flex",
                            marginLeft: "5px",
                            fontSize: "17px",
                            color: "#4829B2",
                          }}
                        >
                          {" "}
                          Email
                        </Typography>
                        <Paper
                          elevation={0}
                          style={{ display: "flex", padding: "10px" }}
                        >
                          <MailOutlineIcon
                            style={{ marginRight: "3px", color: "#b3294e" }}
                          />
                          <Divider orientation="vertical" flexItem />
                          <Typography style={{ marginLeft: "5px" }}>
                            <a href={`mail:to ${patient?.user.email}`}>
                              Send a mail
                            </a>
                          </Typography>
                        </Paper>
                      </Grid>
                      <Grid item xs={6}>
                        <Typography
                          style={{
                            display: "flex",
                            marginLeft: "5px",
                            fontSize: "17px",
                            color: "#4829B2",
                          }}
                        >
                          {" "}
                          Genre
                        </Typography>
                        <Paper
                          elevation={0}
                          style={{ display: "flex", padding: "10px" }}
                        >
                          <Divider orientation="vertical" flexItem />
                          <Typography style={{ marginLeft: "5px" }}>
                            {patient.user?.gender}
                          </Typography>
                        </Paper>
                      </Grid>
                      <Grid item xs={6}>
                        <Typography
                          style={{
                            display: "flex",
                            marginLeft: "5px",
                            fontSize: "17px",
                            color: "#4829B2",
                          }}
                        >
                          {" "}
                          Téléphone
                        </Typography>
                        <Paper
                          elevation={0}
                          style={{ display: "flex", padding: "10px" }}
                        >
                          <PhoneAndroidIcon
                            style={{ marginRight: "3px", color: "#b3294e" }}
                          />
                          <Divider orientation="vertical" flexItem />
                          <Typography style={{ marginLeft: "5px" }}>
                            {patient?.user.phone}
                          </Typography>
                        </Paper>
                      </Grid>
                      <Grid item xs={6}>
                        <Typography
                          style={{
                            display: "flex",
                            marginLeft: "5px",
                            fontSize: "17px",
                            color: "#4829B2",
                          }}
                        >
                          {" "}
                          Date de naissance
                        </Typography>
                        <Paper
                          elevation={0}
                          style={{ display: "flex", padding: "10px" }}
                        >
                          <CakeIcon
                            style={{ marginRight: "3px", color: "#b3294e" }}
                          />
                          <Divider orientation="vertical" flexItem />
                          <Typography style={{ marginLeft: "5px" }}>
                            {patient?.birthday}
                          </Typography>
                        </Paper>
                      </Grid>
                      <Grid item xs={6}>
                        <Typography
                          style={{
                            display: "flex",
                            marginLeft: "5px",
                            fontSize: "17px",
                            color: "#4829B2",
                          }}
                        >
                          {" "}
                          Téléphone fixe
                        </Typography>
                        <Paper
                          elevation={0}
                          style={{ display: "flex", padding: "10px" }}
                        >
                          <CallEndIcon
                            style={{ marginRight: "3px", color: "#b3294e" }}
                          />
                          <Divider orientation="vertical" flexItem />
                          <Typography
                            style={{ marginLeft: "5px", display: "flex" }}
                          >
                            {patient?.fixeNumber}
                          </Typography>
                        </Paper>
                      </Grid>
                      <Grid item xs={6}>
                        <Typography
                          style={{
                            display: "flex",
                            marginLeft: "5px",
                            fontSize: "17px",
                            color: "#4829B2",
                          }}
                        >
                          {" "}
                          N. Sécurite sociale
                        </Typography>
                        <Paper
                          elevation={0}
                          style={{ display: "flex", padding: "10px" }}
                        >
                          <ShortTextIcon
                            style={{ marginRight: "3px", color: "#b3294e" }}
                          />
                          <Divider orientation="vertical" flexItem />
                          <Typography
                            style={{ marginLeft: "5px", display: "flex" }}
                          >
                            {patient?.securityNumber}
                          </Typography>
                        </Paper>
                      </Grid>
                      <Grid item xs={6}>
                        <Typography
                          style={{
                            display: "flex",
                            marginLeft: "5px",
                            fontSize: "17px",
                            color: "#4829B2",
                          }}
                        >
                          {" "}
                          Centre Payeur
                        </Typography>
                        <Paper
                          elevation={0}
                          style={{ display: "flex", padding: "10px" }}
                        >
                          <AccountBalanceIcon
                            style={{ marginRight: "3px", color: "#b3294e" }}
                          />
                          <Divider orientation="vertical" flexItem />
                          <Typography
                            style={{ marginLeft: "5px", display: "flex" }}
                          >
                            {patient?.paymentCenter}
                          </Typography>
                        </Paper>
                      </Grid>
                      <Grid item xs={6}>
                        <Typography
                          style={{
                            display: "flex",
                            marginLeft: "5px",
                            fontSize: "17px",
                            color: "#4829B2",
                          }}
                        >
                          {" "}
                          Adresse
                        </Typography>
                        <Paper
                          elevation={0}
                          style={{ display: "flex", padding: "10px" }}
                        >
                          <HomeIcon
                            style={{ marginRight: "3px", color: "#b3294e" }}
                          />
                          <Divider orientation="vertical" flexItem />
                          <Typography
                            style={{ marginLeft: "5px", display: "flex" }}
                          >
                            {patient?.address}
                          </Typography>
                        </Paper>
                      </Grid>
                      <Grid item xs={6}>
                        <Typography
                          style={{
                            display: "flex",
                            marginLeft: "5px",
                            fontSize: "17px",
                            color: "#4829B2",
                          }}
                        >
                          {" "}
                          Accès
                        </Typography>
                        <Paper
                          elevation={0}
                          style={{ display: "flex", padding: "10px" }}
                        >
                          <InfoIcon
                            style={{ marginRight: "3px", color: "#b3294e" }}
                          />
                          <Divider orientation="vertical" flexItem />
                          <Typography
                            style={{ marginLeft: "5px", display: "flex" }}
                          >
                            {patient?.access}
                          </Typography>
                        </Paper>
                      </Grid>
                      <Grid item xs={6}>
                        <Typography
                          style={{
                            display: "flex",
                            marginLeft: "5px",
                            fontSize: "17px",
                            color: "#4829B2",
                          }}
                        >
                          {" "}
                          Code Postale
                        </Typography>
                        <Paper
                          elevation={0}
                          style={{ display: "flex", padding: "10px" }}
                        >
                          <MarkunreadMailboxIcon
                            style={{ marginRight: "3px", color: "#b3294e" }}
                          />
                          <Divider orientation="vertical" flexItem />
                          <Typography
                            style={{ marginLeft: "5px", display: "flex" }}
                          >
                            {patient?.cp}
                          </Typography>
                        </Paper>
                      </Grid>
                      <Grid item xs={6}>
                        <Typography
                          style={{
                            display: "flex",
                            marginLeft: "5px",
                            fontSize: "17px",
                            color: "#4829B2",
                          }}
                        >
                          {" "}
                          Ville
                        </Typography>
                        <Paper
                          elevation={0}
                          style={{ display: "flex", padding: "10px" }}
                        >
                          <LocationCityIcon
                            style={{ marginRight: "3px", color: "#b3294e" }}
                          />
                          <Divider orientation="vertical" flexItem />
                          <Typography
                            style={{ marginLeft: "5px", display: "flex" }}
                          >
                            {patient?.city}
                          </Typography>
                        </Paper>
                      </Grid>
                      <Grid item xs={12}>
                        <Typography
                          style={{
                            display: "flex",
                            marginLeft: "5px",
                            fontSize: "17px",
                            color: "#4829B2",
                          }}
                        >
                          {" "}
                          RDV. par Int.
                        </Typography>
                        <Paper
                          elevation={0}
                          style={{ display: "flex", padding: "10px" }}
                        >
                          <LanguageIcon
                            style={{ marginRight: "3px", color: "#b3294e" }}
                          />
                          <Divider orientation="vertical" flexItem />
                          <Typography
                            style={{ marginLeft: "5px", display: "flex" }}
                          >
                            {patient?.rdv ? "Oui" : "Non"}
                          </Typography>
                        </Paper>
                      </Grid>
                      <Grid item xs={3}>
                        <Typography
                          style={{
                            display: "flex",
                            marginLeft: "5px",
                            fontSize: "17px",
                            color: "#4829B2",
                          }}
                        >
                          {" "}
                          Med. Trait.{" "}
                        </Typography>
                        <Paper
                          elevation={0}
                          style={{ display: "flex", padding: "10px" }}
                        >
                          <PersonIcon
                            style={{ marginRight: "3px", color: "#b3294e" }}
                          />
                          <Divider orientation="vertical" flexItem />
                          {patient.treatingDoctor ? (
                            <FiberManualRecordIcon style={{ color: "green" }} />
                          ) : (
                            <FiberManualRecordIcon style={{ color: "red" }} />
                          )}
                        </Paper>
                      </Grid>
                      <Grid item xs={3}>
                        <Typography
                          style={{
                            display: "flex",
                            marginLeft: "5px",
                            fontSize: "17px",
                            color: "#4829B2",
                          }}
                        >
                          {" "}
                          AME
                        </Typography>
                        <Paper
                          elevation={0}
                          style={{ display: "flex", padding: "10px" }}
                        >
                          <BusinessIcon
                            style={{ marginRight: "3px", color: "#b3294e" }}
                          />
                          <Divider orientation="vertical" flexItem />
                          {patient.ame ? (
                            <FiberManualRecordIcon style={{ color: "green" }} />
                          ) : (
                            <FiberManualRecordIcon style={{ color: "red" }} />
                          )}
                        </Paper>
                      </Grid>
                      <Grid item xs={3}>
                        <Typography
                          style={{
                            display: "flex",
                            marginLeft: "5px",
                            fontSize: "17px",
                            color: "#4829B2",
                          }}
                        >
                          {" "}
                          CMU
                        </Typography>
                        <Paper
                          elevation={0}
                          style={{ display: "flex", padding: "10px" }}
                        >
                          <PublicIcon
                            style={{ marginRight: "3px", color: "#b3294e" }}
                          />
                          <Divider orientation="vertical" flexItem />
                          {patient.cmu ? (
                            <FiberManualRecordIcon style={{ color: "green" }} />
                          ) : (
                            <FiberManualRecordIcon style={{ color: "red" }} />
                          )}
                        </Paper>
                      </Grid>
                      <Grid item xs={3}>
                        <Typography
                          style={{
                            display: "flex",
                            marginLeft: "5px",
                            fontSize: "17px",
                            color: "#4829B2",
                          }}
                        >
                          {" "}
                          Blacklist
                        </Typography>
                        <Paper
                          elevation={0}
                          style={{ display: "flex", padding: "10px" }}
                        >
                          <BlockIcon
                            style={{ marginRight: "3px", color: "#b3294e" }}
                          />
                          <Divider orientation="vertical" flexItem />
                          {patient.blacklist ? (
                            <FiberManualRecordIcon style={{ color: "green" }} />
                          ) : (
                            <FiberManualRecordIcon style={{ color: "red" }} />
                          )}
                        </Paper>
                      </Grid>
                    </Grid>
                  </DialogContent>
                ) : selectedTab.label === "MSG" ? (
                  <ChatByPatient patient={patient} />
                ) : (
                  <RdvByPatient patient={patient} />
                )}
              </motion.div>
            </AnimatePresence>
          </main>
        </div>
        <DialogActions>
          <Button onClick={props.closeMe} color="primary">
            Cancel
          </Button>
        </DialogActions>
      </Dialog>
    </div>
  );
}
