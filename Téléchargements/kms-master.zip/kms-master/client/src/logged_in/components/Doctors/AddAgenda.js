import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Grid, makeStyles,TextField, Typography, Button, FormControl, InputLabel, Select } from '@material-ui/core';
import { createAgenda, editAgenda } from '../../../actions/agendas';
import ChipInput from 'material-ui-chip-input'

const useStyles = makeStyles((theme) => ({
    formControl: {
        minWidth: 120,
        height: 20,
        display: 'flex',
    },
    saveButton: {
        paddingTop: 10,
    },
    loading: {
        width: '20px',
        marginLeft: '10px',
    },
    divider: {
        marginTop: '30px',
    },

}));

export default function AddAgenda(props) {
    const {agenda, show} = props
    const dispatch = useDispatch()
    const { AgendasIsLoading } = useSelector(state => state.agendas)
    const classes = useStyles();
    const [feedback, setFeedback] = useState(null);
    const [formData, setFormData] = useState({
        agendaName: '',
        speciality: '',
        consultationsTypes: [],
        cabinePhone: '',
    });

    const clear = () => {
        setFormData({
            agendaName: '',
            speciality: '',
            consultationsTypes: [],
            cabinePhone: '',
        })
    }

    const handleSubmit = (e) => {
        e.preventDefault();

        if (formData.agendaName.length === 0) {
            setFeedback("Veuillez entrer un nom d'agenda.");
            if (document.getElementById('feedback')) {
                document.getElementById('feedback').style.color = 'red';
            }
            if (document.getElementById('agendaname')) {
                document.getElementById('agendaname').focus();
            }
            return;
        }
        
        if (formData.speciality.length === 0) {
            setFeedback("Veuillez entrer une spécialité.");
            if (document.getElementById('feedback')) {
                document.getElementById('feedback').style.color = 'red';
            }
            if (document.getElementById('speciality')) {
                document.getElementById('speciality').focus();
            }
            return;
        }

        if (formData.consultationsTypes.length === 0) {
            setFeedback("Veuillez entrer un type de consultation.");
            if (document.getElementById('feedback')) {
                document.getElementById('feedback').style.color = 'red';
            }
            if (document.getElementById('consultationstypes')) {
                document.getElementById('consultationstypes').focus();
            }
            return;
        }

        if (agenda) {
           dispatch(editAgenda(agenda._id, formData)).then(() => {
               setFeedback('Agenda modifié');
               props.close();
           })
        } else {
            dispatch(createAgenda(formData)).then(() => {
                setFeedback('Agenda ajouté');
                clear();
                props.close();
            })  
        }
    }

    useEffect(() => {
        if (agenda) {
            setFormData({
                agendaName: agenda.name,
                speciality: agenda.speciality,
                consultationsTypes: agenda.consultationsTypes,
                cabinePhone: agenda.phone,
            });
        }
    }, [agenda])

    if (!show) return null;

    return (
        <form>
            <Grid container spacing={3} className="griditem" >
                <Grid item xs={12}>
                    <Typography variant="h4" style={{ marginTop: '10px' }}>Ajout d'agenda </Typography>
                </Grid>
                <Grid item xs={6}>
                    <TextField fullWidth name="agendaName" id="agendaname" label="Nom agenda" value={formData.agendaName} onChange={e => setFormData({ ...formData, agendaName : e.target.value})} />
                </Grid>
                <Grid item xs={6}>
                    <TextField fullWidth name="cabinePhone" id="cabinephone" label="Tél. cabinet" value={formData.cabinePhone} onChange={e => setFormData({ ...formData, cabinePhone : e.target.value})} />
                </Grid>
                <Grid item xs={12}>
                    <FormControl style={{ width: '100%' }} >
                        <InputLabel htmlFor="age-native-simple">Spécialité</InputLabel>
                        <Select
                            native
                            value={formData.speciality}
                            onChange={(e) => setFormData({ ...formData, speciality: e.target.value })}
                            inputProps={{ name: 'speciality', id: 'speciality' }} >
                            
                            <option aria-label="None" value="" />

                            <option value='Acupuncteur'>Acupuncteur</option>
                            <option value='Addictologue'>Addictologue</option>
                            <option value='Allergologue'>Allergologue</option>
                            <option value='Anesthésiste'>Anesthésiste</option>
                            <option value='Angiologue'>Angiologue</option>
                            <option value='Aromathérapeute'>Aromathérapeute</option>
                            <option value='Cabinet dentaire'>Cabinet dentaire</option>
                            <option value='Cabinet médical'>Cabinet médical</option>
                            <option value='Cancérologue'>Cancérologue</option>
                            <option value='Cancérologue médical'>Cancérologue médical</option>
                            <option value='Cancérologue radiothérapeute'>Cancérologue radiothérapeute</option>
                            <option value='Cardiologue'>Cardiologue</option>
                            <option value="Cardiologue du sport">Cardiologue du sport</option>
                            <option value="Cardiologue Rythmologue">Cardiologue Rythmologue</option>
                            <option value="Centre de chirurgie réfractive">Centre de chirurgie réfractive</option>
                            <option value="Centre de médecine préventive">Centre de médecine préventive</option>
                            <option value="Centre de planification et d'éducation familiale">Centre de planification et d'éducation familiale</option>
                            <option value="Centre de santé">Centre de santé</option>
                            <option value="Centre Laser">Centre Laser</option>
                            <option value="Centre médical et dentaire">Centre médical et dentaire</option>
                            <option value="Chiropracteur">Chiropracteur</option>
                            <option value="Chirurgie de l'épaule">Chirurgie de l'épaule</option>
                            <option value="Chirurgien">Chirurgien</option>
                            <option value="Chirurgien cancérologue">Chirurgien cancérologue</option>
                            <option value="Chirurgien de l'obésité">Chirurgien de l'obésité</option>
                            <option value="Chirurgien de la hanche, du genou et du pied">Chirurgien de la hanche, du genou et du pied</option>
                            <option value="Chirurgien de la main">Chirurgien de la main</option>
                            <option value="Chirurgien dentiste">Chirurgien dentiste</option>
                            <option value="Chirurgien du genou">Chirurgien du genou</option>
                            <option value="Chirurgien du genou et de la hanche">Chirurgien du genou et de la hanche</option>
                            <option value="Chirurgien du membre supérieur">Chirurgien du membre supérieur</option>
                            <option value="Chirurgien du pied">Chirurgien du pied</option>
                            <option value="Chirurgien du rachis">Chirurgien du rachis</option>
                            <option value="Chirurgien esthétique">Chirurgien esthétique</option>
                            <option value="Chirurgien gynécologique et obstétrique">Chirurgien gynécologique et obstétrique</option>
                            <option value="Chirurgien gynécologue">Chirurgien gynécologue</option>
                            <option value="Chirurgien maxillo-facial">Chirurgien maxillo-facial</option>
                            <option value="Chirurgien maxillo-facial et stomatologiste">Chirurgien maxillo-facial et stomatologiste</option>
                            <option value="Chirurgien ophtalmologue">Chirurgien ophtalmologue</option>
                            <option value="Chirurgien oral">Chirurgien oral</option>
                            <option value="Chirurgien orthopédiste">Chirurgien orthopédiste</option>
                            <option value="Chirurgien orthopédiste pédiatrique">Chirurgien orthopédiste pédiatrique</option>
                            <option value="Chirurgien pédiatrique">Chirurgien pédiatrique</option>
                            <option value="Chirurgien plasticien">Chirurgien plasticien</option>
                            <option value="Chirurgien plasticien et esthétique">Chirurgien plasticien et esthétique</option>
                            <option value="Chirurgien sénologue">Chirurgien sénologue</option>
                            <option value="Chirurgien urologue">Chirurgien urologue</option>
                            <option value="Chirurgien vasculaire">Chirurgien vasculaire</option>
                            <option value="Chirurgien viscéral et digestif">Chirurgien viscéral et digestif</option>
                            <option value="Clinique privée">Clinique privée</option>
                            <option value="Dentiste pédiatrique">Dentiste pédiatrique</option>
                            <option value="Dermatologue">Dermatologue</option>
                            <option value="Dermatologue Allergologue">Dermatologue Allergologue</option>
                            <option value="Dermatologue esthétique">Dermatologue esthétique</option>
                            <option value="Dermatologue pédiatrique">Dermatologue pédiatrique</option>
                            <option value="Diabétologue">Diabétologue</option>
                            <option value="Diététicien">Diététicien</option>
                            <option value="Doppler">Doppler</option>
                            <option value="Echographie gynécologique et obstétricale">Echographie gynécologique et obstétricale</option>
                            <option value="Echographie obstétricale">Echographie obstétricale</option>
                            <option value="Echographiste">Echographiste</option>
                            <option value="Endocrinologue">Endocrinologue</option>
                            <option value="Endocrinologue diabétologue">Endocrinologue diabétologue</option>
                            <option value="Endocrinologue pédiatrique">Endocrinologue pédiatrique</option>
                            <option value="Epilation laser">Epilation laser</option>
                            <option value="ESPIC - Etablissement de Santé Privé d'Intérêt Collectif">ESPIC - Etablissement de Santé Privé d'Intérêt Collectif</option>
                            <option value="Etiopathe">Etiopathe</option>
                            <option value="Gastro-entérologue et hépatologue">Gastro-entérologue et hépatologue</option>
                            <option value="Gastro-entérologue pédiatre">Gastro-entérologue pédiatre</option>
                            <option value="Gériatre">Gériatre</option>
                            <option value="Gynécologue">Gynécologue</option>
                            <option value="Gynécologue sexologue">Gynécologue sexologue</option>
                            <option value="Gynécologue-obstétricien">Gynécologue-obstétricien</option>
                            <option value="Hématologue">Hématologue</option>
                            <option value="Homéopathe">Homéopathe</option>
                            <option value="Hôpital privé">Hôpital privé</option>
                            <option value="Hypnopraticien">Hypnopraticien</option>
                            <option value="Hypnothérapeute">Hypnothérapeute</option>
                            <option value="Infirmier">Infirmier</option>
                            <option value="Infirmière coordinatrice">Infirmière coordinatrice</option>
                            <option value="Laser">Laser</option>
                            <option value="Masseur-kinésithérapeute">Masseur-kinésithérapeute</option>
                            <option value="Masseur-kinésithérapeute du sport">Masseur-kinésithérapeute du sport</option>
                            <option value="Médecin de la douleur">Médecin de la douleur</option>
                            <option value="Médecin du sport">Médecin du sport</option>
                            <option value="Médecin esthétique">Médecin esthétique</option>
                            <option value="Médecin généraliste">Médecin généraliste</option>
                            <option value="Médecin nutritionniste">Médecin nutritionniste</option>
                            <option value="Médecin ostéopathe">Médecin ostéopathe</option>
                            <option value="Médecin physique - Réadaptateur">Médecin physique - Réadaptateur</option>
                            <option value="Médecine anti-âge">Médecine anti-âge</option>
                            <option value="Médecine Interne">Médecine Interne</option>
                            <option value="Médecine Morphologique et Anti-âge">Médecine Morphologique et Anti-âge</option>
                            <option value="Médecine préventive">Médecine préventive</option>
                            <option value="Naturopathe">Naturopathe</option>
                            <option value="Néphrologue">Néphrologue</option>
                            <option value="Neurochirurgien">Neurochirurgien</option>
                            <option value="Neurologue">Neurologue</option>
                            <option value="Neuropédiatre">Neuropédiatre</option>
                            <option value="Neuropsychiatre">Neuropsychiatre</option>
                            <option value="Obstétricien">Obstétricien</option>
                            <option value="Oncologie">Oncologie</option>
                            <option value="Oncologue">Oncologue</option>
                            <option value="Ophtalmologue">Ophtalmologue</option>
                            <option value="Ophtalmologue pédiatrique">Ophtalmologue pédiatrique</option>
                            <option value="ORL">ORL</option>
                            <option value="ORL - Chirurgien de la face et du cou">ORL - Chirurgien de la face et du cou</option>
                            <option value="ORL et Chirurgien Plastique">ORL et Chirurgien Plastique</option>
                            <option value="ORL pédiatrique">ORL pédiatrique</option>
                            <option value="Orthodontiste">Orthodontiste</option>
                            <option value="Orthopédiste">Orthopédiste</option>
                            <option value="Orthophoniste">Orthophoniste</option>
                            <option value="Orthoptiste">Orthoptiste</option>
                            <option value="Ostéopathe">Ostéopathe</option>
                            <option value="Pathologiste">Pathologiste</option>
                            <option value="Pédiatre">Pédiatre</option>
                            <option value="Pédicure-podologue">Pédicure-podologue</option>
                            <option value="Pédopsychiatre">Pédopsychiatre</option>
                            <option value="Phlébologue">Phlébologue</option>
                            <option value="Planning familial">Planning familial</option>
                            <option value="PMA/AMP - FIV - Fertilité">PMA/AMP - FIV - Fertilité</option>
                            <option value="Pneumo-allergologue">Pneumo-allergologue</option>
                            <option value="Pneumo-pédiatre">Pneumo-pédiatre</option>
                            <option value="Pneumologue">Pneumologue</option>
                            <option value="Podologue du sport">Podologue du sport</option>
                            <option value="Posturologue">Posturologue</option>
                            <option value="Proctologue">Proctologue</option>
                            <option value="Psychanalyste">Psychanalyste</option>
                            <option value="Psychiatre">Psychiatre</option>
                            <option value="Psychiatre de l'enfant et de l'adolescent">Psychiatre de l'enfant et de l'adolescent</option>
                            <option value="Psychologue">Psychologue</option>
                            <option value="Psychologue clinicien">Psychologue clinicien</option>
                            <option value="Psychothérapeute">Psychothérapeute</option>
                            <option value="Radiologue">Radiologue</option>
                            <option value="Radiothérapeute">Radiothérapeute</option>
                            <option value="Rhumatologue">Rhumatologue</option>
                            <option value="Rythmologue interventionnel">Rythmologue interventionnel</option>
                            <option value="Sage femme">Sage femme</option>
                            <option value="Sénologue">Sénologue</option>
                            <option value="Sexologue">Sexologue</option>
                            <option value="Sexologue médecin">Sexologue médecin</option>
                            <option value="Sophrologue">Sophrologue</option>
                            <option value="Stomatologue">Stomatologue</option>
                            <option value="Tabacologue">Tabacologue</option>
                            <option value="Trouble du sommeil">Trouble du sommeil</option>
                            <option value="Urologue">Urologue</option>
                        </Select>
                    </FormControl>
                </Grid>
                <Grid item xs={12}>
                    <InputLabel style={{margin: '10px 0'}} >Types de consultations</InputLabel>
                    <FormControl style={{ width: '100%'}}>
                        <ChipInput
                            value={formData.consultationsTypes}
                            onAdd={(chip) => setFormData({ ...formData, consultationsTypes: [...formData.consultationsTypes, chip] })}
                            onDelete={(chip, index) => setFormData({ ...formData, consultationsTypes: formData.consultationsTypes.filter((c, i) => i !== index) })}
                        />
                    </FormControl>
                </Grid>
            </Grid>
            <Button style={{ marginTop: '50px', marginRight: '10px' }} variant="contained" color="secondary" type="submit" onClick={e => handleSubmit(e)}>
                Enregistrer
                {
                    AgendasIsLoading ? (
                        <img className={classes.loading} src='/images/loading.gif' alt='Loading' />
                    ) : null
                }
            </Button>
            <Button onClick={props.close} style={{ marginTop: '50px' }} variant="contained" color="primary">
                Annuler
            </Button>
            {
                feedback ? (
                    <p id='feedback' style={{ color: '#080', marginTop: '15px' }}>{feedback}</p>
                ) : null
            }
            
        </form>
    )
}