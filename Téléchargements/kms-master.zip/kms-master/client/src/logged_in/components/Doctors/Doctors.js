import { CircularProgress, Button, Dialog, IconButton, makeStyles, Paper, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, DialogTitle, DialogContent, DialogContentText, DialogActions } from '@material-ui/core';
import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { deleteDoctor } from '../../../actions/doctors';
import AddIcon from '@material-ui/icons/Add';
import AddDoctor from './AddDoctor';
import DeleteForeverIcon from '@material-ui/icons/DeleteForever';
import EditIcon from '@material-ui/icons/Edit';
import AddEtablissement from './AddEtablissement';
import AddAgenda from './AddAgenda';
import TableConfig from './TableConfig';
import { deleteAgenda } from '../../../actions/agendas';
import { deleteEtablissement } from '../../../actions/etablissements';

const useStyles = makeStyles((theme) => ({
    iconButton: {
        margin: 5,
    },
    paper: {
        flexGrow: 1,
        padding: 30,
    },
    tableDialog: {
        maxWidth: '100%',
        '&>div': {
            maxWidth: '850px',
        }
    },
    flex: {
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        padding: '10px 20px',
    },
    bgGreen: {
        background: '#080',
    },
    bgRed: {    
        background: '#cb7878',
    },
    infosBulle: {
        borderRadius: '50%', 
        width: '30px', 
        height: '30px', 
        margin: '0 5px', 
        background: "#CCC",
        boxShadow: '0 0 2px 2px rbga(0,0,0,0.1)',
        fontWeight: 'bold',
        color: '#FFF',
        textAlign: 'center',
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
    },
    infosOther: {
        borderRadius: '20%', 
        margin: '0 5px',
        padding: '5px 10px',
        background: "#CCC",
        boxShadow: '0 0 2px 2px rbga(0,0,0,0.1)',
        fontWeight: 'bold',
        color: '#FFF',
        textAlign: 'center',
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
    }
}));

export default function Doctors(props) {
    const { selectDoctors, etablissement, etablissements, agendas } = props;
    const dispatch = useDispatch();
    const classes = useStyles();
    const { doctors, DoctorsIsLoading } = useSelector((state) => state.doctors);
    const { EtablissementsIsLoading } = useSelector((state) => state.etablissements);
    const { AgendasIsLoading } = useSelector((state) => state.agendas);
    const [showAddDoctor, setShowAddDoctor] = useState(false);
    const [showAddEtablissement, setShowAddEtablissement] = useState(false);
    const [showAddAgenda, setShowAddAgenda] = useState(false);
    const [showTableConfig, setShowTableConfig] = useState(false);
    const [selectedDoctor, setSelectedDoctor] = useState(null);
    const [selectedEtablissement, setSelectedEtablissement] = useState(null);
    const [selectedAgenda, setSelectedAgenda] = useState(null);
    const [selectedTab, setSelectedTab] = useState('doctors');
    const [deleteAgendaConfirmation, setDeleteAgendaConfirmation] = useState(false);
    const [deleteEtablissementConfirmation, setDeleteEtablissementConfirmation] = useState(false);
    const [deleteDoctorConfirmation, setDeleteDoctorConfirmation] = useState(false);

    useEffect(selectDoctors, [selectDoctors]);

    const handleClickOpen = () => {
        if (selectedTab === 'doctors') {
            setSelectedDoctor(null)
            setShowAddDoctor(true);
        } else if (selectedTab === 'etablissements') {
            setSelectedEtablissement(null)
            setShowAddEtablissement(true);
        } else if (selectedTab === 'agendas') {
            setSelectedAgenda(null)
            setShowAddAgenda(true);
        }
    };

    const handleClose = () => {
        setShowAddDoctor(false);
    };

    const handleDeleteAgenda = () => {
        dispatch(deleteAgenda(selectedAgenda._id));
        setDeleteAgendaConfirmation(false);
    }

    const handleDeleteEtablissement = () => {
        dispatch(deleteEtablissement(selectedEtablissement._id));
        setDeleteEtablissementConfirmation(false);
    }

    const handleDeleteDoctor = () => {
        dispatch(deleteDoctor(selectedDoctor._id));
        setDeleteDoctorConfirmation(false);
    }
      
    return (
        <Paper sx={{ width: '100%', overflow: 'hidden' }}>
            <div className={classes.flex} >
                { DoctorsIsLoading || EtablissementsIsLoading || AgendasIsLoading ? <div style={{ margin: 5, padding: '12px' }}><CircularProgress size={25} color='primary' /></div> : (
                    <IconButton color="primary" aria-label="add" className={classes.iconButton} onClick={handleClickOpen}>
                        <AddIcon />
                    </IconButton>
                ) }
                <div>
                    <Button style={{ margin: '0 10px' }} onClick={() => setSelectedTab('doctors')} variant="contained" color={selectedTab === 'doctors' ? "primary" : "default"}> Médecins </Button>
                    <Button style={{ margin: '0 10px' }} onClick={() => setSelectedTab('agendas')} variant="contained" color={selectedTab === 'agendas' ? "primary" : "default"}> Agendas </Button>
                    <Button style={{ margin: '0 10px' }} onClick={() => setSelectedTab('etablissements')} variant="contained" color={selectedTab === 'etablissements' ? "primary" : "default"}> Etablissements </Button>
                </div>
            </div>
            {
                selectedTab === 'doctors' ? (
                    <TableContainer sx={{ maxHeight: 440 }}>
                        <Table stickyHeader aria-label="sticky table">
                            <TableHead>
                                <TableRow>
                                    <TableCell>Name</TableCell>
                                    <TableCell>Phone</TableCell>
                                    <TableCell>Email</TableCell>
                                    <TableCell>Etablissement</TableCell>
                                    <TableCell>Agenda</TableCell>
                                    <TableCell>Actions</TableCell>
                                </TableRow>
                            </TableHead>
                            <TableBody>     
                                {doctors?.map((doctor) => (
                                    <TableRow key={doctor._id}>
                                        <TableCell>{doctor.user?.name}</TableCell>
                                        <TableCell>{doctor.user?.phone}</TableCell>
                                        <TableCell>{doctor.user?.email}</TableCell>
                                        <TableCell>{doctor.etablissement?.name}</TableCell>
                                        <TableCell>{agendas?.map(agenda => doctor.agendas?.includes(agenda._id) ? `${agenda.name}, ` : null)}</TableCell>
                                        <TableCell>
                                            <EditIcon onClick={() => { setSelectedDoctor(doctor); setShowAddDoctor(true) }} style={{ color: '#1bb719', cursor: 'pointer' }} />
                                            <DeleteForeverIcon onClick={() => {setSelectedDoctor(doctor); setDeleteDoctorConfirmation(true)}} style={{ color: '#b54827', cursor: 'pointer' }} />
                                        </TableCell>
                                    </TableRow>
                                ))}
                            </TableBody>
                        </Table>
                    </TableContainer>
                ) : selectedTab ===  'etablissements' ? (
                    <TableContainer sx={{ maxHeight: 440 }}>
                        <Table stickyHeader aria-label="sticky table">
                            <TableHead>
                                <TableRow>
                                    <TableCell>Name</TableCell>
                                    <TableCell>Phone</TableCell>
                                    <TableCell>Adresse</TableCell>
                                    <TableCell>Ville</TableCell>
                                    <TableCell>Code Postal</TableCell>
                                    <TableCell align="center">Infos</TableCell>
                                    <TableCell>Actions</TableCell>
                                </TableRow>
                            </TableHead>
                            <TableBody>     
                                {etablissements?.map((etablissement) => (
                                    <TableRow key={etablissement._id}>
                                        <TableCell>{etablissement.name}</TableCell>
                                        <TableCell>{etablissement.phone}</TableCell>
                                        <TableCell>{etablissement.address}</TableCell>
                                        <TableCell>{etablissement.postalCode}</TableCell>
                                        <TableCell>{etablissement.city}</TableCell>
                                        <TableCell><span style={{ display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
                                            <span className={classes.infosOther}>
                                                {etablissement.startDayHour} &nbsp;-&nbsp; {etablissement.endDayHour}
                                            </span>
                                            <span className={classes.infosBulle} style={!etablissement.excludedDays.includes(6) ? { background: '#080'} : null}>S</span>
                                            <span className={classes.infosBulle} style={!etablissement.excludedDays.includes(0) ? { background: '#080'} : null}>D</span>
                                        </span></TableCell>
                                        <TableCell>
                                            <EditIcon onClick={() => { setSelectedEtablissement(etablissement); setShowAddEtablissement(true) }} style={{ color: '#1bb719', cursor: 'pointer' }} />
                                            <DeleteForeverIcon onClick={() => {setSelectedEtablissement(etablissement); setDeleteEtablissementConfirmation(true)}} style={{ color: '#b54827', cursor: 'pointer' }} />
                                        </TableCell>
                                    </TableRow>
                                ))}
                            </TableBody>
                        </Table>
                    </TableContainer>
                ) : selectedTab === 'agendas' ? (
                    <TableContainer sx={{ maxHeight: 440 }}>
                        <Table stickyHeader aria-label="sticky table">
                            <TableHead>
                                <TableRow>
                                    <TableCell>Name</TableCell>
                                    <TableCell>Phone</TableCell>
                                    <TableCell>Spécialité</TableCell>
                                    <TableCell>Types de consultations</TableCell>
                                    <TableCell>Pré-reservation</TableCell>
                                    <TableCell>Actions</TableCell>
                                </TableRow>
                            </TableHead>
                            <TableBody>     
                                {agendas?.map((agenda) => (
                                    <TableRow key={agenda._id}>
                                        <TableCell>{agenda.name}</TableCell>
                                        <TableCell>{agenda.phone}</TableCell>
                                        <TableCell>{agenda.speciality}</TableCell>
                                        <TableCell>{agenda.consultationsTypes.join(', ')}</TableCell>
                                        <TableCell><Button className={agenda.template ? classes.bgGreen : classes.bgRed} onClick={() => {setSelectedAgenda(agenda); setShowTableConfig(true)}} >Config</Button></TableCell>
                                        <TableCell>
                                            <EditIcon onClick={() => { setSelectedAgenda(agenda); setShowAddAgenda(true) }} style={{ color: '#1bb719', cursor: 'pointer' }} />
                                            <DeleteForeverIcon onClick={() => {setSelectedAgenda(agenda); setDeleteAgendaConfirmation(true)}} style={{ color: '#b54827', cursor: 'pointer' }} />
                                        </TableCell>
                                    </TableRow>
                                ))}
                            </TableBody>
                        </Table>
                    </TableContainer>
                ) : null
            }
            <Dialog open={showAddDoctor} onClose={() => setShowAddDoctor(false)} aria-labelledby="form-dialog-title">
                <Paper className={classes.paper}>
                    <AddDoctor doctor={selectedDoctor} etablissements={etablissements} agendas={agendas} show={showAddDoctor} close={handleClose} />
                </Paper>
            </Dialog>
            <Dialog open={showAddEtablissement} onClose={() => setShowAddEtablissement(false)} aria-labelledby="form-dialog-title">
                <Paper className={classes.paper}>
                    <AddEtablissement etablissement={selectedEtablissement} show={showAddEtablissement} close={() => setShowAddEtablissement(false)} />
                </Paper>
            </Dialog>
            <Dialog open={showAddAgenda} onClose={() => setShowAddAgenda(false)} aria-labelledby="form-dialog-title">
                <Paper className={classes.paper}>
                    <AddAgenda agenda={selectedAgenda} show={showAddAgenda} close={() => setShowAddAgenda(false)} />
                </Paper>
            </Dialog>
            <Dialog maxWidth="lg" open={showTableConfig} onClose={() => setShowTableConfig(false)} aria-labelledby="form-dialog-title">
                <Paper className={classes.paper} >
                    <TableConfig agenda={selectedAgenda} show={showTableConfig} close={() => setShowTableConfig(false)} etablissement={etablissement} doctors={doctors} />
                </Paper>
            </Dialog>
            {/* DELETE CONFIRMATION */}
            <Dialog
                open={deleteAgendaConfirmation}
                onClose={() => setDeleteAgendaConfirmation(false)}
                aria-labelledby="agenda-title"
                aria-describedby="agenda-description"
            >
                <DialogTitle id="agenda-title">{"Supprimer une agenda ?"}</DialogTitle>
                <DialogContent>
                <DialogContentText id="agenda-description">
                    Êtes-vous sûr de supprimer cette agenda ?
                </DialogContentText>
                </DialogContent>
                <DialogActions>
                <Button onClick={() => setDeleteAgendaConfirmation(false)} color="primary">
                    Annuler
                </Button>
                <Button onClick={handleDeleteAgenda} color="primary" autoFocus>
                    Supprimer
                </Button>
                </DialogActions>
            </Dialog>
            <Dialog
                open={deleteEtablissementConfirmation}
                onClose={() => setDeleteEtablissementConfirmation(false)}
                aria-labelledby="etablissement-title"
                aria-describedby="etablissement-description"
            >
                <DialogTitle id="etablissement-title">{"Supprimer une établissement ?"}</DialogTitle>
                <DialogContent>
                <DialogContentText id="etablissement-description">
                    Êtes-vous sûr de supprimer cette établissement ?
                </DialogContentText>
                </DialogContent>
                <DialogActions>
                <Button onClick={() => setDeleteEtablissementConfirmation(false)} color="primary">
                    Annuler
                </Button>
                <Button onClick={handleDeleteEtablissement} color="primary" autoFocus>
                    Supprimer
                </Button>
                </DialogActions>
            </Dialog>
            <Dialog
                open={deleteDoctorConfirmation}
                onClose={() => setDeleteDoctorConfirmation(false)}
                aria-labelledby="doctor-title"
                aria-describedby="doctor-description"
            >
                <DialogTitle id="doctor-title">{"Supprimer un médecin ?"}</DialogTitle>
                <DialogContent>
                <DialogContentText id="doctor-description">
                    Êtes-vous sûr de supprimer cet médecin ?
                </DialogContentText>
                </DialogContent>
                <DialogActions>
                <Button onClick={() => setDeleteDoctorConfirmation(false)} color="primary">
                    Annuler
                </Button>
                <Button onClick={handleDeleteDoctor} color="primary" autoFocus>
                    Supprimer
                </Button>
                </DialogActions>
            </Dialog>
        </Paper>
    );
}
