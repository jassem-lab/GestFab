import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import {
  Grid,
  makeStyles,
  TextField,
  Typography,
  Button,
  withStyles,
  TableRow,
  TableCell,
  TableContainer,
  Table,
  TableHead,
  TableBody,
  Tooltip,
} from "@material-ui/core";
import {
  KeyboardDatePicker,
  MuiPickersUtilsProvider,
} from "@material-ui/pickers";
import moment from "moment";
import MomentUtils from "@date-io/moment";
import { createTemplate, editTemplate } from "../../../actions/agendas";
import AddIcon from "@material-ui/icons/Add";
import CancelPresentationIcon from "@material-ui/icons/CancelPresentation";
import FileCopyIcon from "@material-ui/icons/FileCopy";
import CloudDownloadIcon from "@material-ui/icons/CloudDownload";
import DialpadIcon from "@material-ui/icons/Dialpad";

const StyledTableCell = withStyles((theme) => ({
  head: {
    backgroundColor: theme.palette.common.black,
    color: theme.palette.common.white,
  },
  body: {
    fontSize: 14,
  },
}))(TableCell);

const StyledTableRow = withStyles((theme) => ({
  root: {
    "&:nth-of-type(odd)": {
      backgroundColor: theme.palette.action.hover,
    },
  },
}))(TableRow);

const useStyles = makeStyles((theme) => ({
  formControl: {
    minWidth: 120,
    height: 20,
  },
  saveButton: {
    paddingTop: 10,
  },
  loading: {
    width: "20px",
    marginLeft: "10px",
  },
  divider: {
    marginTop: "30px",
  },
  datePicker: {
    margin: "0",
  },
  cellulesInput: {
    width: "90%",
    margin: "5px 5%",
  },
  addInterval: {
    fontSize: "16px",
    margin: "5px",
    cursor: "pointer",
    transition: "all 0.3s ease-in-out",
    "&:hover": {
      transform: "scale(1.1)",
    },
  },
  removeInterval: {
    fontSize: "16px",
    margin: "5px",
    cursor: "pointer",
    transition: "all 0.3s ease-in-out",
    "&:hover": {
      transform: "scale(1.1)",
    },
  },
  timeInput: {
    margin: "2px",
  },
  interval: {
    display: "block",
    padding: "5px",
    border: "1px dashed #e0e0e0",
    margin: "5px",
  },
  copyIcons: {
    margin: "3px",
    fontSize: "16px",
    cursor: "pointer",
    color: "#AAA",
    opacity: "0.6",
    transition: "all 0.3s ease-in-out",
    "&:hover": {
      transform: "scale(1.1)",
      opacity: "1",
    },
  },
}));

export default function TableConfig(props) {
  const { agenda, show, etablissement, doctors } = props;
  const dispatch = useDispatch();
  const { AgendasIsLoading } = useSelector((state) => state.agendas);
  const classes = useStyles();
  const [feedback, setFeedback] = useState(null);
  const [copiedRow, setCopiedRow] = useState(null);
  const dayArray = [1, 2, 3, 4, 5, 6, 0];

  const calculateIntervalDate = () => {
    let startTime = etablissement?.startDayHour
      ? moment()
          .add(0, "days")
          .hours(etablissement?.startDayHour)
          .minute(0)
          .second(0)
      : null;
    let endTime = etablissement?.endDayHour
      ? moment()
          .add(0, "days")
          .hours(etablissement?.endDayHour)
          .minute(0)
          .second(0)
      : null;
    let myIntervals = [];
    while (startTime?.isBefore(endTime)) {
      myIntervals.push({
        cellules: 0,
        start: startTime.format("HH:mm"),
        end: startTime.add(30, "minutes").format("HH:mm"),
      });
    }
    return myIntervals;
  };

  const generateNewTable = () => {
    const newTable = [];
    agenda?.consultationsTypes?.map((consultationType, index) =>
      newTable.push({
        type: consultationType,
        color: "#b3294e",
        days: [
          {
            dayIndex: 0,
            intervals: [
              {
                cellules: 0,
                start: "00:00",
                end: "00:00",
              },
            ],
          },
          {
            dayIndex: 1,
            intervals: [
              {
                cellules: 0,
                start: "00:00",
                end: "00:00",
              },
            ],
          },
          {
            dayIndex: 2,
            intervals: [
              {
                cellules: 0,
                start: "00:00",
                end: "00:00",
              },
            ],
          },
          {
            dayIndex: 3,
            intervals: [
              {
                cellules: 0,
                start: "00:00",
                end: "00:00",
              },
            ],
          },
          {
            dayIndex: 4,
            intervals: [
              {
                cellules: 0,
                start: "00:00",
                end: "00:00",
              },
            ],
          },
          {
            dayIndex: 5,
            intervals: [
              {
                cellules: 0,
                start: "00:00",
                end: "00:00",
              },
            ],
          },
          {
            dayIndex: 6,
            intervals: [
              {
                cellules: 0,
                start: "00:00",
                end: "00:00",
              },
            ],
          },
        ],
      })
    );
    return newTable;
  };

  const [formData, setFormData] = useState({
    startDate: moment(),
    endDate: moment().add(6, "M"),
    durationPart: 30,
    rdvsByPart: 0,
    table: generateNewTable(),
  });

  const clear = () => {
    setFormData({
      startDate: moment(),
      endDate: moment().add(6, "M"),
      durationPart: 30,
      rdvsByPart: 0,
      table: generateNewTable(),
    });
  };

  const handlePastRow = (target) => {
    if (copiedRow && target) {
      setFormData({
        ...formData,
        table: formData.table.map((cs, index) => {
          return {
            ...cs,
            days: cs.days.map((day) => {
              if (day.dayIndex === target) {
                return {
                  ...day,
                  intervals: formData.table[index].days[copiedRow].intervals,
                };
              }
              return day;
            }),
          };
        }),
      });
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!doctors || doctors.length === 0) {
      setFeedback("Veuillez ajouter des docteurs avant de sauvegarder");
      return;
    }
    if (
      !doctors.find((doctor) => doctor.agendas.includes(agenda._id)) ||
      doctors.find((doctor) => doctor.agendas.includes(agenda._id)) ===
        undefined
    ) {
      setFeedback(
        "Veuillez affectez cette agenda a un docteur avant de sauvegarder"
      );
      return;
    }

    if (agenda) {
      if (agenda.template) {
        dispatch(editTemplate(agenda._id, formData)).then(() => {
          setFeedback("Agenda modifiée");
          props.close();
        });
      } else {
        dispatch(createTemplate(agenda._id, formData)).then(() => {
          setFeedback("Agenda configurée");
          clear();
          props.close();
        });
      }
    }
  };

  useEffect(() => {
    if (agenda && agenda.template) {
      setFormData({
        startDate: agenda.template.startDate,
        endDate: agenda.template.endDate,
        durationPart: agenda.template.durationPart,
        rdvsByPart: agenda.template.rdvsByPart,
        table: agenda.template.table,
      });
    }
  }, [agenda, agenda?.template]);

  if (!show) return null;

  return (
    <form>
      <Grid container spacing={3} className="griditem">
        <Grid item xs={12}>
          <Typography variant="h4" style={{ marginTop: "10px" }}>
            Configuration de l'agenda{" "}
          </Typography>
        </Grid>
        <Grid item xs={3}>
          <MuiPickersUtilsProvider utils={MomentUtils}>
            <KeyboardDatePicker
              className={classes.datePicker}
              disableToolbar
              variant="inline"
              format="DD/MM/YYYY"
              margin="normal"
              id="startDate"
              label="Date Debut"
              value={formData.startDate}
              onChange={(newDate) =>
                setFormData({ ...formData, startDate: newDate })
              }
              KeyboardButtonProps={{
                "aria-label": "change date",
              }}
            />
          </MuiPickersUtilsProvider>
        </Grid>
        <Grid item xs={3}>
          <MuiPickersUtilsProvider utils={MomentUtils}>
            <KeyboardDatePicker
              className={classes.datePicker}
              disableToolbar
              variant="inline"
              format="DD/MM/YYYY"
              margin="normal"
              id="endDate"
              label="Date Fin"
              value={formData.endDate}
              onChange={(newDate) =>
                setFormData({ ...formData, endDate: newDate })
              }
              KeyboardButtonProps={{
                "aria-label": "change date",
              }}
            />
          </MuiPickersUtilsProvider>
        </Grid>
        <Grid item xs={3}>
          <TextField
            fullWidth
            name="durationPart"
            id="durationPart"
            label="Durée"
            value={formData.durationPart}
            onChange={(e) =>
              setFormData({ ...formData, durationPart: e.target.value })
            }
          />
        </Grid>
        <Grid item xs={3}>
          {/* <TextField fullWidth name="rdvsByPart" id="rdvsByPart" label="Rdvs/Durée" value={formData.rdvsByPart} onChange={e => setFormData({ ...formData, rdvsByPart : e.target.value})} /> */}
        </Grid>
        <Grid item xs={12}>
          <TableContainer>
            <Table className={classes.table} aria-label="Config Table">
              <TableHead>
                <TableRow>
                  <StyledTableCell>Type de consultation</StyledTableCell>
                  <StyledTableCell align="center">Couleur</StyledTableCell>
                  <StyledTableCell align="center">
                    Lundi
                    <span
                      style={{
                        display: "flex",
                        justifyContent: "center",
                        alignItems: "center",
                      }}
                    >
                      <Tooltip title="Copier le jour">
                        <FileCopyIcon
                          onClick={() => setCopiedRow(1)}
                          className={classes.copyIcons}
                          style={copiedRow === 1 ? { opacity: "1" } : {}}
                        />
                      </Tooltip>
                      {copiedRow && copiedRow !== 1 ? (
                        <Tooltip title="Coller le jour">
                          <CloudDownloadIcon
                            onClick={() => handlePastRow(1)}
                            className={classes.copyIcons}
                          />
                        </Tooltip>
                      ) : null}
                    </span>
                  </StyledTableCell>
                  <StyledTableCell align="center">
                    Mardi
                    <span
                      style={{
                        display: "flex",
                        justifyContent: "center",
                        alignItems: "center",
                      }}
                    >
                      <Tooltip title="Copier le jour">
                        <FileCopyIcon
                          onClick={() => setCopiedRow(2)}
                          className={classes.copyIcons}
                          style={copiedRow === 2 ? { opacity: "1" } : {}}
                        />
                      </Tooltip>
                      {copiedRow && copiedRow !== 2 ? (
                        <Tooltip title="Coller le jour">
                          <CloudDownloadIcon
                            onClick={() => handlePastRow(2)}
                            className={classes.copyIcons}
                          />
                        </Tooltip>
                      ) : null}
                    </span>
                  </StyledTableCell>
                  <StyledTableCell align="center">
                    Mercredi
                    <span
                      style={{
                        display: "flex",
                        justifyContent: "center",
                        alignItems: "center",
                      }}
                    >
                      <Tooltip title="Copier le jour">
                        <FileCopyIcon
                          onClick={() => setCopiedRow(3)}
                          className={classes.copyIcons}
                          style={copiedRow === 3 ? { opacity: "1" } : {}}
                        />
                      </Tooltip>
                      {copiedRow && copiedRow !== 3 ? (
                        <Tooltip title="Coller le jour">
                          <CloudDownloadIcon
                            onClick={() => handlePastRow(3)}
                            className={classes.copyIcons}
                          />
                        </Tooltip>
                      ) : null}
                    </span>
                  </StyledTableCell>
                  <StyledTableCell align="center">
                    Jeudi
                    <span
                      style={{
                        display: "flex",
                        justifyContent: "center",
                        alignItems: "center",
                      }}
                    >
                      <Tooltip title="Copier le jour">
                        <FileCopyIcon
                          onClick={() => setCopiedRow(4)}
                          className={classes.copyIcons}
                          style={copiedRow === 4 ? { opacity: "1" } : {}}
                        />
                      </Tooltip>
                      {copiedRow && copiedRow !== 4 ? (
                        <Tooltip title="Coller le jour">
                          <CloudDownloadIcon
                            onClick={() => handlePastRow(4)}
                            className={classes.copyIcons}
                          />
                        </Tooltip>
                      ) : null}
                    </span>
                  </StyledTableCell>
                  <StyledTableCell align="center">
                    Vendredi
                    <span
                      style={{
                        display: "flex",
                        justifyContent: "center",
                        alignItems: "center",
                      }}
                    >
                      <Tooltip title="Copier le jour">
                        <FileCopyIcon
                          onClick={() => setCopiedRow(5)}
                          className={classes.copyIcons}
                          style={copiedRow === 5 ? { opacity: "1" } : {}}
                        />
                      </Tooltip>
                      {copiedRow && copiedRow !== 5 ? (
                        <Tooltip title="Coller le jour">
                          <CloudDownloadIcon
                            onClick={() => handlePastRow(5)}
                            className={classes.copyIcons}
                          />
                        </Tooltip>
                      ) : null}
                    </span>
                  </StyledTableCell>
                  <StyledTableCell align="center">
                    Samedi
                    <span
                      style={{
                        display: "flex",
                        justifyContent: "center",
                        alignItems: "center",
                      }}
                    >
                      <Tooltip title="Copier le jour">
                        <FileCopyIcon
                          onClick={() => setCopiedRow(6)}
                          className={classes.copyIcons}
                          style={copiedRow === 6 ? { opacity: "1" } : {}}
                        />
                      </Tooltip>
                      {copiedRow && copiedRow !== 6 ? (
                        <Tooltip title="Coller le jour">
                          <CloudDownloadIcon
                            onClick={() => handlePastRow(6)}
                            className={classes.copyIcons}
                          />
                        </Tooltip>
                      ) : null}
                    </span>
                  </StyledTableCell>
                  <StyledTableCell align="center">
                    Dimanche
                    <span
                      style={{
                        display: "flex",
                        justifyContent: "center",
                        alignItems: "center",
                      }}
                    >
                      <Tooltip title="Copier le jour">
                        <FileCopyIcon
                          onClick={() => setCopiedRow(0)}
                          className={classes.copyIcons}
                          style={copiedRow === 6 ? { opacity: "1" } : {}}
                        />
                      </Tooltip>
                      {copiedRow && copiedRow !== 0 ? (
                        <Tooltip title="Coller le jour">
                          <CloudDownloadIcon
                            onClick={() => handlePastRow(0)}
                            className={classes.copyIcons}
                          />
                        </Tooltip>
                      ) : null}
                    </span>
                  </StyledTableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {formData?.table?.map((consultationType, index) => (
                  <StyledTableRow
                    key={index}
                    style={{ background: `${consultationType.color} / 20%` }}
                  >
                    <StyledTableCell component="th" scope="row">
                      {consultationType.type}
                    </StyledTableCell>
                    <StyledTableCell component="th" scope="row">
                      <TextField
                        name="color"
                        label="Couleur"
                        type="color"
                        className={classes.textField}
                        value={consultationType.color}
                        onChange={(e) =>
                          setFormData({
                            ...formData,
                            table: formData.table?.map((row, i) => {
                              if (i === index) {
                                return {
                                  ...row,
                                  color: e.target.value,
                                };
                              }
                              return row;
                            }),
                          })
                        }
                        style={{ minWidth: "40px", cursor: "pointer" }}
                        InputLabelProps={{ shrink: true }}
                        inputProps={{ step: 300 }}
                      />
                    </StyledTableCell>
                    {/* days Cellule */}
                    {dayArray.map((dayNumber) => (
                      <StyledTableCell key={dayNumber} align="center">
                        <span style={{ display: "flex", alignItems: "center" }}>
                          <DialpadIcon
                            onClick={(e) => {
                              setFormData({
                                ...formData,
                                table: formData.table.map((row, i) => {
                                  if (i === index) {
                                    return {
                                      ...row,
                                      days: row.days.map((day, j) => {
                                        if (j === dayNumber) {
                                          return {
                                            ...day,
                                            intervals: calculateIntervalDate(),
                                          };
                                        }
                                        return day;
                                      }),
                                    };
                                  }
                                  return row;
                                }),
                              });
                            }}
                            className={classes.addInterval}
                            style={{ fontSize: "1.2rem" }}
                          />
                          <AddIcon
                            onClick={(e) => {
                              setFormData({
                                ...formData,
                                table: formData.table.map((row, i) => {
                                  if (i === index) {
                                    return {
                                      ...row,
                                      days: row.days.map((day, j) => {
                                        if (j === dayNumber) {
                                          return {
                                            ...day,
                                            intervals: day.intervals?.concat({
                                              cellules: 1,
                                              start: "00:00",
                                              end: "00:00",
                                            }),
                                          };
                                        }
                                        return day;
                                      }),
                                    };
                                  }
                                  return row;
                                }),
                              });
                            }}
                            className={classes.addInterval}
                          />
                        </span>
                        {consultationType?.days
                          ?.find((d) => d.dayIndex === dayNumber)
                          ?.intervals?.map((cell, cellIndex) => (
                            <span
                              key={`${index}-${cellIndex}-${dayNumber}`}
                              className={classes.interval}
                              style={
                                parseInt(cell.cellules) > 0
                                  ? { background: "#8ed991b8" }
                                  : { background: "#eee" }
                              }
                            >
                              {consultationType.days?.find(
                                (d) => d.dayIndex === dayNumber
                              )?.intervals?.length > 1 ? (
                                <CancelPresentationIcon
                                  onClick={(e) => {
                                    setFormData({
                                      ...formData,
                                      table: formData.table.map((row, i) => {
                                        if (i === index) {
                                          return {
                                            ...row,
                                            days: row.days.map((day, j) => {
                                              if (j === dayNumber) {
                                                return {
                                                  ...day,
                                                  intervals:
                                                    day.intervals?.filter(
                                                      (int, intIndex) =>
                                                        intIndex !== cellIndex
                                                    ),
                                                };
                                              }
                                              return day;
                                            }),
                                          };
                                        }
                                        return row;
                                      }),
                                    });
                                  }}
                                  className={classes.removeInterval}
                                />
                              ) : null}
                              <TextField
                                name={`cellules-${index}`}
                                label="Cellules"
                                type="number"
                                className={classes.cellulesInput}
                                value={cell.cellules}
                                onChange={(e) => {
                                  setFormData({
                                    ...formData,
                                    table: formData.table.map((row, i) => {
                                      if (i === index) {
                                        return {
                                          ...row,
                                          days: row.days.map((day, j) => {
                                            if (j === dayNumber) {
                                              return {
                                                ...day,
                                                intervals: day.intervals?.map(
                                                  (interval, k) => {
                                                    if (k === cellIndex) {
                                                      return {
                                                        ...interval,
                                                        cellules:
                                                          e.target.value,
                                                      };
                                                    }
                                                    return interval;
                                                  }
                                                ),
                                              };
                                            }
                                            return day;
                                          }),
                                        };
                                      }
                                      return row;
                                    }),
                                  });
                                }}
                              />
                              <TextField
                                name="start"
                                label="Debut"
                                type="time"
                                className={classes.timeInput}
                                value={cell.start}
                                onChange={(e) => {
                                  setFormData({
                                    ...formData,
                                    table: formData.table.map((row, i) => {
                                      if (i === index) {
                                        return {
                                          ...row,
                                          days: row.days.map((day, j) => {
                                            if (j === dayNumber) {
                                              return {
                                                ...day,
                                                intervals: day.intervals?.map(
                                                  (interval, k) => {
                                                    if (k === cellIndex) {
                                                      return {
                                                        ...interval,
                                                        start: e.target.value,
                                                      };
                                                    }
                                                    return interval;
                                                  }
                                                ),
                                              };
                                            }
                                            return day;
                                          }),
                                        };
                                      }
                                      return row;
                                    }),
                                  });
                                }}
                                InputLabelProps={{ shrink: true }}
                                inputProps={{ step: 300 }}
                              />
                              <TextField
                                name="end"
                                label="Fin"
                                type="time"
                                className={classes.timeInput}
                                value={cell.end}
                                onChange={(e) => {
                                  setFormData({
                                    ...formData,
                                    table: formData.table.map((row, i) => {
                                      if (i === index) {
                                        return {
                                          ...row,
                                          days: row.days.map((day, j) => {
                                            if (j === dayNumber) {
                                              return {
                                                ...day,
                                                intervals: day.intervals?.map(
                                                  (interval, k) => {
                                                    if (k === cellIndex) {
                                                      return {
                                                        ...interval,
                                                        end: e.target.value,
                                                      };
                                                    }
                                                    return interval;
                                                  }
                                                ),
                                              };
                                            }
                                            return day;
                                          }),
                                        };
                                      }
                                      return row;
                                    }),
                                  });
                                }}
                                InputLabelProps={{ shrink: true }}
                                inputProps={{ step: 300 }}
                              />
                            </span>
                          ))}
                      </StyledTableCell>
                    ))}
                  </StyledTableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
        </Grid>
      </Grid>
      {/* disabled={agenda?.template ? true : false}  */}
      <Button
        style={{ marginTop: "50px", marginRight: "10px" }}
        variant="contained"
        color="secondary"
        type="submit"
        onClick={(e) => handleSubmit(e)}
      >
        Enregistrer
        {AgendasIsLoading ? (
          <img
            className={classes.loading}
            src="/images/loading.gif"
            alt="Loading"
          />
        ) : null}
      </Button>
      <Button
        onClick={props.close}
        style={{ marginTop: "50px" }}
        variant="contained"
        color="primary"
      >
        Annuler
      </Button>
      {feedback ? (
        <p style={{ color: "#080", marginTop: "15px" }}>{feedback}</p>
      ) : null}
    </form>
  );
}
