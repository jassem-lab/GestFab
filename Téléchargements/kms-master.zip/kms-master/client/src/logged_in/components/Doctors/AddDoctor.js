import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Divider, Grid, makeStyles,TextField, Typography, Button, FormControl, InputLabel, Select, FormLabel, FormGroup, FormControlLabel, Checkbox, MenuItem, Input, ListItemText } from '@material-ui/core';
import { createDoctor, editDoctor } from '../../../actions/doctors';

const useStyles = makeStyles((theme) => ({
    formControl: {
        minWidth: 120,
        height: 20,
        display: 'flex',
    },
    saveButton: {
        paddingTop: 10,
    },
    loading: {
        width: '20px',
        marginLeft: '10px',
    },
    divider: {
        marginTop: '30px',
    }
}));

export default function AddDoctor(props) {
    const {doctor, etablissements, agendas, show} = props
    const dispatch = useDispatch()
    const { DoctorsIsLoading } = useSelector(state => state.doctors)
    const classes = useStyles();
    const [feedback, setFeedback] = useState(null);
    const [formData, setFormData] = useState({
        name: '',
        phone: '',
        email: '',
        password: '',
        etablissementId: null,
        etablissementName: '',
        etablissementPhone: '',
        etablissementAdress: '',
        postalCode: '',
        city: '',
        startDayHour: 8,
        endDayHour: 19,
        excludedDays: [6, 0],
        agendas: [],
    });

    const clear = () => {
        setFormData({
            name: '',
            phone: '',
            email: '',
            password: '',
            etablissementId: null,
            etablissementName: '',
            etablissementPhone: '',
            etablissementAdress: '',
            postalCode: '',
            city: '',
            startDayHour: 8,
            endDayHour: 19,
            excludedDays: [6, 0],
            agendas: [],
        })
    }
     
    const handleSubmit = (e) => {
        e.preventDefault();

        if (formData.name.length === 0) {
            setFeedback("Veuillez entrer un nom.");
            if (document.getElementById('feedback')) {
                document.getElementById('feedback').style.color = 'red';
            }
            if (document.getElementById('doctorname')) {
                document.getElementById('doctorname').focus();
            }
            return;
        }

        if (formData.phone.length === 0) {
            setFeedback('Veuillez entrer un numéro de téléphone.');
            if (document.getElementById('feedback')) {
                document.getElementById('feedback').style.color = 'red';
            }
            if (document.getElementById('doctorphone')) {
                document.getElementById('doctorphone').focus();
            }
            return;
        }

        if (formData.email.length === 0) {
            setFeedback('Veuillez entrer un email.');
            if (document.getElementById('feedback')) {
                document.getElementById('feedback').style.color = 'red';
            }
            if (document.getElementById('doctoremail')) {
                document.getElementById('doctoremail').focus();
            }
            return;
        }

        if (!doctor) {
            if (formData.password.length === 0) {
                setFeedback('Veuillez entrer un mot de passe.');
                if (document.getElementById('feedback')) {
                    document.getElementById('feedback').style.color = 'red';
                }
                if (document.getElementById('doctorpassword')) {
                    document.getElementById('doctorpassword').focus();
                }
                return;
            }
    
            if (formData.password.length < 6) {
                setFeedback('Votre mot de passe doit contenir au moins 6 caractères.');
                if (document.getElementById('feedback')) {
                    document.getElementById('feedback').style.color = 'red';
                }
                if (document.getElementById('doctorpassword')) {
                    document.getElementById('doctorpassword').focus();
                }
                return;
            }
        }

        if (formData.etablissementId === '') {
            if (formData.etablissementName.length === 0) {
                setFeedback("Veuillez entrer un nom d'établissement.");
                if (document.getElementById('feedback')) {
                    document.getElementById('feedback').style.color = 'red';
                }
                if (document.getElementById('etablissementname')) {
                    document.getElementById('etablissementname').focus();
                }
                return;
            }
            if (formData.etablissementPhone.length === 0) {
                setFeedback('Veuillez entrer un numéro de téléphone.');
                if (document.getElementById('feedback')) {
                    document.getElementById('feedback').style.color = 'red';
                }
                if (document.getElementById('etablissementphone')) {
                    document.getElementById('etablissementphone').focus();
                }
                return;
            }
            if (formData.startDayHour > 23) {
                setFeedback('L\'heure de début doit être inférieure à 23h.');
                if (document.getElementById('feedback')) {
                    document.getElementById('feedback').style.color = 'red';
                }
                if (document.getElementById('startdayhour')) {  
                    document.getElementById('startdayhour').focus();
                }
                return;
            }
            if (formData.endDayHour > 24) {
                setFeedback('L\'heure de fin doit être inférieure à 24h.');
                if (document.getElementById('feedback')) {
                    document.getElementById('feedback').style.color = 'red';
                }
                if (document.getElementById('enddayhour')) {
                    document.getElementById('enddayhour').focus();
                }
                return;
            }
            if (formData.startDayHour >= formData.endDayHour) {
                setFeedback('L\'heure de début doit être inférieure à l\'heure de fin.');
                if (document.getElementById('feedback')) {
                    document.getElementById('feedback').style.color = 'red';
                }
                if (document.getElementById('startdayhour')) {
                    document.getElementById('startdayhour').focus();
                }
                return;
            }
        }

        if (doctor) {
           dispatch(editDoctor(doctor._id, formData)).then(() => {
               setFeedback('Médecin modifié');
           })
        } else {
            dispatch(createDoctor(formData)).then(() => {
                setFeedback('Médecin ajouté');
                clear();
                props.close();
            })  
        }
    }

    useEffect(() => {
        if (doctor) {
            setFormData({
                name: doctor.user?.name,
                phone: doctor.user?.phone,
                email: doctor.user?.email,
                password: '',
                etablissementId: doctor.etablissement?._id,
                agendas: doctor.agendas || [],
            });
        }
    }, [doctor])

    if (!show) return null;

    return (
        <form>
            <Grid container spacing={3} className="griditem">
                <Grid item xs={12}>
                    <Typography variant="h4" style={{ marginTop: '10px' }}> {doctor ? 'Modifation' : 'Ajout'} de médecin </Typography>
                </Grid>
                <Grid item xs={6}>
                    <TextField required fullWidth name="doctorname" id="doctorname" label="Nom" value={formData.name} onChange={e => setFormData({ ...formData, name : e.target.value})} />
                </Grid>
                <Grid item xs={6}>
                    <TextField disabled={doctor ? true : false} fullWidth type="email" autoComplete='off' name="doctoremail" id="doctoremail" label="E-mail" value={formData.email} onChange={e => setFormData({ ...formData, email : e.target.value})} />
                </Grid>
                <Grid item xs={6}>
                    <TextField fullWidth name="doctorphone" id="doctorphone" label="Téléphone" value={formData.phone} onChange={e => setFormData({ ...formData, phone : e.target.value})} />
                </Grid>
                <Grid item xs={6}>
                    <TextField required fullWidth type="password" autoComplete='off' name="password" id="doctorpassword" label="Mot de passe" value={formData.password} onChange={e => setFormData({ ...formData, password : e.target.value})} />
                </Grid>
            </Grid>
            <Divider className={classes.divider}/>
            <Grid container spacing={3} className="griditem" style={{ backgroundColor: 'rgb(162 153 179 / 20%)', paddingBottom: '40px' }} >
                <Grid item xs={6}>
                    <Typography variant="h6" style={{ marginTop: '20px' }}> Etablissement </Typography>
                </Grid>
                <Grid item xs={6}>
                    {
                        etablissements && (
                            <FormControl style={{ width: '100%',  marginTop: '10px' }}>
                                <InputLabel id="etablissements-label">Etablissement Existante</InputLabel>
                                <Select
                                native
                                value={formData.etablissementId}
                                onChange={(e) => setFormData({ ...formData, etablissementId: e.target.value })}
                                inputProps={{ name: 'etablissements', id: 'etablissements-simple' }} >
                                
                                <option aria-label="None" value="" />
                                
                                {etablissements.map((etablissement) => (
                                    <option key={etablissement._id} value={etablissement._id}>
                                       {etablissement.name}
                                    </option>
                                ))}
                                </Select>
                            </FormControl>
                        )
                    }
                </Grid>
                {
                    !formData.etablissementId ? (
                        <> 
                            <Grid item xs={6}>
                                <TextField fullWidth name="etablissementname" id="etablissementname" label="Nom Etablissement" value={formData.etablissementName} onChange={e => setFormData({ ...formData, etablissementName : e.target.value})} />
                            </Grid>
                            <Grid item xs={6}>
                                <TextField fullWidth name="etablissementphone" id="etablissementphone" label="Tél. Etablissement" value={formData.etablissementPhone} onChange={e => setFormData({ ...formData, etablissementPhone : e.target.value})} />
                            </Grid>
                            <Grid item xs={12}>
                                <TextField fullWidth name="etablissementadress" id="etablissementadress" label="Adresse" value={formData.etablissementAdress} onChange={e => setFormData({ ...formData, etablissementAdress : e.target.value})} />
                            </Grid>
                            <Grid item xs={6}>
                                <TextField fullWidth name="postalcode" id="postalcode" label="Code Postal" value={formData.postalCode} onChange={e => setFormData({ ...formData, postalCode : e.target.value})} />
                            </Grid>
                            <Grid item xs={6}>
                                <TextField fullWidth name="city" id="city" label="Ville" value={formData.city} onChange={e => setFormData({ ...formData, city : e.target.value})} />
                            </Grid>
                            <Grid item xs={4}>
                                <TextField type="Number" fullWidth name="startdayhour" id="startdayhour" label="Heure début" value={formData.startDayHour} onChange={e => setFormData({ ...formData, startDayHour : e.target.value})} />
                            </Grid>
                            <Grid item xs={4}>
                                <TextField type="Number" fullWidth name="enddayhour" id="enddayhour" label="Heure fin" value={formData.endDayHour} onChange={e => setFormData({ ...formData, endDayHour : e.target.value})} />
                            </Grid>
                            <Grid item xs={4}>
                                <FormControl component="fieldset" className={classes.formControl}>
                                    <FormLabel component="legend">Weekend</FormLabel>
                                    <FormGroup>
                                        <FormControlLabel
                                            control={<Checkbox checked={formData.excludedDays?.includes(6)} 
                                            onChange={e => {
                                                if (formData.excludedDays?.includes(6)) {
                                                    setFormData({ ...formData, excludedDays: formData.excludedDays?.filter(day => day !== 6) })
                                                } else {
                                                    setFormData({ ...formData, excludedDays: [...formData.excludedDays, 6] })
                                                }
                                            }} value={6} />}
                                            label="Samedi"
                                        />
                                        <FormControlLabel
                                            control={<Checkbox checked={formData.excludedDays?.includes(0)} 
                                            onChange={e => {
                                                if (formData.excludedDays?.includes(0)) {
                                                    setFormData({ ...formData, excludedDays: formData.excludedDays?.filter(day => day !== 0) })
                                                } else {
                                                    setFormData({ ...formData, excludedDays: [...formData.excludedDays, 0] })
                                                }
                                            }} value={0} />}
                                            label="Dimanche"
                                        />
                                    </FormGroup>
                                </FormControl>
                            </Grid>
                        </>
                    ) : null
                }
            </Grid>
            <Divider  className={classes.divider}/>
            <Grid container spacing={3} className="griditem" style={{ backgroundColor: 'rgb(191 168 176 / 20%)', paddingBottom: '30px' }} >
                <Grid item xs={6}>
                    <Typography variant="h6" style={{ marginTop: '20px' }}> Agendas </Typography>
                </Grid>
                <Grid item xs={12}>
                    {
                        agendas && (
                            <FormControl className={classes.formControl}>
                                <InputLabel id="demo-mutiple-checkbox-label">Agendas</InputLabel>
                                <Select style={{ width: '100%',  marginTop: '10px' }}
                                    labelId="mutiple-label"
                                    id="mutiple-checkbox"
                                    multiple
                                    value={formData.agendas}
                                    onChange={(event) => setFormData({ ...formData, agendas: event.target.value?.filter(r => r !== undefined) })}
                                    input={<Input />}
                                    renderValue={(selected) => {
                                    const res = [];
                                    selected?.forEach(element => {
                                        res.push(agendas.find(agenda => agenda._id === element)?.name)
                                    });
                                    //console.log(res)
                                    return res.filter(r => r !== undefined).join(', ');
                                }}
                                >
                                {agendas.map((agenda) => (
                                    <MenuItem key={agenda._id} value={agenda._id}>
                                        <Checkbox checked={formData.agendas?.indexOf(agenda._id) > -1} />
                                        <ListItemText primary={agendas?.find(ag => ag._id === agenda._id)?.name} />
                                    </MenuItem>
                                ))}
                                </Select>
                            </FormControl>
                        )
                    }
                </Grid>
            </Grid>
            <Button style={{ marginTop: '50px', marginRight: '10px' }} variant="contained" color="secondary" type="submit" onClick={e => handleSubmit(e)}>
                Enregistrer
                {
                    DoctorsIsLoading ? (
                        <img className={classes.loading} src='/images/loading.gif' alt='Loading' />
                    ) : null
                }
            </Button>
            <Button onClick={props.close} style={{ marginTop: '50px' }} variant="contained" color="primary">
                Annuler
            </Button>
            {
                feedback ? (
                    <p id="feedback" style={{ color: '#080', marginTop: '15px' }}>{feedback}</p>
                ) : null
            }
            
        </form>
    )
}