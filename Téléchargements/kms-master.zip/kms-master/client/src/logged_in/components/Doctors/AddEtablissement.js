import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import {  Grid, makeStyles,TextField, Typography, Button, FormControl, FormLabel, FormControlLabel, Checkbox } from '@material-ui/core';
import { createEtablissement, editEtablissement } from '../../../actions/etablissements';

const useStyles = makeStyles((theme) => ({
    formControl: {
        minWidth: 120,
        height: 20,
        display: 'flex',
    },
    saveButton: {
        paddingTop: 10,
    },
    loading: {
        width: '20px',
        marginLeft: '10px',
    },
    divider: {
        marginTop: '30px',
    }
}));

export default function AddEtablissement(props) {
    const {etablissement, show} = props
    const dispatch = useDispatch()
    const { EtablissementsIsLoading } = useSelector(state => state.etablissements)
    const classes = useStyles();
    const [feedback, setFeedback] = useState(null);
    const [formData, setFormData] = useState({
        etablissementName: '',
        etablissementPhone: '',
        etablissementAdress: '',
        postalCode: '',
        city: '',
        startDayHour: 7,
        endDayHour: 21,
        excludedDays: [0],
    });

    const clear = () => {
        setFormData({
            etablissementName: '',
            etablissementPhone: '',
            etablissementAdress: '',
            postalCode: '',
            city: '',
            startDayHour: 7,
            endDayHour: 21,
            excludedDays: [0],
        })
    }

    const handleSubmit = (e) => {
        e.preventDefault();

        if (formData.etablissementName.length === 0) {
            setFeedback("Veuillez entrer un nom d'établissement.");
            if (document.getElementById('feedback')) {
                document.getElementById('feedback').style.color = 'red';
            }
            if (document.getElementById('etablissementname')) {
                document.getElementById('etablissementname').focus();
            }
            return;
        }
        if (formData.etablissementPhone.length === 0) {
            setFeedback('Veuillez entrer un numéro de téléphone.');
            if (document.getElementById('feedback')) {
                document.getElementById('feedback').style.color = 'red';
            }
            if (document.getElementById('etablissementphone')) {
                document.getElementById('etablissementphone').focus();
            }
            return;
        }
        if (parseInt(formData.startDayHour) > 23) {
            setFeedback('L\'heure de début doit être inférieure à 23h.');
            if (document.getElementById('feedback')) {
                document.getElementById('feedback').style.color = 'red';
            }
            if (document.getElementById('startdayhour')) {  
                document.getElementById('startdayhour').focus();
            }
            return;
        }
        if (parseInt(formData.endDayHour) > 24) {
            setFeedback('L\'heure de fin doit être inférieure à 24h.');
            if (document.getElementById('feedback')) {
                document.getElementById('feedback').style.color = 'red';
            }
            if (document.getElementById('enddayhour')) {
                document.getElementById('enddayhour').focus();
            }
            return;
        }
        if (parseInt(formData.startDayHour) >= parseInt(formData.endDayHour)) {
            setFeedback('L\'heure de début doit être inférieure à l\'heure de fin.');
            if (document.getElementById('feedback')) {
                document.getElementById('feedback').style.color = 'red';
            }
            if (document.getElementById('startdayhour')) {
                document.getElementById('startdayhour').focus();
            }
            return;
        }
        
        if (etablissement) {
           dispatch(editEtablissement(etablissement._id, formData)).then(() => {
               setFeedback('Etablissement modifié');
               props.close();
           })
        } else {
            dispatch(createEtablissement(formData)).then(() => {
                setFeedback('Etablissement ajouté');
                clear();
                props.close();
            })  
        }
    }

    useEffect(() => {
        if (etablissement) {
            setFormData({
                etablissementName: etablissement.name,
                etablissementPhone: etablissement.phone,
                etablissementAdress: etablissement.address,
                postalCode: etablissement.postalCode,
                city: etablissement.city,
                startDayHour: etablissement.startDayHour,
                endDayHour: etablissement.endDayHour,
                excludedDays: etablissement.excludedDays,
            });
        }
    }, [etablissement])

    if (!show) return null;

    return (
        <form>
            <Grid container spacing={3} className="griditem" >
                <Grid item xs={12}>
                    <Typography variant="h4" style={{ marginTop: '10px' }}> {etablissement ? 'Modification' : 'Ajout' } d'établissement </Typography>
                </Grid>
                <Grid item xs={6}>
                    <TextField fullWidth name="etablissementName" id="etablissementname" label="Nom Etablissement" value={formData.etablissementName} onChange={e => setFormData({ ...formData, etablissementName : e.target.value})} />
                </Grid>
                <Grid item xs={6}>
                    <TextField fullWidth name="etablissementPhone" id="etablissementphone" label="Tél. Etablissement" value={formData.etablissementPhone} onChange={e => setFormData({ ...formData, etablissementPhone : e.target.value})} />
                </Grid>
                <Grid item xs={12}>
                    <TextField fullWidth name="etablissementAdress" id="etablissementadress" label="Adresse" value={formData.etablissementAdress} onChange={e => setFormData({ ...formData, etablissementAdress : e.target.value})} />
                </Grid>
                <Grid item xs={6}>
                    <TextField fullWidth name="postalCode" id="postalcode" label="Code Postal" value={formData.postalCode} onChange={e => setFormData({ ...formData, postalCode : e.target.value})} />
                </Grid>
                <Grid item xs={6}>
                    <TextField fullWidth name="city" id="city" label="Ville" value={formData.city} onChange={e => setFormData({ ...formData, city : e.target.value})} />
                </Grid>
                <Grid item xs={4}>
                    <TextField type="Number" fullWidth name="startDayHour" id="startdayhour" label="Heure début" value={formData.startDayHour} onChange={e => setFormData({ ...formData, startDayHour : e.target.value})} />
                </Grid>
                <Grid item xs={4}>
                    <TextField type="Number" fullWidth name="endDayHour" id="enddayhour" label="Heure fin" value={formData.endDayHour} onChange={e => setFormData({ ...formData, endDayHour : e.target.value})} />
                </Grid>
                <Grid item xs={4}>
                    <FormControl component="fieldset" className={classes.formControl}>
                        <FormLabel component="legend">Weekend</FormLabel>
                        <FormControlLabel
                            control={<Checkbox checked={formData.excludedDays?.includes(6)} 
                            onChange={e => {
                                if (formData.excludedDays?.includes(6)) {
                                    setFormData({ ...formData, excludedDays: formData.excludedDays?.filter(day => day !== 6) })
                                } else {
                                    setFormData({ ...formData, excludedDays: [...formData.excludedDays, 6] })
                                }
                            }} value={6} />}
                            label="Samedi"
                        />
                        <FormControlLabel
                            control={<Checkbox checked={formData.excludedDays?.includes(0)} 
                            onChange={e => {
                                if (formData.excludedDays?.includes(0)) {
                                    setFormData({ ...formData, excludedDays: formData.excludedDays?.filter(day => day !== 0) })
                                } else {
                                    setFormData({ ...formData, excludedDays: [...formData.excludedDays, 0] })
                                }
                            }} value={0} />}
                            label="Dimanche"
                        />
                    </FormControl>
                </Grid>
            </Grid>
            <Button style={{ marginTop: '50px', marginRight: '10px' }} variant="contained" color="secondary" type="submit" onClick={e => handleSubmit(e)}>
                Enregistrer
                {
                    EtablissementsIsLoading ? (
                        <img className={classes.loading} src='/images/loading.gif' alt='Loading' />
                    ) : null
                }
            </Button>
            <Button onClick={props.close} style={{ marginTop: '50px' }} variant="contained" color="primary">
                Annuler
            </Button>
            {
                feedback ? (
                    <p id="feedback" style={{ color: '#080', marginTop: '15px' }}>{feedback}</p>
                ) : null
            }
            
        </form>
    )
}