import React, { memo } from "react";
import { Switch } from "react-router-dom";
import { withStyles } from "@material-ui/core";
import Dashboard from "./dashboard/Dashboard";
import PropsRoute from "../../shared/components/PropsRoute";
import useLocationBlocker from "../../shared/functions/useLocationBlocker";
import Appointment from "./Appointment/Appointment.js";
import Messenger from "./Messenger/Messenger";
import Patients from "./Patients/Patients";
import Doctors from "./Doctors/Doctors";
import Etablissements from "./Etablissements/Etablissements";
import Profile from "./Profile/Profile";
import CalendarContainer from "./Calendar/CalendarContainer";
import CalendarContainerVAD from "./CalendarVAD/CalendarContainer";
import Events from "./Event/Events";
import { RdvByPatient } from "./Patients/RdvByPatient";
import { ChatByPatient } from "./Patients/ChatByPatient";

const styles = (theme) => ({
  wrapper: {
    margin: theme.spacing(1),
    width: "auto",
    [theme.breakpoints.up("xs")]: {
      width: "99%",
      marginLeft: "auto",
      marginRight: "auto",
      marginTop: theme.spacing(1),
      marginBottom: theme.spacing(4),
    },
    [theme.breakpoints.up("sm")]: {
      marginTop: theme.spacing(1),
      marginBottom: theme.spacing(6),
      width: "99%",
      marginLeft: "auto",
      marginRight: "auto",
    },
    [theme.breakpoints.up("md")]: {
      marginTop: theme.spacing(1),
      marginBottom: theme.spacing(6),
      width: "99%",
      marginLeft: "auto",
      marginRight: "auto",
    },
    [theme.breakpoints.up("lg")]: {
      marginTop: theme.spacing(1),
      marginBottom: theme.spacing(6),
      width: "99%",
      marginLeft: "auto",
      marginRight: "auto",
    },
  },
});

function Routing(props) {
  const {
    chats,
    user,
    classes,
    selectCalendarVAD,
    selectDashboard,
    selectCalendar,
    selectAppointment,
    selectMessenger,
    selectPatients,
    selectDoctors,
    selectEtablissements,
    selectEvents,
    selectProfile,
    settings,
    etablissement,
    doctorsByEtab,
    agendas,
    etablissements,
    agendasByEtab,
  } = props;
  useLocationBlocker();

  return (
    <div className={classes.wrapper}>
      <Switch>
        <PropsRoute
          path="/c/calendar"
          component={CalendarContainer}
          selectCalendar={selectCalendar}
          settings={settings}
          etablissement={etablissement}
          doctors={doctorsByEtab}
          agendas={agendasByEtab}
        />
        <PropsRoute
          path="/c/Calendarvad"
          component={CalendarContainerVAD}
          selectCalendarVAD = {selectCalendarVAD}
          settings={settings}
          etablissement={etablissement}
          doctors={doctorsByEtab}
          agendas={agendasByEtab}
        />
        <PropsRoute
          path="/c/list-rdv"
          component={Appointment}
          selectAppointment={selectAppointment}
          etablissement={etablissement}
          doctorsByEtab={doctorsByEtab}
          agendas={agendasByEtab}
        />
        <PropsRoute
          path="/c/messenger"
          component={Messenger}
          selectMessenger={selectMessenger}
          etablissement={etablissement}
          doctorsByEtab={doctorsByEtab}
        />
        <PropsRoute
          path="/c/patients"
          component={Patients}
          selectPatients={selectPatients}
          etablissement={etablissement}
          doctorsByEtab={doctorsByEtab}
        />
        <PropsRoute
          path="/c/doctors"
          component={Doctors}
          selectDoctors={selectDoctors}
          etablissement={etablissement}
          etablissements={etablissements}
          doctors={doctorsByEtab}
          agendas={agendas}
        />
        <PropsRoute
          path="/c/etablissement"
          component={Etablissements}
          selectEtablissements={selectEtablissements}
        />

        <PropsRoute
          path="/c/profile"
          component={Profile}
          selectProfile={selectProfile}
          userID={user?._id}
          userEmail={user?.email}
        />

        <PropsRoute
          path="/c/events"
          component={Events}
          selectEvents={selectEvents}
        />

        <PropsRoute
          path=""
          component={Dashboard}
          selectDashboard={selectDashboard}
        />
      </Switch>
    </div>
  );
}

export default withStyles(styles, { withTheme: true })(memo(Routing));
