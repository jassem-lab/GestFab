import React, { Fragment, useEffect } from "react";
import PropTypes from "prop-types";
import { makeStyles } from "@material-ui/core";
import { Link } from "react-router-dom";
import { useHistory } from "react-router-dom";
import { useSelector } from "react-redux";
import Badge from "@mui/material/Badge";
import MailIcon from "@mui/icons-material/Mail";

const useStyles = makeStyles((theme) => ({
  container: {
    margin: "10px",
    padding: "40px",
  },
  flex: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
  },
  box: {
    position: "relative",
    width: "20%",
    height: "150px",
    boxShadow: "0px 0px 5px 0px rgba(0,0,0,0.75)",
    borderRadius: "5px",
    cursor: "pointer",
    overflow: "hidden",
  },
  bg: {
    width: "100%",
    height: "100%",
    position: "absolute",
    objectFit: "cover",
    top: "0",
    left: "0",
    zIndex: "-1",
  },
  overlay: {
    backgroundColor: "rgba(0,0,0,0.2)",
    display: "flex",
    height: "100%",
    justifyContent: "center",
    alignItems: "center",
    fontSize: "23px",
    fontWeight: "bold",
    color: "#fff",
    transition: "all 0.3s ease-in-out",
    "&:hover": {
      backgroundColor: "rgba(0,0,0,0.3)",
    },
  },
}));

function Dashboard(props) {
  const { chats } = useSelector((state) => state.chats);
  const { selectDashboard } = props;
  const classes = useStyles();
  const history = useHistory();
  const currentUser = JSON.parse(localStorage.getItem("profile"));
  if (currentUser?.user?.role === "patient") {
    history.push("/c/list-rdv");
  }

  useEffect(selectDashboard, [selectDashboard]);

  if (!currentUser) {
    history.push("/");
  }
  const count = chats.filter((item) => item.seen === false).length;

  const CheckkArray = (array) => {
    if (chats.filter((item) => item.seen === false).length > 0) {
      return (
        <div style={{ position: "absolute", top: "15px" }}>
          <Badge
            badgeContent={chats.filter((item) => item.seen === false).length}
            color="primary"
            style={{ zIndex: "3" }}
          >
            <MailIcon color="action" />
          </Badge>
        </div>
      );
    } else {
      return (
        <div style={{ position: "absolute", top: "15px" }}>
          <Badge badgeContent={0} color="primary" showZero>
            <MailIcon color="action" />
          </Badge>
        </div>
      );
    }
  };

  return (
    <Fragment>
      <div className={classes.container}>
        <div className={classes.flex}>
          <div className={classes.box}>
            <img
              className={classes.bg}
              src="/images/calendar.png"
              alt="agenda"
            />
            <Link to="/c/calendar" className={classes.overlay}>
              Agenda
            </Link>
          </div>
          <div className={classes.box}>
            <img className={classes.bg} src="/images/insert.png" alt="agenda" />
            <Link to="/c/list-rdv" className={classes.overlay}>
              RDVS
            </Link>
          </div>

          <div className={classes.box}>
            <div style={{ position: "absolute", top: "0", left: "20px" }}>
              {/* {CheckArray(chats)} */}
              {CheckkArray(chats)}
            </div>
            <img className={classes.bg} src="/images/edit.png" alt="agenda" />

            <Link to="/c/messenger" className={classes.overlay}>
              Messenger
            </Link>
          </div>

          <div className={classes.box}>
            <img className={classes.bg} src="/images/name.png" alt="agenda" />
            <Link to="/c/patients" className={classes.overlay}>
              Patients
            </Link>
          </div>
        </div>
      </div>
    </Fragment>
  );
}

Dashboard.propTypes = {
  selectDashboard: PropTypes.func.isRequired,
};

export default Dashboard;
