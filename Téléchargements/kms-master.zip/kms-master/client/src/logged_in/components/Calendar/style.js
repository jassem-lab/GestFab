import { makeStyles } from "@material-ui/core";

export default makeStyles((theme) => ({

    addBtn: {
        opacity: '0',
        transition: 'all 0.5s ease-in-out',
        color: '#fff',
    
        '&:hover': {
          transform: 'scale(1.2)',
          color: '#333'
        },
      },
      celluleContainer: {
        '&:hover $addBtn': {
          opacity: 1,
        },
      },
      cellule: {
        transition: 'all 0.5s ease-in-out',
        border: '1px solid #aaa',
        cursor: 'pointer',
      },
      celluleIcon: {
        fontSize: '14px',
        position: 'absolute',
        bottom: '5px',
        right: '5px',
        opacity: '0',
        color: '#fff',
        transition: 'all 0.5s ease-in-out',
        '&:hover': {
          transform: 'scale(1.2)',
          color: '#333',
        },
      },
      celluleItem: {
        opacity: '0.5', 
        transition: 'all 0.5s ease-in-out',
        border: '1px solid #eee',
        borderRadius: '5px',
        cursor: 'pointer',
        '&:hover': {
          opacity: '0.8',
          border: '1px solid #e0e0e0',
        },
        '&:hover $celluleIcon': {
          opacity: '1',
        }
      },
      filterContainer: {
        padding: "10px",
        backgroundColor: "#fafafa",
        height: "659px",
        display: 'flex',
        flexDirection: 'column',
        gap: '1rem',
        overflowY: "auto",
        overflowX: "hidden",
      },
      filterTitle: {
        fontSize: "20px",
        fontWeight: "bold",
        textAlign: 'center',
        marginBottom: "20px",
      },
      filterBlock: {
        marginBottom: "10px",
      },
      filterButton: {
        display: 'block',
        width: "100%",
        boxShadow: "1px 3px 5px rgba(0,0,0,0.25)",
        backgroundColor: "#CCC",
        borderRadius: "5px",
        padding: "10px",
        marginBottom: "10px",
        cursor: "pointer",
      },
      headerCell: {
        backgroundColor: '#fff',
        '&:hover': {
          backgroundColor: '#fff',
        },
        '&:focus': {
          backgroundColor: '#fff',
        },
      },
      flexibleContainer: {
        background: 'none',
        backgroundColor: 'transparent'
      },
      flexibleSpace: {
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        padding: '5px 20px',
      },
      doctorBtn: {
        margin: '0 10px',
        padding: '8px 20px',
        background: '#fff',
        textAlign: 'center',
        borderRadius: '5px',
        cursor: 'pointer',
        whiteSpace: 'nowrap',
        fontSize: '1rem',
        opacity: '0.8',
        outline: 'none',
      },
      paper: {
        flexGrow: 1,
        padding: 30,
        transition: 'all 0.6s ease-in-out',
      },
      actionBlock: {
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
      },
      actionLabel: {
        width: '30%',
        fontSize: '1.1rem',
      },
      select: {
        width: '70%',
        padding: '5px 10px',
        borderRadius: '5px',
      },
      post: {
        display: "flex",
        alignItems: 'center',
      },
      resaType: {
        margin: '0.5rem 0',
        borderRadius: '2rem'
      },
      deleteForm: {
        display: 'flex',
        alignItems: 'center',
        margin: '0 1rem',
      },
      myTextArea: {
        display: 'block',
        width: '75%',
        border: "1px solid #eee",
        margin: '1rem',
        padding: '1rem',
      }
}));