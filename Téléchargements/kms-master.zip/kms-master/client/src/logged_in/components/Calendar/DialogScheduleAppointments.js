import {
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
} from "@material-ui/core";
import React, { useState } from "react";
import ErrorIcon from "@material-ui/icons/Error";
import CheckCircleIcon from "@material-ui/icons/CheckCircle";
import moment from "moment";
import { createAppointment } from "../../../api";
import { useSelector } from "react-redux";

function DialogScheduleAppointments(props) {
  const { open, close, resas, patientId, patientName } = props;
  const { agendas } = useSelector((state) => state.agendas);
  const { doctorsMap } = useSelector((state) => state.doctors);
  const connectedUser = JSON.parse(localStorage.getItem("profile"))?.user;
  const [loadingStates, setLoadingStates] = useState({});

  const handleAction = async () => {
    for (const resa of resas) {
      setLoadingStates((loadingStates) => ({
        ...loadingStates,
        [resa._id]: "loading",
      }));
      try {
        const agenda = agendas.find((a) =>
          doctorsMap[resa.doctor]?.agendas?.includes(a._id)
        );
        await createAppointment({
          createdBy: connectedUser._id,
          doctor: resa.doctor,
          patient: patientId,
          start: resa.start,
          type: resa.type,
          duration: agenda?.template?.durationPart ?? 0,
          motif: "",
          notes: "",
          status: "Attente",
          celluleId: resa._id,
          agenda: resa.agenda,
        });
      } catch {
        setLoadingStates((loadingStates) => ({
          ...loadingStates,
          [resa._id]: "error",
        }));
      }
      setLoadingStates((loadingStates) => ({
        ...loadingStates,
        [resa._id]: "done",
      }));
    }
    close();
  };

  return (
    <Dialog
      open={open}
      onClose={close}
      aria-labelledby="action-title"
      aria-describedby="action-description"
    >
      <DialogTitle id="action-title">{`Ajouter plusieurs rendez-vous au patient '${patientName}'`}</DialogTitle>
      <DialogContent>
        <div
          style={{
            display: "flex",
            flexDirection: "column",
            gap: "1rem",
          }}
        >
          {resas?.map((resa) => (
            <div
              key={resa._id}
              style={{
                display: "flex",
                alignItems: "center",
                gap: "0.5rem",
              }}
            >
              <div
                style={{
                  backgroundColor: resa.color,
                  padding: ".5rem 1rem",
                  borderRadius: "1rem",
                  fontSize: 16,
                }}
              >
                {resa.type} le{" "}
                {moment(resa.start).format("DD/MM/YYYY [à] HH:mm")}
              </div>
              {loadingStates[resa._id] === "loading" ? (
                <img height={25} src="/images/loading-36.gif" alt="loading" />
              ) : loadingStates[resa._id] === "error" ? (
                <ErrorIcon color="error" />
              ) : (
                loadingStates[resa._id] === "done" && (
                  <CheckCircleIcon style={{ color: "green" }} />
                )
              )}
            </div>
          ))}
        </div>
      </DialogContent>
      <DialogActions>
        <Button
          onClick={close}
          color="primary"
          disabled={Object.entries(loadingStates).length > 0}
        >
          Retour
        </Button>
        <Button
          onClick={handleAction}
          style={{ cursor: "pointer" }}
          color="primary"
          autoFocus
          disabled={Object.entries(loadingStates).length > 0}
        >
          Confirmer
        </Button>
      </DialogActions>
    </Dialog>
  );
}

export default DialogScheduleAppointments;
