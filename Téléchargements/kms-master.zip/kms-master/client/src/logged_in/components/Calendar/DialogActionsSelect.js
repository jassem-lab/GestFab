import { Button, Dialog, DialogActions, DialogContent, DialogTitle } from '@material-ui/core'
import React, { useState } from 'react'
import useStyle from './style'

function DialogActionsSelect(props) {
    const { open, close } = props
    const [actionToDo, setActionToDo] = useState('')
    const classes = useStyle();

    const handleAction = () => {
        if (actionToDo === 'Annuler') {
          // dispatch(changeStatus(selectedAppointment?._id, {status: 'Annuler'}));
          alert('Comming Soon :p');
        } else if (actionToDo === 'Confirmer') {
          // dispatch(changeStatus(selectedAppointment?._id, {status: 'Confirmer'}));
          alert('Comming Soon :p');
        } else {
          alert('Nothing to do');
        }
        setActionToDo('');
        close();
    }

    return (
        <Dialog
                open={open}
                onClose={close}
                aria-labelledby="action-title"
                aria-describedby="action-description"
            >
                <DialogTitle id="action-title">{"Selectionnez l'action à faire au rendez-vous sélectionnés ?"}</DialogTitle>
                <DialogContent>
                        <div className={classes.actionBlock}>
                          <label className={classes.actionLabel}>Action :</label>
                          <select className={classes.select}
                                  value={actionToDo}
                                  onChange={e => setActionToDo(e.target.value)}
                                 >
                            <option value=''>Choisir une action</option>
                            <option value='Annuler'>Annuler les rendez-vous sélectionnés ?</option>
                            <option value='Confirmer'>Confirmer les rendez-vous sélectionnés ?</option>
                          </select>
                        </div>
                </DialogContent>
                <DialogActions>
                <Button onClick={close} color="primary">
                    Retour
                </Button>
                <Button onClick={handleAction} style={{ cursor: 'pointer' }} color="primary" autoFocus>
                    Action
                </Button>
                </DialogActions>
        </Dialog>
    )
}

export default DialogActionsSelect
