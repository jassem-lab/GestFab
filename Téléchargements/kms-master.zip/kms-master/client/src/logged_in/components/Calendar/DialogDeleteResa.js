import {
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
} from "@material-ui/core";
import React from "react";
import { useDispatch } from "react-redux";
import { deleteResa } from "../../../actions/resas";

function DialogDeleteResa(props) {
  const { open, close, selectedResa } = props;
  const dispatch = useDispatch();
  const RefreshPage = () => {
    window.location.reload(false);
  };
  return (
    <Dialog
      open={open}
      aria-labelledby="action-title"
      aria-describedby="action-description"
    >
      <DialogTitle id="action-deleteResa">
        {"Confirmer la supression de la cellule ?"}
      </DialogTitle>
      <DialogContent></DialogContent>
      <DialogActions>
        <Button onClick={close} color="primary">
          Retour
        </Button>
        <Button
          onClick={(e) => {
            e.stopPropagation();
            dispatch(deleteResa(selectedResa._id));
            // RefreshPage();
            close();
          }}
          style={{ cursor: "pointer" }}
          color="primary"
          autoFocus
        >
          Supprimer
        </Button>
      </DialogActions>
    </Dialog>
  );
}

export default DialogDeleteResa;
