import {
  Checkbox,
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  DialogContentText,
  DialogTitle,
} from "@material-ui/core";
import React, { useState } from "react";
import { useDispatch } from "react-redux";
import { changeStatus } from "../../../actions/appointments";
import useStyles from "./style";

function DialogDeleteAppointment(props) {
  const { open, close, selectedAppointment, connectedUser } = props;
  const classes = useStyles();
  const dispatch = useDispatch();
  const [formData, setFormData] = useState({
    connectedUser: connectedUser?._id,
    motif: "",
    sendSms: false,
    sendMsg: true,
  });

  const handleDeleteAppointment = (e) => {
    e.preventDefault();
    dispatch(
      changeStatus(
        selectedAppointment?._id,
        selectedAppointment?.celluleId,
        "Annuler",
        formData
      )
    );
    close();
  };

  return (
    <Dialog
      open={open}
      onClose={close}
      aria-labelledby="appointment-title"
      aria-describedby="appointment-description"
    >
      <DialogTitle id="appointment-title">
        {"Annuler le Rendez-vous ?"}
      </DialogTitle>
      <DialogContent>
        <DialogContentText id="appointment-description">
          <div className={classes.deleteForm}>
            <div className={classes.deleteFormGroup}>
              <label htmlFor="sendmsg">Envoyer un message</label>
              <Checkbox
                checked={formData.sendMsg}
                onChange={() =>
                  setFormData({
                    ...formData,
                    sendMsg: !formData.sendMsg,
                  })
                }
                name="sendmsg"
                id="sendmsg"
              />
            </div>
            <div className={classes.deleteFormGroup}>
              <label htmlFor="sendmsg">Envoyer un sms</label>
              <Checkbox
                checked={formData.sendSms}
                onChange={() =>
                  setFormData({
                    ...formData,
                    sendSms: !formData.sendSms,
                  })
                }
                name="sendsms"
                id="sendsms"
              />
            </div>
          </div>
          <div>
            <textarea
              name="motif"
              id="motif"
              rows="4"
              placeholder="Motif de l'annulation"
              className={classes.myTextArea}
              value={formData.motif}
              onChange={(e) => {
                setFormData({
                  ...formData,
                  motif: e.target.value,
                });
              }}
            />
          </div>
        </DialogContentText>
      </DialogContent>
      <DialogActions>
        <Button onClick={close} color="primary">
          Annuler
        </Button>
        <Button onClick={handleDeleteAppointment} color="primary">
          Confirmer
        </Button>
      </DialogActions>
    </Dialog>
  );
}

export default DialogDeleteAppointment;
