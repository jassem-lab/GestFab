import React, { useEffect, useState } from "react";
import { ViewState } from "@devexpress/dx-react-scheduler";
import { Resource } from "devextreme-react/scheduler";
import {
  WeekView,
  Scheduler,
  DayView,
  Appointments,
  Toolbar,
  DateNavigator,
  ViewSwitcher,
  TodayButton,
  DragDropProvider,
} from "@devexpress/dx-react-scheduler-material-ui";
import BookmarkIcon from "@mui/icons-material/Bookmark";
import moment from "moment";
import { Tooltip } from "@material-ui/core";
import FaceIcon from "@material-ui/icons/Face";
import QueryBuilderIcon from "@material-ui/icons/QueryBuilder";
import DeleteForeverIcon from "@material-ui/icons/DeleteForever";
import EditOutlinedIcon from "@material-ui/icons/EditOutlined";
import HighlightOffOutlinedIcon from "@material-ui/icons/HighlightOffOutlined";
import AddCircleOutlineIcon from "@material-ui/icons/AddCircleOutline";
import useStyles from "./style";
import { useSelector } from "react-redux";
import PublicIcon from "@material-ui/icons/Public";
import PersonIcon from "@material-ui/icons/Person";
import CheckCircleIcon from "@mui/icons-material/CheckCircle";
import AutorenewIcon from "@mui/icons-material/Autorenew";
// import PendingIcon from "@mui/icons-material/Pending";
import AlarmOffIcon from "@mui/icons-material/AlarmOff";

const DEFAULT_HEIGHT = 240;

var myState = {};

const mapAppointmentData = (appointment) => ({
  id: appointment._id,
  startDate: moment(appointment.start).format("YYYY-MM-DDTHH:mm"),
  endDate: moment(appointment.start)
    .add(appointment.duration, "minutes")
    .format("YYYY-MM-DDTHH:mm"),
  type: appointment.type,
  patient: appointment.patient,
  motif: appointment.motif,
  doctor: appointment.doctor,
  status: appointment.status,
  createdBy: appointment.createdBy.role,
  createdAt: appointment.createdAt,
});

// Time scale label

const WeekViewTimeScaleLabel = ({ style, ...restProps }) => (
  <WeekView.TimeScaleLabel
    {...restProps}
    style={{ ...style, height: `${DEFAULT_HEIGHT}px`, lineHeight: "1rem" }}
  />
);

const DayViewTimeScaleLabel = ({ style, ...restProps }) => (
  <DayView.TimeScaleLabel
    {...restProps}
    style={{ ...style, height: `${DEFAULT_HEIGHT}px`, lineHeight: "1rem" }}
  />
);

// WEEK  VIEW
const WeekTimeTableCell = ({ ...restProps }) => {
  const { startDate } = restProps;
  const celluleHeight = DEFAULT_HEIGHT;
  // const cellData = myState.resas?.filter(
  //   (resa) => resa.start === moment(startDate).format("YYYY-MM-DDTHH:mm")
  // );
  const cellData = useSelector((state) => state.resas.resas).filter(
    (resa) =>
      resa.start === moment(startDate).format("YYYY-MM-DDTHH:mm") &&
      !resa.type.match("VAD")
  );

  const elementWidth = 100;

  // console.log(cellData);

  if (cellData && cellData.length > 0) {
    const elementHeight = 100 / cellData.length;

    return (
      <WeekView.TimeTableCell
        {...restProps}
        className={myState.classes.cellule}
        style={{
          height: `${celluleHeight}px`,
          border: "10px solid #e0e0e0",
        }}
      >
        <span
          className={myState.classes.celluleContainer}
          id="celCon"
          style={{
            display: "flex",
            flexDirection: "column",
            height: "100%",
            width: "100%",
            position: "relative",
          }}
        >
          {cellData
            ?.sort((a, b) => (a.type > b.type ? 1 : b.type > a.type ? -1 : 0))
            ?.map((item, itemIndex) => (
              <span
                key={`${itemIndex}-${item.type}-${startDate}`}
                className={myState.classes.celluleItem}
                style={{
                  position: "relative",
                  backgroundColor: `${item.color}`,
                  height: `${elementHeight}%`,
                  width: `${elementWidth}%`,
                }}
                onClick={() => {
                 
                  item.status === "taked"
                    ? alert("Cette réservation est déjà prise")
                    : myState.handleSetFormData({
                        type: item.type,
                        start: new Date(startDate),
                        duration: 30,
                        doctor: item.doctor,
                        celluleId: item._id,
                      });
                }}
              >
                <EditOutlinedIcon
                  className={myState.classes.celluleIcon}
                  style={{ right: "20px" }}
                  onClick={(e) => {
                    e.stopPropagation();
                    myState.handleSelectResaData(item);
                  }}
                />
                <HighlightOffOutlinedIcon
                  className={myState.classes.celluleIcon}
                  onClick={(e) => {
                    e.stopPropagation();
                    myState.handleConfirmDeleteResa(item);
                  }}
                />
              </span>
            ))}
          <AddCircleOutlineIcon
            className={myState.classes.addBtn}
            style={{
              position: "absolute",
              bottom: "-8px",
              left: "-8px",
              fontSize: "1.1rem",
              zIndex: "4",
            }}
            onClick={(e) => {
              e.stopPropagation();
              myState.handleAddResa({
                date: moment(startDate).format("YYYY-MM-DDTHH:mm"),
              });
            }}
          />
        </span>
      </WeekView.TimeTableCell>
    );
  } else {
    return (
      <WeekView.TimeTableCell
        {...restProps}
        className={myState.classes.cellule}
        style={{
          height: `${celluleHeight}px`,
          border: "10px solid #e0e0e0",
          backgroundColor: "#eee",
        }}
      >
        <span
          className={myState.classes.celluleContainer}
          style={{
            display: "flex",
            flexDirection: "column",
            height: "100%",
            width: "100%",
            position: "relative",
          }}
        >
          <AddCircleOutlineIcon
            className={myState.classes.addBtn}
            style={{
              position: "absolute",
              bottom: "-8px",
              left: "-8px",
              fontSize: "1.1rem",
              zIndex: "4",
            }}
            onClick={(e) => {
              e.preventDefault();
              myState.handleAddResa({
                date: moment(startDate).format("YYYY-MM-DDTHH:mm"),
              });
            }}
          />
        </span>
      </WeekView.TimeTableCell>
    );
  }
};

// PRESERVATION OF VIEW - DAY VIEW

const DayTimeTableCell = ({ ...restProps }) => {
  const { startDate } = restProps;
  const celluleHeight = DEFAULT_HEIGHT;

  const cellData = myState.resas?.filter(
    (resa) => resa.start === moment(startDate).format("YYYY-MM-DDTHH:mm")
  );
  const elementWidth = 100;

  if (cellData && cellData.length > 0) {
    const elementHeight = 100 / cellData.length;

    return (
      <DayView.TimeTableCell
        {...restProps}
        className={myState.classes.cellule}
        style={{
          height: `${celluleHeight}px`,
        }}
      >
        <span
          className={myState.classes.celluleContainer}
          style={{
            display: "flex",
            flexDirection: "column",
            height: "100%",
            width: "100%",
            position: "relative",
          }}
        >
          {cellData
            ?.sort((a, b) => (a.type > b.type ? 1 : b.type > a.type ? -1 : 0))
            ?.map((item, itemIndex) => (
              <span
                key={`${itemIndex}-${item.type}-${startDate}`}
                className={myState.classes.celluleItem}
                style={{
                  position: "relative",
                  backgroundColor: `${item.color}`,
                  height: `${elementHeight}%`,
                  width: `${elementWidth}%`,
                }}
                onClick={() =>
                  myState.handleSetFormData({
                    type: item.type,
                    start: new Date(startDate),
                    duration: 30,
                    doctor: item.doctor,
                    celluleId: item._id,
                  })
                }
              >
                <EditOutlinedIcon
                  className={myState.classes.celluleIcon}
                  onClick={(e) => {
                    e.stopPropagation();
                    myState.handleSelectResaData(item);
                  }}
                />
                <HighlightOffOutlinedIcon
                  className={myState.classes.celluleIcon}
                  style={{ right: "20px" }}
                  onClick={(e) => {
                    e.stopPropagation();
                    myState.handleConfirmDeleteResa(item);
                  }}
                />
              </span>
            ))}
          <AddCircleOutlineIcon
            className={myState.classes.addBtn}
            style={{
              position: "absolute",
              bottom: "2px",
              left: "2px",
              fontSize: "1.1rem",
            }}
            onClick={(e) => {
              e.stopPropagation();
              myState.handleAddResa({
                date: moment(startDate).format("YYYY-MM-DDTHH:mm"),
              });
            }}
          />
        </span>
      </DayView.TimeTableCell>
    );
  } else {
    return (
      <DayView.TimeTableCell
        {...restProps}
        className={myState.classes.cellule}
        style={{
          height: `${celluleHeight}px`,
          backgroundColor: "#eee",
        }}
      >
        <span
          className={myState.classes.celluleContainer}
          style={{
            display: "flex",
            flexDirection: "column",
            height: "100%",
            width: "100%",
            position: "relative",
          }}
        >
          <AddCircleOutlineIcon
            className={myState.classes.addBtn}
            style={{
              position: "absolute",
              bottom: "2px",
              left: "2px",
              fontSize: "1.1rem",
            }}
            onClick={(e) => {
              e.stopPropagation();
              myState.handleAddResa({
                date: moment(startDate).format("YYYY-MM-DDTHH:mm"),
              });
            }}
          />
        </span>
      </DayView.TimeTableCell>
    );
  }
};

// APPOINTMENT CONTAINER

const AppointmentContainer = ({ style, ...restProps }) => {
  let widthCoef = 7;
  if (myState.etablissement.excludedDays.includes(6)) {
    widthCoef = widthCoef - 1;
  }
  if (myState.etablissement.excludedDays.includes(0)) {
    widthCoef = widthCoef - 1;
  }

  const celluleHeight = DEFAULT_HEIGHT - 12;

  // get day and multiple it with width/widthCoef
  const startDate = new Date(
    restProps?.children[0]?.props?.params?.data?.startDate
  );
  const day = startDate?.getDay();

  return (
    <Appointments.Container
      {...restProps}
      style={{
        ...style,
        left: `${(100 / widthCoef) * (day - 1)}%`,
        width: `${100 / widthCoef}%`,
        height: `${celluleHeight}px`,
        pointerEvents: "none",
        marginTop: "5px",
      }}
    />
  );
};

// APPOINTMENT STYLE

const Appointment = ({ style, children, data, ...restProps }) => {
  // const doctor = doctors?.find(doctor => doctor._id === data.doctorId)
  const color = myState.typesByEtab?.find(
    (item) =>
      item.type?.trim()?.toUpperCase() === data?.type?.trim()?.toUpperCase()
  )?.color;
  const start = new Date(data.startDate);
  const appointmentDuration =
    moment(data.endDate).diff(moment(data.startDate)) / 60 / 1000;
  const doctorInitialDuration = 30;

  // Available Free Spaces in the case

  const cellData = useSelector((state) => state.resas.resas).filter(
    (resa) =>
      resa.start === moment(start).format("YYYY-MM-DDTHH:mm") &&
      !resa.type.match("VAD")
  );
  let freeSpacesCase = [];
  if (cellData && cellData.length > 0) {
    // eslint-disable-next-line array-callback-return
    cellData.map((cell) => {
      freeSpacesCase.push({
        color: cell.color,
        type: cell.type,
        doctor: myState.doctors?.find((doctor) => doctor._id === cell.doctor),
        start: cell.start,
        takedBy: cell.takedBy,
      });
    });
  }

  //  CASE FREE SPACE & FILL WITH FREE SPACES
  freeSpacesCase = freeSpacesCase.sort((a, b) =>
    a.type > b.type ? 1 : b.type > a.type ? -1 : 0
  );

  // Calcule de la position de la cellule

  // console.log(freeSpaces);
  let posRes = 0;
  for (let i = 0; i < freeSpacesCase.length; i++) {
    if (freeSpacesCase[i].takedBy === data.id) {
      posRes = i;
    }
  }

  // Calcul de duration

  let celluleWidth = 100;
  if (appointmentDuration < doctorInitialDuration) {
    celluleWidth = celluleWidth - (doctorInitialDuration - appointmentDuration);
  }

  // Calcul de position

  const left = 5;
  const translateValue = posRes * 100;
  const width = celluleWidth - 6;
  const celluleHeight = 100 / freeSpacesCase.length;

  return (
    <Appointments.Appointment
      {...restProps}
      style={{
        ...style,
        pointerEvents: "all",
        backgroundColor: `${color}`,
        borderRadius: "4px",
        boxShadow: "0px 0px 2px #00000029",
        height: `calc(${celluleHeight}%)`,
        width: `calc(${width}%)`,
        transform: `translateY(${translateValue}%)`,
        left: `${left}px`,
      }}
      onClick={(e) => {
        myState.handleSelectAppointment(data.id);
      }}
    >
      {children}
    </Appointments.Appointment>
  );
};

// APPOINTMENT CONTENT -

const AppointmentContent = ({ style, data, ...restProps }) => {
  const { patientsMap } = useSelector((state) => state.patients);
  const { doctorsMap } = useSelector((state) => state.doctors);
  var today = new Date();
  var currentDate =
    today.getFullYear() + "-" + (today.getMonth() + 1) + "-" + today.getDate();
  return (
    <Appointments.AppointmentContent
      {...restProps}
      data={data}
      style={{ ...style, height: "100%" }}
    >
      <div
        style={{
          position: "relative",
          width: "100%",
          height: "100%",
          paddingTop: "15px",
        }}
      >
        <div style={{ fontSize: "12px", color: "#000", fontWeight: "500" }}>
          {patientsMap[data.patient]?.user?.name}
        </div>
        <span
          style={{
            position: "absolute",
            top: "0",
            left: "0",
            display: "flex",
            alignItems: "center",
          }}
        >
          <Tooltip
            title={`Durée : ${moment(data.endDate).diff(
              moment(data.startDate),
              "minutes"
            )} min 
            | Date de Prise de RDV: ${moment(data.createdAt)
              .format("YYYY-MM-DDTHH:mm")
              .replace("T", " ")} `}
            placement="bottom"
          >
            <QueryBuilderIcon
              style={{
                marginRight: "5px",
                fontSize: "11px",
                marginTop: "-2px",
                color: "#000",
              }}
            />
          </Tooltip>

          <span style={{ fontSize: "10px", color: "#000" }}>
            {moment(data.startDate).format("HH:mm").replace("T", " ")}
          </span>
        </span>
        <span
          style={{
            position: "absolute",
            top: "0",
            right: "0",
            display: "flex",
            justifyContent: "space-around",
          }}
        >
          <Tooltip
            title={doctorsMap[data.doctor]?.user?.name}
            placement="bottom"
          >
            <FaceIcon style={{ fontSize: "14px", color: "#000" }} />
          </Tooltip>
          {data.motif ? (
            <Tooltip title={data.motif} placement="bottom">
              <BookmarkIcon style={{ fontSize: "14px", color: "#000" }} />
            </Tooltip>
          ) : null}
        </span>
        {/* Appointment Status Icon */}
        <span style={{ position: "absolute", bottom: "-5px", right: "25px" }}>
          {data.status === "Confirmer" ||
          moment(currentDate).isAfter(data.startDate) ? (
            <Tooltip title={`Confirmer`} placement="bottom">
              <CheckCircleIcon
                style={{
                  fontSize: "13px",
                  color: "green",
                }}
              />
            </Tooltip>
          ) : (
            <Tooltip
              title={`En attente`}
              placement="bottom"
              // style={{ position: "absolute", bottom: "-5px", right: "25 px" }}
            >
              <AutorenewIcon
                style={{
                  fontSize: "13px",
                  color: "black",
                }}
              />
            </Tooltip>
          )}{" "}
        </span>
        <span style={{ position: "absolute", bottom: "-5px", right: "12px" }}>
          {data.createdBy === "patient" ? (
            <Tooltip
              title={`Internet @${patientsMap[data.patient]?.user?.name}`}
              placement="bottom"
            >
              <PublicIcon style={{ fontSize: "14px", color: "#000" }} />
            </Tooltip>
          ) : data.createdBy === "client" ? (
            <Tooltip
              title={`Docteur @${doctorsMap[data.doctor]?.user?.name}`}
              placement="bottom"
            >
              <FaceIcon style={{ fontSize: "14px", color: "#000" }} />
            </Tooltip>
          ) : data.createdBy === "admin" ? (
            <Tooltip title={`Admin`} placement="bottom">
              <PersonIcon style={{ fontSize: "14px", color: "#000" }} />
            </Tooltip>
          ) : null}
        </span>
        <span style={{ position: "absolute", bottom: "-5px", right: "0" }}>
          <Tooltip title="Annuler le rendez-vous?" placement="bottom">
            <DeleteForeverIcon
              style={{ fontSize: "14px", color: "#000" }}
              onClick={(e) => {
                e.stopPropagation();
                myState.handleConfirmDeleteAppointment(data.id);
              }}
            />
          </Tooltip>
        </span>
      </div>
    </Appointments.AppointmentContent>
  );
};

// Calendar Component

export default function Calendar(props) {
  const { doctors, settings, etablissement, agendas, typesByEtab } = props;
  const classes = useStyles();
  const { appointments, AppointmentsIsLoading } = useSelector(
    (state) => state.appointments
  );
  var today = new Date();
  var date =
    today.getFullYear() + "-" + (today.getMonth() + 1) + "-" + today.getDate();

  const { resas, ResasIsLoading } = useSelector((state) => state.resas);
  const [currentDate, setCurrentDate] = useState(
    localStorage.getItem("currentDate")
      ? localStorage.getItem("currentDate")
      : date
  );
  const [currentViewName, setCurrentViewName] = useState("Week");
  const defaultDuration = 30;
  const [calendarData, setCalendarData] = useState([]);
  const removedValues = ["VAD", "VAD CH.VERT", "VAD NERE", "VAD 4 SAISONS"];

  useEffect(() => {
    if (appointments && appointments.length > 0) {
      const myAppointments = appointments?.filter(
        (appointment) =>
          appointment.status !== "Annuler" && !appointment.type.match("VAD")
      );
      setCalendarData(
        myAppointments?.map((appointment) => mapAppointmentData(appointment))
      );
    }
  }, [appointments]);

  useEffect(() => {
    if (resas && resas.length > 0) {
      myState.resas = resas;
    }
  }, [resas]);

  useEffect(() => {
    if (typesByEtab && typesByEtab.length > 0) {
      myState.typesByEtab = typesByEtab;
    }
  }, [typesByEtab]);

  if (!settings || !etablissement || !agendas || !doctors) return null;
  if (!AppointmentsIsLoading && !appointments) return null;
  if (!ResasIsLoading && !resas) return null;

  myState.classes = classes;
  myState.etablissement = etablissement;
  myState.handleSetFormData = (data) => props.handleSetFormData(data);
  myState.handleSelectResaData = (data) => props.handleSelectResaData(data);
  myState.handleConfirmDeleteResa = (data) =>
    props.handleConfirmDeleteResa(data);
  myState.handleAddResa = (data) => props.handleAddResa(data);
  myState.handleSelectAppointment = (data) =>
    props.handleSelectAppointment(data);
  myState.handleConfirmDeleteAppointment = (data) =>
    props.handleConfirmDeleteAppointment(data);
  const views = [
    { type: "week", name: "Week Mode", maxAppointmentsPerCell: "5" },
  ];
  return (
    <>
      {ResasIsLoading || AppointmentsIsLoading ? (
        <div
          style={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            height: "600px",
          }}
        >
          <img
            width={60}
            height={60}
            src="/images/loading-36.gif"
            alt="loading"
          />
        </div>
      ) : (
        <Scheduler
          data={calendarData}
          locale="fr-FR"
          height={660}
          views={views}
        >
          <ViewState
            currentDate={currentDate}
            currentViewName={currentViewName}
            onCurrentViewNameChange={(newItem) => setCurrentViewName(newItem)}
            onCurrentDateChange={(newItem) => {
              props.handleChangeCurrentDate(newItem);
              setCurrentDate(newItem);
              localStorage.setItem("currentDate", newItem);
            }}
          />
          <WeekView
            cellDuration={defaultDuration}
            startDayHour={etablissement?.startDayHour}
            endDayHour={etablissement?.endDayHour}
            excludedDays={etablissement?.excludedDays}
            timeScaleLabelComponent={WeekViewTimeScaleLabel}
            timeTableCellComponent={WeekTimeTableCell}
          />
          <DayView
            cellDuration={defaultDuration}
            startDayHour={etablissement?.startDayHour}
            endDayHour={etablissement?.endDayHour}
            excludedDays={etablissement?.excludedDays}
            timeScaleLabelComponent={DayViewTimeScaleLabel}
            timeTableCellComponent={DayTimeTableCell}
          />
          <Appointments
            appointmentComponent={Appointment}
            containerComponent={AppointmentContainer}
            appointmentContentComponent={AppointmentContent}
          />
          <Toolbar />
          <DateNavigator />
          <TodayButton />
          <ViewSwitcher />
        </Scheduler>
      )}
    </>
  );
}
