import { WeekView } from "@devexpress/dx-react-scheduler";
import { makeStyles } from "@material-ui/core";
import moment from "moment";
import React from "react";
import EditOutlinedIcon from "@material-ui/icons/EditOutlined";
import HighlightOffOutlinedIcon from "@material-ui/icons/HighlightOffOutlined";
import AddCircleOutlineIcon from "@material-ui/icons/AddCircleOutline";

const useStyles = makeStyles((theme) => ({
  addBtn: {
    opacity: "0",
    transition: "all 0.5s ease-in-out",
    color: "#fff",

    "&:hover": {
      transform: "scale(1.2)",
      color: "#333",
    },
  },
  celluleContainer: {
    "&:hover $addBtn": {
      opacity: 1,
    },
  },
  cellule: {
    transition: "all 0.5s ease-in-out",
    border: "1px solid #aaa",
    cursor: "pointer",
  },
  celluleIcon: {
    fontSize: "14px",
    position: "absolute",
    bottom: "5px",
    right: "5px",
    opacity: "0",
    color: "#fff",
    transition: "all 0.5s ease-in-out",
    "&:hover": {
      transform: "scale(1.2)",
      color: "#333",
    },
  },
  celluleItem: {
    opacity: "0.5",
    transition: "all 0.5s ease-in-out",
    border: "1px solid #eee",
    borderRadius: "5px",
    cursor: "pointer",
    "&:hover": {
      opacity: "0.8",
      border: "1px solid #e0e0e0",
    },
    "&:hover $celluleIcon": {
      opacity: "1",
    },
  },
}));

function WeekTimeTableCellComponent({
  defaultDuration,
  freeSpaces,
  settings,
  doctors,
  handleSetFormData,
  handleShowFormView,
  handleSetSelectedResa,
  handleShowResaForm,
  handleShowResaDelete,
  handleSetSelectedTime,
  restProps,
}) {
  const classes = useStyles();
  const { startDate } = restProps;
  const celluleHeight =
    parseInt(defaultDuration) *
    parseInt(
      settings?.find((setting) => setting.attribute === "celluleHeight")?.value
    );

  const cellData = freeSpaces;
  let result = [];
  if (cellData && cellData.length > 0) {
    cellData.forEach((cell) => {
      result.push({
        color: cell.color,
        type: cell.type,
        doctor: doctors.find((doctor) => doctor?._id === cell.doctor),
        start: cell.start,
        id: cell._id,
        agenda: cell.agenda,
      });
    });
  }

  const elementHeight = 100 / result.length;
  const elementWidth = 100;

  if (result && result.length > 0) {
    return (
      <WeekView.TimeTableCell
        {...restProps}
        className={classes.cellule}
        style={{
          height: `${celluleHeight}px`,
        }}
      >
        <span
          className={classes.celluleContainer}
          style={{
            display: "flex",
            flexDirection: "column",
            height: "100%",
            width: "100%",
            position: "relative",
          }}
        >
          {result?.map((item, itemIndex) => (
            <span
              key={`${itemIndex}-${item.type}-${startDate}`}
              className={classes.celluleItem}
              style={{
                position: "relative",
                backgroundColor: `${item.color}`,
                height: `${elementHeight}%`,
                width: `${elementWidth}%`,
                // width: `${elementWidth}%`,
              }}
              onClick={() => {
                handleSetFormData({
                  isNewRdv: true,
                  type: item.type,
                  start: new Date(startDate),
                  duration: defaultDuration,
                  doctor: item.doctor,
                  celluleId: item.id,
                });
                handleShowFormView(true);
              }}
            >
              <EditOutlinedIcon
                className={classes.celluleIcon}
                style={{ right: "20px" }}
                onClick={(e) => {
                  e.stopPropagation();
                  handleSetSelectedResa(
                    freeSpaces.find((resa) => resa._id === item.id)
                  );
                  handleShowResaForm(true);
                }}
              />
              <HighlightOffOutlinedIcon
                className={classes.celluleIcon}
                onClick={(e) => {
                  e.stopPropagation();
                  handleSetSelectedResa(
                    freeSpaces.find((resa) => resa._id === item.id)
                  );
                  handleShowResaDelete(true);
                }}
              />
            </span>
          ))}
          <AddCircleOutlineIcon
            className={classes.addBtn}
            style={{
              position: "absolute",
              bottom: "2px",
              left: "2px",
              fontSize: "1.1rem",
              zIndex: "4",
            }}
            onClick={(e) => {
              e.stopPropagation();
              handleSetSelectedResa(null);
              handleSetSelectedTime(
                moment(startDate).format("YYYY-MM-DDTHH:mm")
              );
              handleShowResaForm(true);
            }}
          />
        </span>
      </WeekView.TimeTableCell>
    );
  } else {
    return (
      <WeekView.TimeTableCell
        {...restProps}
        style={{
          backgroundColor: "#eee",
          height: `${celluleHeight}px`,
          width: `${elementWidth}%`,
        }}
        onClick={() => {
          handleSetFormData({
            isNewRdv: true,
            start: new Date(startDate),
            duration: defaultDuration,
          });
          handleShowFormView(true);
        }}
      />
    );
  }
}

export default WeekTimeTableCellComponent;
