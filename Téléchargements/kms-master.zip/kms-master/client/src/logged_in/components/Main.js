import React, { memo, useCallback, useState, useEffect, Fragment } from "react";
import PropTypes from "prop-types";
import classNames from "classnames";
import { withStyles } from "@material-ui/core";
import Routing from "./Routing";
import NavBar from "./navigation/NavBar";
import smoothScrollTop from "../../shared/functions/smoothScrollTop";
import { useHistory, useLocation } from "react-router";
import decode from "jwt-decode";
import { useDispatch, useSelector } from "react-redux";
import { LOGOUT } from "../../constants/actionTypes";
import { getDoctors } from "../../actions/doctors";
import { getSettings } from "../../actions/settings";
import { getEtablissements } from "../../actions/etablissements";
import { getPatients } from "../../actions/patients";
import { getMyAppointments } from "../../actions/appointments";
import { getAgendas } from "../../actions/agendas";

const styles = (theme) => ({
  main: {
    marginLeft: theme.spacing(9),
    transition: theme.transitions.create(["width", "margin"], {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.leavingScreen,
    }),
    [theme.breakpoints.down("xs")]: {
      marginLeft: 0,
    },
  },
});

function Main(props) {
  const { classes } = props;
  const [selectedTab, setSelectedTab] = useState("Dashboard");
  const history = useHistory();
  const location = useLocation();
  const dispatch = useDispatch();
  const { settings } = useSelector((state) => state.settings);
  const { etablissements } = useSelector((state) => state.etablissements);
  const { doctors } = useSelector((state) => state.doctors);
  const { agendas } = useSelector((state) => state.agendas);
  const { patients } = useSelector((state) => state.patients);

  const [user, setUser] = useState(JSON.parse(localStorage.getItem("profile")));
  const [selectedEtab, setSelectedEtab] = useState(null);
  const [doctorsByEtab, setDoctorsByEtab] = useState([]);
  const [agendasByEtab, setAgendasByEtab] = useState([]);

  const selectDashboard = useCallback(() => {
    smoothScrollTop();
    document.title = "KineDoc - Dashboard";
    setSelectedTab("Dashboard");
  }, [setSelectedTab]);

  const selectCalendar = useCallback(() => {
    smoothScrollTop();
    document.title = "KineDoc - Calendar";
    setSelectedTab("Calendar");
  }, [setSelectedTab]);

  const selectAppointment = useCallback(() => {
    smoothScrollTop();
    document.title = "KineDoc - List R.D.V";
    setSelectedTab("Appointment");
  }, [setSelectedTab]);

  const selectMessenger = useCallback(() => {
    smoothScrollTop();
    document.title = "KineDoc - Messenger";
    setSelectedTab("Messenger");
  }, [setSelectedTab]);

  const selectPatients = useCallback(() => {
    smoothScrollTop();
    document.title = "KineDoc - Patients";
    setSelectedTab("Patients");
  }, [setSelectedTab]);

  const selectDoctors = useCallback(() => {
    smoothScrollTop();
    document.title = "KineDoc - Doctors";
    setSelectedTab("Doctors");
  }, [setSelectedTab]);

  const selectEvents = useCallback(() => {
    smoothScrollTop();
    document.title = "KineDoc - Journal d'événements";
    setSelectedTab("Events");
  }, [setSelectedTab]);

  const selectProfile = useCallback(() => {
    smoothScrollTop();
    document.title = "KineDoc - Profile";
    setSelectedTab("Profile");
  }, [setSelectedTab]);
  const selectCalendarVAD = useCallback(() => {
    smoothScrollTop();
    document.title = "KineDoc - Calendar VAD";
    setSelectedTab("CalendarVAD");
  }, [setSelectedTab]);
  const logout = useCallback(() => {
    dispatch({ type: LOGOUT });
    history.push("/");
    setUser(null);
    window.location.reload();
  }, [dispatch, history]);

  useEffect(() => {
    const token = user?.token;
    if (token) {
      const decodedToken = decode(token);
      if (decodedToken?.exp * 1000 < new Date().getTime()) logout();
    }
    setUser(JSON.parse(localStorage.getItem("profile")));
  }, [location, logout, user?.token]);

  useEffect(() => {
    dispatch(getSettings());
    dispatch(getEtablissements());
    dispatch(getDoctors());
    dispatch(getAgendas());
    if (user?.user?.role === "admin" || user?.user?.role === "client") {
      dispatch(getPatients());
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [dispatch]);

  useEffect(() => {
    if (
      etablissements &&
      etablissements.length > 0 &&
      doctors &&
      doctors.length > 0
    ) {
      if (user?.user?.role === "patient") {
        setSelectedEtab(
          etablissements?.find(
            (etab) =>
              etab._id ===
              patients?.find((pat) => pat.user?._id === user?.user?._id)
                ?.assignedEtab?._id
          )
        );
      } else if (user?.user?.role === "client") {
        setSelectedEtab(
          etablissements?.find(
            (etab) =>
              etab._id ===
              doctors?.find((doc) => doc.user?._id === user?.user?._id)
                ?.etablissement?._id
          )
        );
      } else if (localStorage.getItem("etablissement")) {
        setSelectedEtab(
          etablissements?.find(
            (etab) => etab._id === localStorage.getItem("etablissement")
          )
        );
      } else if (user?.user?.role === "admin") {
        setSelectedEtab(etablissements[0]);
      }
    }
  }, [dispatch, doctors, etablissements, patients, user]);

  useEffect(() => {
    if (selectedEtab && selectedEtab._id && doctors && doctors.length > 0) {
      setDoctorsByEtab(
        doctors?.filter((doc) => doc.etablissement?._id === selectedEtab._id)
      );
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedEtab, doctors]);

  useEffect(() => {
    if (doctorsByEtab && doctorsByEtab.length > 0) {
      let myAgendas = [];
      doctorsByEtab.forEach((doc) => {
        if (doc.agendas && doc.agendas.length > 0) {
          doc.agendas.forEach((agenda) => {
            if (agendas?.find((ag) => ag._id === agenda)) {
              myAgendas.push(agendas?.find((ag) => ag._id === agenda));
            }
          });
        }
      });
      if (myAgendas.length > 0) {
        setAgendasByEtab(myAgendas);
      }
    }
  }, [agendas, dispatch, doctorsByEtab]);

  /* useEffect(() => {
    if (selectedEtab && selectedEtab._id) {
      dispatch(getPatientsByEtab(selectedEtab._id));
    }
  }, [dispatch, selectedEtab]); */

  useEffect(() => {
    if (doctorsByEtab && doctorsByEtab.length > 0) {
      if (user?.user?.role === "patient") {
        dispatch(getMyAppointments(user?.user?._id, { all: true }));
      }
    }
  }, [dispatch, doctorsByEtab, user]);

  const handleSelectEtablissement = (etabId) => {
    setSelectedEtab(etablissements?.find((etab) => etab._id === etabId));
  };

  return (
    <Fragment>
      <NavBar
        classes={classes}
        selectedTab={selectedTab}
        user={user?.user}
        logout={logout}
        selectEtablissement={(etabId) => handleSelectEtablissement(etabId)}
        etablissements={etablissements}
        doctors={doctors}
        settings={settings}
      />
      <main className={classNames(classes.main)}>
        <Routing
          selectCalendarVAD={selectCalendarVAD}
          selectDashboard={selectDashboard}
          selectCalendar={selectCalendar}
          selectAppointment={selectAppointment}
          selectMessenger={selectMessenger}
          selectPatients={selectPatients}
          selectDoctors={selectDoctors}
          selectEvents={selectEvents}
          selectProfile={selectProfile}
          user={user?.user}
          settings={settings}
          doctorsByEtab={doctorsByEtab}
          etablissement={selectedEtab}
          agendas={agendas}
          etablissements={etablissements}
          agendasByEtab={agendasByEtab}
        />
      </main>
    </Fragment>
  );
}

Main.propTypes = {
  classes: PropTypes.object.isRequired,
};

export default withStyles(styles, { withTheme: true })(memo(Main));
