import React from 'react';
import PropTypes from 'prop-types';
import Dialog from '@material-ui/core/Dialog';
import IconButton from '@material-ui/core/IconButton';
import AddIcon from '@material-ui/icons/Add';
import { makeStyles } from '@material-ui/core/styles';
import { Box, Paper, Tab, Tabs, Typography } from '@material-ui/core';
import AddDoctor from '../Doctors/AddDoctor';

export default function AddButton() {
    const [open, setOpen] = React.useState(false);

    const handleClickOpen = () => {
        setOpen(true);
    };

    const handleClose = () => {
        setOpen(false);
    };

    const useStyles = makeStyles((theme) => ({
        iconButton: {
            margin: 5,
        },
        root: {
            flexGrow: 1,
        },
    }));

    const classes = useStyles();
    const [value, setValue] = React.useState(0);

    const handleChange = (event, newValue) => {
        setValue(newValue);
    };

    function TabPanel(props) {
        const { children, value, index, ...other } = props;

        return (
            <div
                role="tabpanel"
                hidden={value !== index}
                id={`scrollable-auto-tabpanel-${index}`}
                aria-labelledby={`scrollable-auto-tab-${index}`}
                {...other}
            >
                {value === index && (
                    <Box p={3}>
                        <Typography>{children}</Typography>
                    </Box>
                )}
            </div>
        );
    }

    TabPanel.propTypes = {
        children: PropTypes.node,
        index: PropTypes.any.isRequired,
        value: PropTypes.any.isRequired,
    };

    function a11yProps(index) {
        return {
            id: `scrollable-auto-tab-${index}`,
            'aria-controls': `scrollable-auto-tabpanel-${index}`,
        };
    }


    return (
        <div>
            <IconButton color="primary" aria-label="add" className={classes.iconButton} onClick={handleClickOpen}>
                <AddIcon />
            </IconButton>
            <Dialog open={open} onClose={handleClose} aria-labelledby="form-dialog-title">
                <Paper className={classes.root}>
                    <Tabs
                        value={value}
                        onChange={handleChange}
                        indicatorColor="primary"
                        textColor="primary"
                        centered
                    >
                        <Tab label="Ajouter Médecin" {...a11yProps(0)} />
                        <Tab label="Ajouter Etablissement" {...a11yProps(1)} />
                        <Tab label="Ajouter Agenda" {...a11yProps(2)} />
                    </Tabs>
                </Paper>
                <TabPanel value={value} index={0}>
                    <AddDoctor />
                </TabPanel>
                <TabPanel value={value} index={1}>
                    <AddDoctor />
                </TabPanel>
                <TabPanel value={value} index={2}>
                    <AddDoctor />
                </TabPanel>
            </Dialog>
        </div>
    );
}