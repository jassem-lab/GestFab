import { Paper, Table, TableBody, TableCell, TableContainer, TableHead, TableRow } from '@material-ui/core';
import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { getEtablissements } from '../../../actions/etablissements'


export default function Etablissements(props) {
    const dispatch = useDispatch()
    // eslint-disable-next-line
    const { etablissements } = useSelector((state) => state.etablissements)

    const {
        selectEtablissements,
    } = props;

    useEffect(() => {
        dispatch(getEtablissements())
    }, [dispatch])
    useEffect(selectEtablissements, [selectEtablissements]);
   
    return (
        <Paper sx={{ width: '100%', overflow: 'hidden' }}>
            <TableContainer sx={{ maxHeight: 440 }}>
                <Table stickyHeader aria-label="sticky table">
                    <TableHead>
                    <TableRow>
                        <TableCell>Name</TableCell>
                        <TableCell align="right">Phone</TableCell>
                        <TableCell align="right">Email</TableCell>
                        <TableCell align="right">Etablissement</TableCell>
                        <TableCell align="right">Agenda</TableCell>
                    </TableRow>
                    </TableHead>
                    <TableBody>
                        {etablissements?.map((etablissement) => {
                                return (
                                    <TableRow hover role="checkbox" tabIndex={-1} key={etablissement.code}>
                                        {etablissements.map((etablissement) => {
                                            const value = etablissement[etablissement.id];
                                            return (
                                                <TableCell key={etablissement.id} align={etablissement.align}>
                                                    {etablissement.format && typeof value === 'number'
                                                        ? etablissement.format(value)
                                                        : value}
                                                </TableCell>
                                            );
                                        })}
                                    </TableRow>
                                );
                            })}
                    </TableBody>
                </Table>
            </TableContainer>
        </Paper>
    );
}
