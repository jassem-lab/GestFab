import moment from "moment";
import React, { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { sendSms, smsGetTomorrow } from "../../../actions/sms";
import "./sms.css";
import {
  Checkbox,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
} from "@material-ui/core";

const mapAppointmentsData = (appointment) => {
  return {
    id: appointment._id,
    start: moment(appointment.date).format("DD/MM/YYYY HH:mm"),
    doctor: appointment.doctor,
    patient: appointment.name,
    phone: appointment.phone,
    selected: appointment.phone.length > 0 ? true : false,
  };
};

function SmsModal(props) {
  const { onClose, open } = props;
  const dispatch = useDispatch();
  const { tomorrowApps, SmsIsLoading, message } = useSelector(
    (state) => state.sms
  );
  const [sms, setSms] = React.useState([]);
    
  useEffect(() => {
    if (open) {
      dispatch(smsGetTomorrow());
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open]);

  useEffect(() => {
    if (tomorrowApps?.length > 0) {
      setSms(tomorrowApps?.map((app) => mapAppointmentsData(app)));
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tomorrowApps]);

  const handleSendSms = (e) => {
    e.preventDefault();
    dispatch(sendSms()).then(() => {
      onClose();
    });
  };

  return (
    <div className={`smsModal ${open && "show"}`}>
      <div className="smsModal-content">
        <div className="close-modal" onClick={onClose}>
          X
        </div>
        <div style={{ height: 400, width: "100%", overflowY: "auto" }}>
          {SmsIsLoading && (
            <img
              src="/images/admin-loading.gif"
              alt="loading"
              style={{
                position: "absolute",
                top: "48%",
                left: "48%",
                width: "40px",
                height: "40px",
              }}
            />
          )}
          <TableContainer>
            <Table aria-label="simple table">
              <TableHead>
                <TableRow>
                  <TableCell>Select</TableCell>
                  <TableCell align="center">Date</TableCell>
                  <TableCell align="center">Doctor</TableCell>
                  <TableCell align="center">Patient</TableCell>
                  <TableCell align="center">Phone</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {sms?.map((row, index) => (
                  <TableRow key={row.id}>
                    <TableCell>
                      <Checkbox
                        checked={row.selected}
                        onChange={() =>
                          setSms(
                            sms?.map((s, i) => {
                              if (i === index) {
                                s.selected = !s.selected;
                              }
                              return s;
                            })
                          )
                        }
                        name="checkedA"
                      />
                    </TableCell>
                    <TableCell align="center">{row.start}</TableCell>
                    <TableCell align="center">{row.doctor}</TableCell>
                    <TableCell align="center">{row.patient}</TableCell>
                    <TableCell align="center">{row.phone}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
        </div>
        <div className="smsModal-footer">
          {message && <div className="smsModal-footer-message">{message}</div>}
          <button className="btn btn-primary" onClick={(e) => handleSendSms(e)}>
            Send SMS
          </button>
        </div>
      </div>
    </div>
  );
}

export default SmsModal;
