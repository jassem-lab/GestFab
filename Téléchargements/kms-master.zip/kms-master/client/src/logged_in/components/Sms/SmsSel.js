import moment from "moment";
import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { smsGetTomorrow } from "../../../actions/sms";
import "./sms.css";
import { API } from "../../../api/index";
import LocalizationProvider from "@mui/lab/LocalizationProvider";
import AdapterDateFns from "@mui/lab/AdapterDateFns";
import DesktopDatePicker from "@mui/lab/DesktopDatePicker";
import {
  FormControl,
  InputLabel,
  makeStyles,
  NativeSelect,
  TextField,
} from "@material-ui/core";
import {
  Checkbox,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
} from "@material-ui/core";
import "react-datepicker/dist/react-datepicker.css";

const mapAppointmentsData = (appointment) => {
  return {
    id: appointment._id,
    start: moment(appointment.date).format("DD/MM/YYYY HH:mm"),
    doctor: appointment.doctor,
    patient: appointment.name,
    phone: appointment.phone,
    selected: appointment.phone.length > 0 ? true : false,
  };
};
const useStyles = makeStyles((theme) => ({
  margin: {
    display: "flexbox",
    flexDirection: "row",
    margin: theme.spacing(1),
  },
  typography: {
    marginBottom: "60px",
    margin: theme.spacing(1),
    color: "black",
  },
  select: {
    margin: theme.spacing(1),
    width: "220px",
    color: "rgb(72,41,178)",
    fontWeight: "bold",
  },
}));
const SmsSelect = (props) => {
  const classes = useStyles();
  const [doctor, setDoctor] = useState("");
  const [count, setCount] = React.useState(0);
  const [formData, setFormData] = useState("");
  const { onClose, open } = props;
  const dispatch = useDispatch();
  const { tomorrowApps, SmsIsLoading, message } = useSelector(
    (state) => state.sms
  );

  const { doctors } = useSelector((state) => state.doctors);
  const [sms, setSms] = React.useState([]);

  useEffect(() => {
    if (open) {
      dispatch(smsGetTomorrow());
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open]);

  const handleChangeDoctor = (event) => {
    localStorage.setItem("doctorID", event.target.value);
    setDoctor(localStorage.getItem("doctorID"));
  };
  const customedSms = sms.filter((sms) => sms.doctor === doctor);
  const customSms = {
    doctor,
    message: formData.message,
    customedSms,
  };
  const handleSendSms = (e) => {
    e.preventDefault();
    API.post("/api/customSms/sendCustomSms", customSms)
      .then(() => {
        console.log("Sms Created");
        onClose();
      })
      .catch((err) => {
        console.error(err);
      });
  };
  // moment(date).format("YYYY/MM/DD")
  const [startDate, setStartDate] = useState(null);
  const [endDate, setEndDate] = useState(null);
  const [apps, setApps] = useState([]);

  useEffect(() => {
    try {
      API.get(`/api/customSms/getAllApps/${startDate}/${endDate}`).then(
        (response) => {
          setApps(response.data.tomorrowSms);
          console.log(response.data.tomorrowSms);
          console.log(response);
        }
      );
    } catch (error) {
      console.log(error);
    }
  }, []);

  useEffect(() => {
    if (apps?.length > 0) {
      setSms(apps?.map((appointment) => mapAppointmentsData(appointment)));
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [apps]);

  const [selected, setSelected] = useState([]);
  const isAllSelected = sms.length > 0 && selected.length === sms.length;

  const handleChange = (event) => {
    const value = event.target.value;
    console.log(value);
    if (value === "all") {
      setSelected(selected.length === sms.length ? [] : sms);
      return;
    }

    setSelected(value);
    console.log("values", selected);
    // const list = [...selected];

    // const index = list.indexOf(value);
    // index === -1 ? list.push(value) : list.splice(index, 1);
    // setSelected(list);
    // console.log(list);
  };
  console.log(selected);
  const arrValues = [];
  console.log(arrValues);
  const listItems = sms?.map((row, index) => {
    return (
      <TableRow key={row.id}>
        <TableCell>
          <Checkbox
            value={row}
            checked={selected.includes(row)}
            onChange={handleChange}
            name="checkedA"
          />
        </TableCell>
        <TableCell align="center">{row.start}</TableCell>
        <TableCell align="center">{row.doctor}</TableCell>
        <TableCell align="center">{row.patient}</TableCell>
        <TableCell align="center">{row.phone}</TableCell>
      </TableRow>
    );
  });

  const listItemsByDoc = sms
    .filter((sms) => sms.doctor === doctor)
    .map((row) => {
      return (
        <TableRow key={row.id}>
          <TableCell>
            <Checkbox
              value={row}
              checked={selected.includes(row.id)}
              onChange={handleChange}
              name="checkedA"
            />
          </TableCell>
          <TableCell align="center">{row.start}</TableCell>
          <TableCell align="center">{row.doctor}</TableCell>
          <TableCell align="center">{row.patient}</TableCell>
          <TableCell align="center">{row.phone}</TableCell>
        </TableRow>
      );
    });

  return (
    <div className={`smsModal ${open && "show"}`}>
      <div className="smsModal-content">
        <div className="close-modal" onClick={onClose}>
          X
        </div>

        <div
          style={{
            display: "flex",
            flexDirection: "column",
            margin: "0 auto",
            alignItems: "center",
            maxWidth: "700px",
          }}
        >
          {" "}
          <FormControl variant="outlined" className={classes.margin}>
            <InputLabel htmlFor="selectdoctor" className={classes.typography}>
              Selectionner médecin{" "}
            </InputLabel>
            <NativeSelect
              value={doctor}
              onChange={handleChangeDoctor}
              className={classes.select}
              inputProps={{
                name: "doctor",
              }}
            >
              <option aria-label="None" value="" />
              <option key="1" value="All Doctors">
                Tous les docteurs
              </option>
              {doctors?.map((doctor) => (
                <option key={doctor._id} value={doctor.user.name}>
                  {doctor.user.name}
                </option>
              ))}
            </NativeSelect>
          </FormControl>
          <TextField
            multiline={true}
            rows={6}
            style={{
              width: "100%",
            }}
            name="SmsContent"
            id="SmsContent"
            placeholder="Motif de l'SMS"
            onChange={(e) => {
              setCount(e.target.value.length);
              setFormData({
                message: e.target.value,
              });
            }}
          />
          <p
            style={{
              fontSize: "10px",
              position: "relative",
              right: "0",
            }}
          >
            Nombre des characteres: {count}/185
          </p>
        </div>
        <div></div>
        <div style={{ display: "flex", justifyContent: "space-around" }}>
          <LocalizationProvider dateAdapter={AdapterDateFns}>
            <DesktopDatePicker
              label="Start Date"
              value={startDate}
              onChange={(date) => {
                setStartDate(moment(date).format("YYYY-MM-DD"));
              }}
              inputFormat="MM/dd/yyyy"
              renderInput={(params) => <TextField {...params} />}
            />
          </LocalizationProvider>
          <LocalizationProvider dateAdapter={AdapterDateFns}>
            <DesktopDatePicker
              label="End Date"
              value={endDate}
              onChange={(date) => {
                setEndDate(moment(date).format("YYYY-MM-DD"));
              }}
              inputFormat="MM/dd/yyyy"
              renderInput={(params) => <TextField {...params} />}
            />
          </LocalizationProvider>
        </div>
        <div style={{ height: 400, width: "100%", overflowY: "auto" }}>
          {SmsIsLoading && (
            <img
              src="/images/admin-loading.gif"
              alt="loading"
              style={{
                position: "absolute",
                top: "48%",
                left: "48%",
                width: "40px",
                height: "40px",
              }}
            />
          )}

          <TableContainer>
            <Table aria-label="simple table" height={680}>
              <TableHead>
                <TableRow>
                  <TableCell>
                    Select{" "}
                    <Checkbox
                      value="all"
                      onChange={handleChange}
                      checked={isAllSelected}
                    />
                  </TableCell>
                  <TableCell align="center">Date</TableCell>
                  <TableCell align="center">Doctor</TableCell>
                  <TableCell align="center">Patient</TableCell>
                  <TableCell align="center">Phone</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {doctor === "All Doctors" ? listItems : listItemsByDoc}
              </TableBody>
            </Table>
          </TableContainer>
        </div>
        <div className="smsModal-footer">
          {message && <div className="smsModal-footer-message">{message}</div>}
          <button className="btn btn-primary" onClick={(e) => handleSendSms(e)}>
            Send SMS
          </button>
        </div>
      </div>
    </div>
  );
};

export default SmsSelect;

// import { Checkbox } from "@material-ui/core";
// import { useState } from "react";

// const options = ["Selected Item 1", "Selected Item 2", "Selected Item 3"];

// export default function SmsSelect() {
//   const [selected, setSelected] = useState([]);
//   const isAllSelected =
//     options.length > 0 && selected.length === options.length;

//   const handleChange = (event) => {
//     const value = event.target.value;
//     console.log(value);
//     if (value === "all") {
//       setSelected(selected.length === options.length ? [] : options);
//       return;
//     }
//     // added below code to update selected options
//     const list = [...selected];
//     const index = list.indexOf(value);
//     index === -1 ? list.push(value) : list.splice(index, 1);
//     setSelected(list);
//   };

//   console.log(selected)

//   const listItem = options.map((option) => {
//     return (
//       <div key={option}>
//         <Checkbox
//           value={option}
//           onChange={handleChange}
//           checked={selected.includes(option)}
//         />
//         <span>{option}</span>
//       </div>
//     );
//   });

//   return (
//     <div style={{ display: "flex", alignItems: "center", margin: 10 }}>
//       <Checkbox value="all" onChange={handleChange} checked={isAllSelected} />
//       <span> Select All</span>
//       {listItem}
//     </div>
//   );
// }
