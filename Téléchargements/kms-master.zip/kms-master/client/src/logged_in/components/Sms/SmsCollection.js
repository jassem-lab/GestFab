import moment from "moment";
import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { smsGetTomorrow } from "../../../actions/sms";
import "./sms.css";
import { API } from "../../../api/index";
import LocalizationProvider from "@mui/lab/LocalizationProvider";
import AdapterDateFns from "@mui/lab/AdapterDateFns";
import DesktopDatePicker from "@mui/lab/DesktopDatePicker";
import {
  FormControl,
  InputLabel,
  makeStyles,
  NativeSelect,
  TextField,
} from "@material-ui/core";
import {
  Checkbox,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
} from "@material-ui/core";
import "react-datepicker/dist/react-datepicker.css";

export const SmsSelection = (props) => {
  // const mapAppointmentsData = (appointment) => {
  //   return {
  //     id: appointment._id,
  //     start: moment(appointment.date).format("DD/MM/YYYY HH:mm"),
  //     doctor: appointment.doctor,
  //     patient: appointment.name,
  //     phone: appointment.phone,
  //     selected: appointment.phone.length > 0 ? true : false,
  //   };
  // };
  const { sms, doctor, handleClick, id } = props;
  // console.log(sms)
  // console.log(doctor)
  const useStyles = makeStyles((theme) => ({
    margin: {
      display: "flexbox",
      flexDirection: "row",
      margin: theme.spacing(1),
    },
    typography: {
      marginBottom: "60px",
      margin: theme.spacing(1),
      color: "black",
    },
    select: {
      margin: theme.spacing(1),
      width: "220px",
      color: "rgb(72,41,178)",
      fontWeight: "bold",
    },
  }));
  // const classes = useStyles();
  // const [doctor, setDoctor] = useState("");
  // const [count, setCount] = React.useState(0);
  // const [formData, setFormData] = useState("");
  // const { onClose, open } = props;
  // const dispatch = useDispatch();
  // const { SmsIsLoading, message } = useSelector((state) => state.sms);
  const [isCheckAll, setIsCheckAll] = useState(true);
  const [isCheck, setIsCheck] = useState([]);

  // const { doctors } = useSelector((state) => state.doctors);
  // const [sms, setSms] = React.useState([]);

  // useEffect(() => {
  //   if (open) {
  //     dispatch(smsGetTomorrow());
  //   }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  // }, [open]);

  // const handleChange = (event) => {
  //   localStorage.setItem("doctorID", event.target.value);
  //   setDoctor(localStorage.getItem("doctorID"));
  // };
  // const customedSms = sms.filter((sms) => sms.doctor === doctor);
  // const customSms = {
  //   doctor,
  //   message: formData.message,
  //   customedSms,
  // };
  // const handleSendSms = (e) => {
  //   e.preventDefault();
  //   API.post("/api/customSms/sendCustomSms", customSms)
  //     .then(() => {
  //       console.log("Sms Created");
  //       onClose();
  //     })
  //     .catch((err) => {
  //       console.error(err);
  //     });
  // };
  // moment(date).format("YYYY/MM/DD")
  // const [startDate, setStartDate] = useState(null);
  // const [endDate, setEndDate] = useState(null);
  // const [apps, setApps] = useState([]);

  // useEffect(() => {
  //   try {
  //     API.get(`/api/customSms/getAllApps/${startDate}/${endDate}`).then(
  //       (response) => {
  //         setApps(response.data.tomorrowSms);
  //       }
  //     );
  //   } catch (error) {
  //     console.log(error);
  //   }
  // }, [apps]);

  // useEffect(() => {
  //   if (apps?.length > 0) {
  //     setSms(apps?.map((appointment) => mapAppointmentsData(appointment)));
  //   }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  // }, [apps]);

  //  Select

  return (
    <div>
      {" "}
      {/* <TableContainer>
        <Table aria-label="simple table" height={680}>
          <TableHead>
            <TableRow>
              <TableCell>
                Select
                <Checkbox
                  checked={isCheckAll}
                  onChange={handleSelectAll}
                  name="checkedA"
                />
              </TableCell>
              <TableCell align="center">Date</TableCell>
              <TableCell align="center">Doctor</TableCell>
              <TableCell align="center">Patient</TableCell>
              <TableCell align="center">Phone</TableCell>
            </TableRow>
          </TableHead>
          <TableBody> */}
      {sms && doctor === "All Doctors"
        ? sms?.map((row, index) => (
            <TableRow key={row.id}>
              <TableCell>
                <Checkbox
                  key={index}
                  type="checkbox"
                  F
                  handleClick={handleClick}
                  checked={isCheck.includes(id)}
                />
              </TableCell>
              <TableCell align="center">{row.start}</TableCell>
              <TableCell align="center">{row.doctor}</TableCell>
              <TableCell align="center">{row.patient}</TableCell>
              <TableCell align="center">{row.phone}</TableCell>
            </TableRow>
          ))
        : sms
            ?.filter((sms) => sms.doctor === doctor)
            .map((row, index) => (
              <TableRow key={row.id}>
                <TableCell>
                  <Checkbox
                    key={index}
                    type="checkbox"
                    handleClick={handleClick}
                    isChecked={isCheck.includes(id)}
                  />
                </TableCell>
                <TableCell align="center">{row.start}</TableCell>
                <TableCell align="center">{row.doctor}</TableCell>
                <TableCell align="center">{row.patient}</TableCell>
                <TableCell align="center">{row.phone}</TableCell>
              </TableRow>
            ))}
      {/* </TableBody>
        </Table>
      </TableContainer> */}
    </div>
  );
};
