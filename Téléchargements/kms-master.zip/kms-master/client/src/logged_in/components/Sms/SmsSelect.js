import moment from "moment";
import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { smsGetTomorrow } from "../../../actions/sms";
import "./sms.css";
import { API } from "../../../api/index";
import LocalizationProvider from "@mui/lab/LocalizationProvider";
import AdapterDateFns from "@mui/lab/AdapterDateFns";
import DesktopDatePicker from "@mui/lab/DesktopDatePicker";
import {
  FormControl,
  InputLabel,
  makeStyles,
  NativeSelect,
  TextField,
} from "@material-ui/core";
// import {
//   Checkbox,
//   Table,
//   TableBody,
//   TableCell,
//   TableContainer,
//   TableHead,
//   TableRow,
// } from "@material-ui/core";
import "react-datepicker/dist/react-datepicker.css";
import { DataGrid, GridRowsProp, GridColDef } from "@mui/x-data-grid";
const mapAppointmentsData = (appointment) => {
  return {
    id: appointment.appId,
    start: moment(appointment.date).format("DD/MM/YYYY HH:mm"),
    doctor: appointment.doctor,
    patient: appointment.name,
    phone: appointment.phone,
  };
};
const useStyles = makeStyles((theme) => ({
  margin: {
    display: "flexbox",
    flexDirection: "row",
    margin: theme.spacing(1),
  },
  typography: {
    marginBottom: "60px",
    margin: theme.spacing(1),
    color: "black",
  },
  select: {
    margin: theme.spacing(1),
    width: "220px",
    color: "rgb(72,41,178)",
    fontWeight: "bold",
  },
}));
const SmsSelect = (props) => {
  const classes = useStyles();
  const [doctor, setDoctor] = useState("");
  const [count, setCount] = React.useState(0);
  const [formData, setFormData] = useState("");
  const { onClose, open } = props;
  const dispatch = useDispatch();
  const { tomorrowApps, SmsIsLoading, message } = useSelector(
    (state) => state.sms
  );

  const { doctors } = useSelector((state) => state.doctors);
  const [sms, setSms] = React.useState([]);

  useEffect(() => {
    if (open) {
      dispatch(smsGetTomorrow());
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open]);
  const [selectedRows, setSelectedRows] = React.useState([]);
  const handleChangeDoctor = (event) => {
    localStorage.setItem("doctorID", event.target.value);
    setDoctor(localStorage.getItem("doctorID"));
  };
  console.log(selectedRows)
  const customedSms = selectedRows;
  const customSms = {
    doctor,
    message: formData.message,
    customedSms,
  };
  const handleSendSms = (e) => {
    e.preventDefault();
    API.post("/api/customSms/sendCustomSms", customSms)
      .then(() => {
        console.log("Sms Created");
        onClose();
      })
      .catch((err) => {
        console.error(err);
      });
  };
  // moment(date).format("YYYY/MM/DD")
  const [startDate, setStartDate] = useState(null);
  const [endDate, setEndDate] = useState(null);
  const [apps, setApps] = useState([]);

  useEffect(() => {
    try {
      API.get(`/api/customSms/getAllApps/${startDate}/${endDate}`).then(
        (response) => {
          setApps(response.data.tomorrowSms);
          console.log(response);
        }
      );
    } catch (error) {
      console.log(error);
    }
  }, [doctor]);

  useEffect(() => {
    if (apps?.length > 0) {
      setSms(apps?.map((appointment) => mapAppointmentsData(appointment)));
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [doctor]);

  const columns = [
    { field: "doctor", headerName: "Doctor", width: 200 },
    { field: "patient", headerName: "Patient", width: 200 },
    { field: "phone", headerName: "Phone", width: 200 },
    { field: "start", headerName: "Date", width: 200 },
  ];

  const [pageSize, setPageSize] = React.useState(6);
  console.log(sms);
  return (
    <div className={`smsModal ${open && "show"}`}>
      <div className="smsModal-content">
        <div className="close-modal" onClick={onClose}>
          X
        </div>

        <div
          style={{
            display: "flex",
            flexDirection: "column",
            margin: "0 auto",
            alignItems: "center",
            maxWidth: "700px",
          }}
        >
          {" "}
          <FormControl variant="outlined" className={classes.margin}>
            <InputLabel htmlFor="selectdoctor" className={classes.typography}>
              Selectionner médecin{" "}
            </InputLabel>
            <NativeSelect
              value={doctor}
              onChange={handleChangeDoctor}
              className={classes.select}
              inputProps={{
                name: "doctor",
              }}
            >
              <option aria-label="None" value="" />
              <option key="1" value="All Doctors">
                Tous les docteurs
              </option>
              {doctors?.map((doctor) => (
                <option key={doctor._id} value={doctor.user.name}>
                  {doctor.user.name}
                </option>
              ))}
            </NativeSelect>{" "}
            <button
              className="btn  btn-primary"
              onClick={(e) => handleSendSms(e)}
            >
              Send SMS
            </button>
          </FormControl>
          <TextField
            multiline={true}
            rows={6}
            style={{
              width: "100%",
            }}
            name="SmsContent"
            id="SmsContent"
            placeholder="Motif de l'SMS"
            onChange={(e) => {
              setCount(e.target.value.length);
              setFormData({
                message: e.target.value,
              });
            }}
          />
          <p
            style={{
              fontSize: "10px",
              position: "relative",
              right: "0",
            }}
          >
            Nombre des characteres: {count}/185
          </p>
        </div>
        <div></div>
        <div style={{ display: "flex", justifyContent: "space-around" }}>
          <LocalizationProvider dateAdapter={AdapterDateFns}>
            <DesktopDatePicker
              label="Start Date"
              value={startDate}
              onChange={(date) => {
                setStartDate(moment(date).format("YYYY-MM-DD"));
              }}
              inputFormat="MM/dd/yyyy"
              renderInput={(params) => <TextField {...params} />}
            />
          </LocalizationProvider>
          <LocalizationProvider dateAdapter={AdapterDateFns}>
            <DesktopDatePicker
              label="End Date"
              value={endDate}
              onChange={(date) => {
                setEndDate(moment(date).format("YYYY-MM-DD"));
              }}
              inputFormat="MM/dd/yyyy"
              renderInput={(params) => <TextField {...params} />}
            />
          </LocalizationProvider>
        </div>
        {sms && doctor === "All Doctors" ? (
          <div style={{ height: "400 !important", width: "100%" }}>
            <DataGrid
              rows={sms}
              columns={columns}
              pageSize={pageSize}
              checkboxSelection
              onPageSizeChange={(newPageSize) => setPageSize(newPageSize)}
              rowsPerPageOptions={[6, 10, 20]}
              pagination
              onSelectionModelChange={(ids) => {
                const selectedIDs = new Set(ids);
                const selectedRows = sms.filter((row) =>
                  selectedIDs.has(row.id)
                );

                setSelectedRows(selectedRows);
              }}
            />
          </div>
        ) : (
          <DataGrid
            rows={sms.filter((sm) => sm.doctor === doctor)}
            columns={columns}
            pageSize={pageSize}
            checkboxSelection
            onPageSizeChange={(newPageSize) => setPageSize(newPageSize)}
            rowsPerPageOptions={[6, 10, 20]}
            pagination
            onSelectionModelChange={(ids) => {
              const selectedIDs = new Set(ids);
              const selectedRows = sms.filter((row) => selectedIDs.has(row.id));

              setSelectedRows(selectedRows);
            }}
          />
        )}

        <div className="smsModal-footer">
          {message && <div className="smsModal-footer-message">{message}</div>}
        </div>
      </div>
    </div>
  );
};

export default SmsSelect;
