import React, { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { smsGetLog } from "../../../actions/sms";
import "./sms.css";
import {
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
} from "@material-ui/core";

function LogModal(props) {
  const { onClose, open } = props;
  const dispatch = useDispatch();
  const { SmsIsLoading, smsLog } = useSelector((state) => state.sms);

  useEffect(() => {
    if (open) {
      dispatch(smsGetLog());
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open]);

  return (
    <div className={`smsModal ${open && "show"}`}>
      <div className="smsModal-content">
        <div className="close-modal" onClick={onClose}>
          X
        </div>
        <div style={{ height: 400, width: "100%", overflowY: "auto" }}>
          {SmsIsLoading && (
            <img
              src="/images/admin-loading.gif"
              alt="loading"
              style={{
                position: "absolute",
                top: "48%",
                left: "48%",
                width: "40px",
                height: "40px",
              }}
            />
          )}
          <TableContainer>
            <Table aria-label="simple table">
              <TableHead>
                <TableRow>
                  <TableCell align="center">Date</TableCell>
                  <TableCell align="center">Doctor</TableCell>
                  <TableCell align="center">Patient</TableCell>
                  <TableCell align="center">Phone</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {smsLog?.map((row, index) => (
                  <TableRow key={row.id}>
                    <TableCell align="center">{row.date}</TableCell>
                    <TableCell align="center">{row.doctor}</TableCell>
                    <TableCell align="center">{row.patient}</TableCell>
                    <TableCell align="center">{row.phone}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
        </div>
      </div>
    </div>
  );
}

export default LogModal;
