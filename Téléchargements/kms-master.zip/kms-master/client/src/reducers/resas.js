import { CHANGE_STATUS_RESA, CREATE_RESA, DELETE_RESA, EDIT_RESA, GET_RESAS, GET_RESAS_BY_AGENDAS, GET_RESAS_BY_DOCTORID, GET_RESAS_BY_ETABLISSEMENTID, GET_RESAS_BY_MONTH, RESA_END_LOADING, RESA_LOADING } from "../constants/actionTypes";

const appointmentsReducers = (state = { ResasIsLoading: false, resas: [], resa: {} }, action) => {
  switch (action.type) {
    case RESA_LOADING:
      return { ...state, ResasIsLoading: true };
    case RESA_END_LOADING:
      return { ...state, ResasIsLoading: false };
    case GET_RESAS:
      return { ...state, resas: action.payload };
    case GET_RESAS_BY_MONTH:
      return { ...state, resas: action.payload };
    case GET_RESAS_BY_AGENDAS:
      return { ...state, resas: action.payload };
    case GET_RESAS_BY_DOCTORID:
        return { ...state, resas: action.payload };
    case GET_RESAS_BY_ETABLISSEMENTID:
        return { ...state, resas: action.payload };
    case CREATE_RESA:
      return { ...state, resas: [...state.resas, action.payload] };
    case EDIT_RESA:
      return { ...state, resas:  state.resas.map((resa) => resa._id === action.payload._id ? action.payload : resa) };
    case DELETE_RESA:
      return { ...state, resas: state.resas.filter((resa) => resa._id !== action.payload) }; 
    case CHANGE_STATUS_RESA:
      return { ...state, resas:  state.resas.map((resa) => {
        if (resa._id === action.payload.id) {
          return {
            ...resa,
            status: action.payload.status,
            takedBy: action.payload.takedBy,
          }
        } else {
          return resa;
        } 
      })};
    default:
      return state;
  }
};

export default appointmentsReducers;
