import { APPOINTMENTS_END_LOADING, APPOINTMENTS_LOADING, GET_APPOINTMENTS, CREATE_APPOINTMENT, EDIT_APPOINTMENT, DELETE_APPOINTMENT, FILTER_APPOINTMENTS, CHANGE_STATUS_APPOINTMENT, ADD_MANY_APPOINTMENTS, GET_MY_APPOINTMENTS, SEED_APPOINTMENTS, GET_APPOINTMENTS_BY_MONTH, APPOINTMENTS_ERROR} from "../constants/actionTypes";

const appointmentsReducers = (state = { AppointmentsIsLoading: true, AppointmentsError: null, appointments: [], appointment: {}, message: '' }, action) => {
  switch (action.type) {
    case APPOINTMENTS_LOADING:
      return { ...state, AppointmentsIsLoading: true };
    case APPOINTMENTS_END_LOADING:
      return { ...state, AppointmentsIsLoading: false };
    case APPOINTMENTS_ERROR:
      return { ...state, AppointmentsError: action.payload.message };
    case GET_APPOINTMENTS:
      return { ...state, appointments: action.payload };
    case GET_MY_APPOINTMENTS:
      return { ...state, appointments: action.payload.data, numberOfPages: action.payload.numberOfPages };
    case FILTER_APPOINTMENTS:
      return { ...state, appointments: action.payload.data, numberOfPages: action.payload.numberOfPages };
    case GET_APPOINTMENTS_BY_MONTH:
      return { ...state, appointments: action.payload };
    case CREATE_APPOINTMENT:
      return { ...state, appointments: [...state.appointments, action.payload] };
    case EDIT_APPOINTMENT:
      return { ...state, appointments:  state.appointments.map((pat) => pat._id === action.payload._id ? action.payload : pat) };
    case CHANGE_STATUS_APPOINTMENT:
      return { ...state, appointments:  state.appointments.map((pat) => pat._id === action.payload._id ? action.payload : pat) };
    case ADD_MANY_APPOINTMENTS:
     // return { ...state, appointments:  action.payload };
     return null;
    case DELETE_APPOINTMENT:
      return { ...state, appointments: state.appointments.filter((pat) => pat._id !== action.payload) }; 
    case SEED_APPOINTMENTS:
      return { ...state, appointment: action.payload };
    default:
      return state;
  }
};

export default appointmentsReducers;
