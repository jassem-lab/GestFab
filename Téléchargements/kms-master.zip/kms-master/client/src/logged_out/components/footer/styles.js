import { makeStyles } from "@material-ui/core";

export default makeStyles((theme) => ({
    footer: {
        width: '100%',
        padding: '40px 0',
        background: '#113a67',
        marginTop: '40px',
    },
    footerContainer: {
        width: '80%',
        margin: '0 auto',
        display: 'flex',
        justifyContent: 'space-between',
        [theme.breakpoints.down('xs')]: {
            width: '90%',
            flexWrap: 'wrap',
        },
    },
    footerItem: {
        width: '28%',
        [theme.breakpoints.down('xs')]: {
            width: '100%',
        },
    }
    
  }));