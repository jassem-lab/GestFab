import React from "react";
import useStyles from './styles';
import LocationOnRoundedIcon from '@material-ui/icons/LocationOnRounded';


function Footer(props) {
  const classes = useStyles();
  return (
    <footer className={classes.footer}>
      <div className={classes.footerContainer}>
        <div className={classes.footerItem}>
          <img src="/images/logged_out/logo-white.png" alt="logo" style={{ width: '70%', display: 'block', margin: '10px 0 20px'}} />
          <div style={{ display: 'flex' }}>
           <LocationOnRoundedIcon style={{ color: '#56a7dc', fontSize: '18px', marginRight: '10px' }} />
           <span style={{ fontSize: '11px', fontWeight: 'bold', color: '#BBB' }}>28 Rue ROBERT BECHADE 79110 Chef-Boutonne</span>
          </div>
        </div>
        <div className={classes.footerItem}>
          <h3 style={{ color: '#EEE' }}>Informations pratiques</h3>
          <p style={{ color: '#BBB', margin: '0 0 10px' }}>Accès pour personnes à mobilité réduite: oui</p>
          <p style={{ color: '#BBB' }}>Etage: RDC MAISON INDIVIDUELLE</p>
        </div>
        <div className={classes.footerItem}>
          <h3 style={{ color: '#EEE' }}>Moyen de transport</h3>
          <p style={{ color: '#BBB' }}>
          Parking privatif Le cabinet de Kinésithérapie se trouve sur la rue Robert Béchade en direction de Ruffec. En raison de la crise sanitaire, les toilettes ne sont pas accessibles, merci de prendre vos précautions
          </p>
        </div>
      </div>
    </footer>
  );
}

export default Footer;
