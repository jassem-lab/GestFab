import { makeStyles } from "@material-ui/core";

export default makeStyles((theme) => ({
    cellule: {
      transition: 'all 0.5s ease-in-out',
      border: '1px solid #aaa',
      cursor: 'pointer',
    },
    celluleIcon: {
      fontSize: '14px',
      position: 'absolute',
      bottom: '5px',
      right: '5px',
      opacity: '0',
      color: '#fff',
      transition: 'all 0.5s ease-in-out',
      '&:hover': {
        transform: 'scale(1.2)',
        color: '#333',
      },
    },
    celluleItem: {
      opacity: '0.5', 
      transition: 'all 0.5s ease-in-out',
      border: '1px solid #eee',
      borderRadius: '5px',
      cursor: 'pointer',
      '&:hover': {
        opacity: '0.8',
        border: '1px solid #e0e0e0',
      },
      '&:hover $celluleIcon': {
        opacity: '1',
      }
    },
    filterContainer: {
      padding: "10px",
      backgroundColor: "#fafafa",
    },
    filterTitle: {
      fontSize: "20px",
      fontWeight: "bold",
      textAlign: 'center',
      marginBottom: "20px",
    },
    filterBlock: {
      marginBottom: "10px",
    },
    filterButton: {
      display: 'block',
      width: "100%",
      boxShadow: "1px 3px 5px rgba(0,0,0,0.25)",
      backgroundColor: "#CCC",
      borderRadius: "5px",
      padding: "10px",
      marginBottom: "10px",
      cursor: "pointer",
    },
    headerCell: {
      backgroundColor: '#fff',
      '&:hover': {
        backgroundColor: '#fff',
      },
      '&:focus': {
        backgroundColor: '#fff',
      },
    },
    flexibleContainer: {
      background: 'none',
      backgroundColor: 'transparent'
    },
    flexibleSpace: {
      display: 'flex',
      justifyContent: 'center',
      alignItems: 'center',
      padding: '5px 20px',
    },
    doctorBtn: {
      margin: '0 10px',
      padding: '8px 20px',
      background: '#fff',
      textAlign: 'center',
      borderRadius: '5px',
      cursor: 'pointer',
      whiteSpace: 'nowrap',
      fontSize: '1rem',
      opacity: '0.8',
      outline: 'none',
    },
    paper: {
      flexGrow: 1,
      padding: 30,
      transition: 'all 0.6s ease-in-out',
    },
    actionBlock: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      position: 'relative',
    },
    actionLabel: {
      width: '30%',
      fontSize: '1.1rem',
    },
    confirmUl: {
        listStyle: 'none',
        width: '70%',
        padding: "15px",
        margin: "0"
    },
    confirmFeedback: {
        fontSize: '1.1rem',
        color: '#C00',
        position: 'absolute',
        bottom: '10px',
        left: '10px',
    },
    select: {
      width: '70%',
      padding: '5px 10px',
      borderRadius: '5px',
    },
    calendarContainer: {
      width: '80%',
      margin: '20px auto 0',
      backgroundColor: 'rgba(255,255,255,0.8)',
      borderRadius: '5px',
      padding: '20px',
      height: '550px',
      display: 'flex',
      justifyContent: 'center',
      alignItems: 'center',
      [theme.breakpoints.down('xs')]: {
        width: '100%',
        height: '400px',
      },
      '& h3': {
        fontSize: '25px',
        fontWeight: 'bold',
        letterSpacing: '2px',
        [theme.breakpoints.down('xs')]: {
          fontSize: '20px',
          textAlign: 'center',
        },
      }
    },
    loadingContainer: {
      display: 'flex',
      height: '100%',
      alignItems: 'center',
      justifyContent: 'center',
    },
    loading: {
      width: '80px',
    },
    infosContainer: {
      position: 'relative',
      width: '80%',
      margin: '60px auto 0',
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      [theme.breakpoints.down('xs')]: {
        width: '90%',
        flexWrap: 'wrap',
        justifyContent: 'center',
        alignItems: 'center',
      },
    },
    bg: {
      position: 'absolute',
      left: '-15%',
      top: '120px',
      width: '40vw',
      objectFit: 'cover',
      zIndex: '0'
    },
    infos: {
      width: '50%',
      padding: '20px',
      [theme.breakpoints.down('xs')]: {
        width: '100%',
        padding: '10px',
      },

      '&>h6': {
        letterSpacing: '3px',
        color: '#29a9e1',
        fontWeight: 'bold',
        margin: '0 0 5px',
      },
      '&>h2': {
        fontWeight: 'bold',
        fontSize: '25px',
        margin: '0 0 20px',
      },
      '&>p': {
        fontSize: '15px',
        lineHeigth: '1.6',
      },
      '& ul': {
        margin: 0,
      },
      '& li': {
        padding: '5px 0',
        fontSize: '15px',
      }

    },
    secInfos: {
      textAlign: 'center',
      margin: 'auto',
      fontSize: '18px',
      fontWeight: '500',
      color: '#555',
      [theme.breakpoints.down('xs')]: {
        fontSize: '15px',
      },
    },
    accessContainer: {
      width: '45%',
    },
    access: {
      width: '100%',
      padding: '20px',
      marginBottom: '20px',
    },
    horairContainer: {
      width: '80%',
      margin: '0 auto',
      [theme.breakpoints.down('xs')]: {
        width: '100%',
      },
    },
    horair: {
      listStyleType: 'circle',
      margin: '10px 0 20px',
      display: 'flex',
      justifyContent: 'space-between',
      [theme.breakpoints.down('xs')]: {
        flexWrap: 'wrap',
        justifyContent: 'center',
      },
      '& > li': {
        display: 'block',
        margin: '10px',
        fontSize: '15px',
        padding: '15px',
        [theme.breakpoints.down('xs')]: {
          width: '40%',
        },
        '& > strong': {
          textAlign: 'left',
          display: 'block',
          marginBottom: '10px',
        },
        '& > span': {
          textAlign: 'left',
          display: 'flex',
          justifyContent: 'flex-end',
          alignItems: 'center',
          fontSize: '14px',
          [theme.breakpoints.down('xs')]: {
            fontSize: '10px',
          },
          '& > svg': {
            marginRight: '5px',
            marginTop: '-2px',
            fontSize: '16px',
            [theme.breakpoints.down('xs')]: {
              fontSize: '12px',
            },
          },
        }
      },
    },
    consultationTypesContainer: {
      width: '80%',
      margin: '40px auto 10px',
      height: '80px',
      [theme.breakpoints.down('xs')]: {
        width: '100%',
      },
    },
    consultationTypes: {
      display: 'flex',
      alignItems: 'center',
    },
    consultationTypesGroup: {
      display: 'flex',
      alignItems: 'center',
    },
    consultationType: {
      margin: '0 10px',
      display: 'flex',
      alignItems: 'center',
    },
    consultationTypeColor: {
      display: 'block',
      width: '20px',
      height: '20px',
      borderRadius: '50%',
      marginRight: '10px',
    },
    consultationTypeName: {
      fontSize: '14px',
      fontWeight: 'bold',
    },

    typesContainer: {
      width: '80%',
      margin: '80px auto 40px',
      '&>h6': {
        letterSpacing: '3px',
        color: '#29a9e1',
        fontWeight: 'bold',
        margin: '0 auto 5px',
        textAlign: 'center',
      },
      '&>h2': {
        fontWeight: 'bold',
        fontSize: '25px',
        margin: '0 auto 40px',
        textAlign: 'center',
      },
    },
    types: {
      display: 'flex',
      justifyContent: 'space-evenly',
      alignItems: 'flex-start',
      [theme.breakpoints.down('xs')]: {
        flexWrap: 'wrap',
        justifyContent: 'center',
      },
    },
    type: {
      width: '28%',
      [theme.breakpoints.down('xs')]: {
        width: '100%',
      },
      '&>strong': {
        display: 'block',
        textAlign: 'left',
        marginBottom: '15px'
      },
      '&>p': {
        color: '#444',
        fontSize: '14px',
        lineHeigth: '1.4',
      }
    }
  }));