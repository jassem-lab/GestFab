import React, { memo, Fragment, useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { ViewState } from '@devexpress/dx-react-scheduler';
import {
  Scheduler,
  WeekView,
  Toolbar,
  DateNavigator,
  ViewSwitcher,
  TodayButton,
} from '@devexpress/dx-react-scheduler-material-ui';
import { Button, Dialog, DialogActions, DialogContent, DialogTitle } from "@material-ui/core";
import moment from "moment";
import { createAppointment } from "../../../actions/appointments";
import useStyles from "./style";
import { useHistory } from "react-router";

const DEFAULT_DURATION = 30;
let myState = {};

 // PRESERVATION OF VIEW

 const WeekTimeTableCell = ({ ...restProps }) => {
  const { startDate } = restProps;
 
  const cellData = myState?.resas?.filter(resa => resa.start === moment(startDate).format('YYYY-MM-DDTHH:mm'));
  let result = [];
  if (cellData && cellData.length > 0) {
    cellData.forEach(cell => { 
        result.push({
          color: cell.color,
          type: cell.type,
          doctor: myState.doctors?.find(doctor => doctor?.agendas?.includes(cell.agenda)),
          start: cell.start,
          id: cell._id
        });
    }) 
  }
  
  const elementHeight = 100 / result.length;
  
  if (result && result.length > 0) {
    return (<WeekView.TimeTableCell {...restProps}
                className={myState.classes.cellule}
                style={{ 
                  height: `240px`,
                }} >
                  <span style={{ display: 'flex', flexDirection: 'column', height: '100%', width: '100%' }}>
                    {
                      result?.map((item, itemIndex) => 
                        <span key={`${itemIndex}-${item.type}-${startDate}`}
                            className={myState.classes.celluleItem}
                            style={{
                              position: 'relative',
                              backgroundColor: `${item.color}`,
                              height:`${elementHeight}%`,
                              width: '100%',
                              // width: `${elementWidth}%`,
                            }}
                            onClick={() => {
                              myState.handleSetFormData({
                                    ...myState.formData,
                                    createdBy: myState.user?._id,
                                    patient: myState.patient?._id,
                                    type: item.type,
                                    start: new Date(startDate),
                                    duration: DEFAULT_DURATION,
                                    doctor: item.doctor?._id,
                                    notes: 'Prise par internet. Patient: ' + myState.user?.name,
                                    celluleId: item.id,
                              });
                              myState.showRdvsForm();
                            }}>
                        </span>
                      )
                    }
                  </span>
        </WeekView.TimeTableCell>)
  } else {
    return <WeekView.TimeTableCell {...restProps} 
                  style={{ 
                    backgroundColor: "#eee", 
                    height: `240px` 
                  }} />
  }           
};

// TIME LABEL HEIGHT CHANGING

const WeekViewTimeScaleLabel = ({style, data, ...restProps}) => {
  return (<WeekView.TimeScaleLabel {...restProps} 
    style={{ ...style, height: `240px`, lineHeight: '1rem' }} />)
};


function Calendar(props) {
    const { doctors, filterData, patient, user } = props;
    const classes = useStyles();
    const dispatch = useDispatch();
    const { resas } = useSelector(state => state.resas);
    const [currentDate, setCurrentDate] = useState(localStorage.getItem('currentDate') ? localStorage.getItem('currentDate') : moment().format('YYYY-MM-DD'));
    const [currentViewName, setCurrentViewName] = useState('Week');
    const [rdvsForm, setRdvsForm] = useState(false);
    const [feedback, setFeedback] = useState(false);
    const history = useHistory();

    // DATA FORM
    const [formData, setFormData] = useState({
        createdBy: user?._id,
        doctor: null,
        patient: null,
        start: null,
        duration: 0,
        type: '',
        motif: '',
        notes: 'Prise par internet. Patient: ' + user?.name,
        status: 'Attente',
        celluleId: null,
    });

    const handelConfirmation = () => {
        if (!patient) {
            setFeedback("Vous etes pas un patient ou vous etes pas connecté");
            return;
        }

        dispatch(createAppointment(formData)).then(() => {
            setRdvsForm(false);
            history.push('/c/list-rdv');
        })
    };

     // SET RESAS TO MY STATE
     useEffect(() => {
        if (resas && resas.length > 0) {
            myState.resas = resas
        }
    }, [resas])


    if (!user || !doctors || !filterData || !resas ) return null

    myState.classes = classes;
    myState.formData = formData;
    myState.user = user;
    myState.patient = patient;
    myState.doctors = doctors;
    myState.filterData = filterData;
    myState.showRdvsForm = () => setRdvsForm(true);
    myState.handleSetFormData = (data) => setFormData(data);

    return (
        <>
        <Scheduler
            locale="fr-FR"
            height={550}
            >
            <ViewState
                currentDate={currentDate}
                currentViewName={currentViewName}
                onCurrentViewNameChange={(newItem) => setCurrentViewName(newItem)}
                onCurrentDateChange={(newItem) => {
                                                    setCurrentDate(newItem)
                                                    localStorage.setItem('currentDate', newItem)
                                                }}
            />
            <WeekView
                cellDuration={30}
                startDayHour={7}
                endDayHour={21}
                excludedDays={[0, 6]}
                timeScaleLabelComponent={WeekViewTimeScaleLabel}
                timeTableCellComponent={WeekTimeTableCell}
            />
            <Toolbar />
            <DateNavigator />
            <TodayButton />
            <ViewSwitcher />
        </Scheduler>
        <Dialog
                open={rdvsForm}
                onClose={() => setRdvsForm(false)}
                aria-labelledby="action-title"
                aria-describedby="action-description"
            >
                <DialogTitle id="action-title">{"confirmer le rendez-vous ?"}</DialogTitle>
                <DialogContent>
                        <div className={classes.actionBlock}>
                        <label className={classes.actionLabel}>Rendez-vous :</label>
                        <ul className={classes.confirmUl}>
                            <li>Date et heure: {moment(formData.start).format('DD/MM/YYYY HH:mm')}</li>
                            <li>Durée: {formData.duration}</li>
                            <li>Médecin: {doctors?.find(doc => doc._id === formData.doctor)?.user?.name}</li>
                            <li>Type: {formData.type}</li>
                        </ul>
                        <div className={classes.confirmFeedback}>{
                            feedback ? feedback : null
                        }</div>
                        </div>
                </DialogContent>
                <DialogActions>
                <Button onClick={() => setRdvsForm(false)} color="primary">
                    Annuler
                </Button>
                <Button onClick={handelConfirmation} style={{ cursor: 'pointer' }} color="primary" autoFocus>
                    Confirmer
                </Button>
                </DialogActions>
            </Dialog>
        </>
    )
}

export default memo(Calendar);
