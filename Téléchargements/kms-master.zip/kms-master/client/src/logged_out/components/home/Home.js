import React, { memo, Fragment, useEffect, useState } from "react";
import PropTypes from "prop-types";
import HeadSection from "./HeadSection";
import classNames from "classnames";
import AccessTimeIcon from '@material-ui/icons/AccessTime';
import useStyles from "./style";
import Calendar from "./Calendar";
import { useDispatch, useSelector } from "react-redux";
import { getPatient } from "../../../actions/patients";
import { getResasByDoctorId, getResasByEtablissementId } from "../../../actions/resas";

function Home(props) {
  const { selectHome, etablissements, doctors, agendas } = props;
  const classes = useStyles();
  const dispatch = useDispatch();
  const user = localStorage.getItem('profile') ? JSON.parse(localStorage.getItem('profile'))?.user : null;
  const { patient } = useSelector(state => state.patients);
  const [typesByEtab, setTypesByEtab] = useState([]);
  const { ResasIsLoading } = useSelector(state => state.resas);
  const [filterData, setFilterData] = useState({
    doctor: null,
    etablissement: null,
  });

  // GET RESAS BY DOCTOR
  useEffect(() => {
      if (filterData && filterData.doctor?._id) {
          dispatch(getResasByDoctorId(filterData.doctor?._id));
      } else if (filterData && filterData.etablissement?._id) {
          dispatch(getResasByEtablissementId(filterData.etablissement?._id));
      }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [filterData?.doctor?._id, filterData?.etablissement?._id]);

  // SELECT TAB
  useEffect(() => {
    selectHome();
  }, [selectHome]);

   // GET PATIENT
   useEffect(() => {
    if (user?._id && user?.role === 'patient') {
        dispatch(getPatient(user?._id));
    }
  }, [dispatch, user?._id, user?.role]);

  // get types by agendas
  useEffect(() => {
    if (agendas?.length > 0 && doctors?.length > 0) {
        var types = [];
        // eslint-disable-next-line array-callback-return
        agendas?.filter(ag => ag !== undefined)?.map(agenda => {
            if (agenda?.template?.table) {
                // eslint-disable-next-line array-callback-return
                agenda?.template?.table?.map(consultation => {
                    if (types?.filter(cs => cs.type?.toLowerCase()?.trim() === consultation.type?.toLowerCase()?.trim())?.length === 0 ) {
                      if (consultation.type === 'Cabine' || consultation.type === 'Salle') {
                        types?.push({
                          type: consultation.type,
                          color: consultation.color,
                          doctor: doctors?.find(doc => doc.agendas.includes(agenda._id))?.user?.name,
                          doctorId: doctors?.find(doc => doc.agendas.includes(agenda._id))?._id,
                        })
                      }
                    }
                })
            } else {
                // eslint-disable-next-line array-callback-return
                agenda?.consultationsTypes?.map(consultation => {
                    if (types?.filter(cs => cs.type?.toLowerCase()?.trim() === consultation?.toLowerCase()?.trim())?.length === 0 ) {
                        types?.push({
                            type: consultation,
                        })
                    }
                })
            }
          })
        
        setTypesByEtab(types);
      }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [agendas, doctors]);
 
  return (
    <Fragment>
      <HeadSection etablissements={etablissements} doctors={doctors} handelSetFilterData={(data) => setFilterData(data)} />
      <div className="home-container">
        <div className="home-content">
          <div className={classes.consultationTypesContainer}>
              {
                filterData?.doctor?._id || filterData?.etablissement?._id ? (
                  <>
                    <div className={classes.consultationTypes}>
                      {
                      typesByEtab?.map(row =>
                          <div key={`${row.type}-${row.color}`} className={classes.consultationType}>
                            <span className={classes.consultationTypeColor} style={{ backgroundColor: `${row.color}` }}></span>
                            <span className={classes.consultationTypeName}>{row.type}</span>
                          </div>
                        )
                      }
                    </div>
                    <p>Le patient doit passer obligatoirement par le secrétariats dans les cas suivants : * Demande de visite à domicile * Nouveau patient (e) * Urgence.</p>
                  </>
                ) : null
              }
          </div>
          {
            user ? (
              <div className={classes.calendarContainer}>
                <div className="calendar-content">
                  {
                    filterData?.doctor?._id || filterData?.etablissement?._id ? (
                      <div className={classNames.calendar}>
                        {
                          ResasIsLoading ? (
                            <div className={classes.loadingContainer}>
                              <img className={classes.loading} src="/images/loading-36.gif" alt="loading" />
                            </div>
                          ) : (
                            <Calendar user={user} patient={patient} doctors={doctors} typesByEtab={typesByEtab} filterData={filterData} />
                          )
                        }
                      </div>
                    ) : (
                      <h3>Veuillez vous sélectionner une établissement ou un médecin</h3>
                    )
                  }
                </div>
              </div>
            ) : (
              <div className={classes.calendarContainer}>
                {
                  filterData?.doctor?._id || filterData?.etablissement?._id ? (
                    <h3>Veuillez vous connecter pour accéder aux calendriers</h3>
                  ) : (
                    <h3>Veuillez vous connecter pour accéder aux calendriers</h3>
                  )
                }
              </div>
            )
          }
          <div className={classes.horairContainer}>
            <ul className={classes.horair}>
              <li>
                <strong>Lundi: </strong>
                <span><AccessTimeIcon /> 08:00 - 12:00</span>
                <span><AccessTimeIcon /> 13:00 - 19:30</span>
              </li>
              <li>
                <strong>Mardi: </strong>
                <span><AccessTimeIcon /> 08:00 - 12:00</span>
                <span><AccessTimeIcon /> 13:00 - 19:30</span>
              </li>
              <li>
                <strong>Mercredi: </strong>
                <span><AccessTimeIcon /> 08:00 - 12:00</span>
                <span><AccessTimeIcon /> 13:00 - 19:30</span>
              </li>
              <li>
                <strong>Jeudi: </strong>
                <span><AccessTimeIcon /> 08:00 - 12:00</span>
                <span><AccessTimeIcon /> 13:00 - 19:30</span>
              </li>
              <li>
                <strong>Vendredi: </strong>
                <span><AccessTimeIcon /> 08:00 - 12:00</span>
                <span><AccessTimeIcon /> 13:00 - 19:30</span>
              </li>
            </ul>
            <p className={classes.secInfos}>Pour le mois de Janvier et Février, le Secrétariat est ouvert du lundi au vendredi, de 8h à 12h30, et de 13h30 à 19h30</p>
          </div>
        </div>
        <div className={classes.infosContainer}>
            <div className={classes.infos}>
                <h6>KINEDOC</h6>
                <h2>A propos de nous</h2>
                <p>Le cabinet de Kinésithérapie, SELARL PHIMABCD - Philippe HOLLNER se situe à Chef Boutonne, (commune dynamique des Deux - Sèvres) à une heure de La Rochelle et 45 min de Niort et Poitiers dans un cadre neuf et agréable, doté d 'une infrastructure et matériels performants et récents. Je consulte sur le plan orthopédique, neurologique et respiratoire.</p>
                <h4>Formations</h4>
                <ul>
                  <li>Ecole "Physiotherapie Schule Ortenau" (Bade Würtemberg) : cursus complet en thérapie manuelle et Bobath (en 2008)</li>
                  <li>Kinésio Taping (Expert)</li>
                  <li>Drainage Lymphatique manuel</li>
                  <li>Massage de bien-être</li>              
                </ul>
                <h4>Expériences professionnelles depuis 2009 :</h4>
                <ul>
                  <li>Exercice en milieu carcéral</li>
                  <li>Exercice en milieu hospitalier (service oncologie et soins palliatifs)</li>
                  <li>Exercice en résidence autonomie et EHPAD.</li>
                </ul>   
                <p>Il est impératif de présenter sa carte vitale et la prescription médicale lors du premier rendez vous au cabinet. Le patient doit être en possession de sa carte vitale et d'un moyen de paiement à chaque rendez - vous.</p>
            </div>
            <div className={classes.accessContainer}>
                <div className={classes.access}> 
                  <img src="/images/logged_out/bigicon.png" alt="Icon" style={{ width: '100%', display: 'block' }} />
                </div>
            </div>
            <img src='/images/logged_out/bg.png' alt="bg" className={classes.bg} />
          </div>
          <div className={classes.typesContainer}>
            <h6>KINEDOC</h6>
            <h2>Pour des rendez-vous de type</h2>
            <div className={classes.types}>
              <div className={classes.type}>
                  <strong>Orthopédie</strong>
                  <p>je vous remercie de vous munir lors de la première consultation de vos derniers clichés de type : échographie, radios, scanner, IRM et ou Arthro-scanner et comptes-rendus médicaux.</p>
              </div>
              <div className={classes.type}>
                  <strong>Neurologie</strong>
                  <p>derniers examens médicaux(EMG, prise de sang, scanner et ou IRM et comptes rendus médicaux).</p>
              </div>
              <div className={classes.type}>
                  <strong>Respiratoires</strong>
                  <p>dernier prélèvement sanguin, EFR et ou résultats divers.</p>
              </div>
            </div>
          </div>
      </div>
      
    </Fragment>
  );
}

Home.propTypes = {
  selectHome: PropTypes.func.isRequired
};

export default memo(Home);
