import React, { memo, Fragment, useEffect } from "react";
import PropTypes from "prop-types";
import classNames from "classnames";
import {
  Button,
  FormControl,
  makeStyles,
  TextField,
} from "@material-ui/core";
import Autocomplete from "@material-ui/lab/Autocomplete";
import { useSelector } from "react-redux";

const useStyles = makeStyles(theme => ({
  extraLargeButtonLabel: {
    fontSize: theme.typography.body1.fontSize,
    [theme.breakpoints.up("sm")]: {
      fontSize: theme.typography.h6.fontSize,
    },
  },
  extraLargeButton: {
    paddingTop: theme.spacing(1.5),
    paddingBottom: theme.spacing(1.5),
    [theme.breakpoints.up("xs")]: {
      paddingTop: theme.spacing(1),
      paddingBottom: theme.spacing(1),
    },
    [theme.breakpoints.up("lg")]: {
      paddingTop: theme.spacing(2),
      paddingBottom: theme.spacing(2),
    },
  },
  card: {
    boxShadow: theme.shadows[4],
    marginLeft: theme.spacing(2),
    marginRight: theme.spacing(2),
    [theme.breakpoints.up("xs")]: {
      paddingTop: theme.spacing(3),
      paddingBottom: theme.spacing(3),
    },
    [theme.breakpoints.up("sm")]: {
      paddingTop: theme.spacing(5),
      paddingBottom: theme.spacing(5),
      paddingLeft: theme.spacing(4),
      paddingRight: theme.spacing(4),
    },
    [theme.breakpoints.up("md")]: {
      paddingTop: theme.spacing(5.5),
      paddingBottom: theme.spacing(5.5),
      paddingLeft: theme.spacing(5),
      paddingRight: theme.spacing(5),
    },
    [theme.breakpoints.up("lg")]: {
      paddingTop: theme.spacing(6),
      paddingBottom: theme.spacing(6),
      paddingLeft: theme.spacing(6),
      paddingRight: theme.spacing(6),
    },
    [theme.breakpoints.down("lg")]: {
      width: "auto",
    },
  },
  wrapper: {
    position: "relative",
    backgroundColor: theme.palette.secondary.main,
    paddingBottom: theme.spacing(2),
    minHeight: '100vh',
  },
  introBG: {
    position: 'absolute',
    width: '100%',
    height: '100%',
    top: 0,
    left: 0,
    objectFit: 'cover',
  },
  image: {
    maxWidth: "100%",
    verticalAlign: "middle",
    borderRadius: theme.shape.borderRadius,
    boxShadow: theme.shadows[4],
  },
  container: {
    marginTop: theme.spacing(6),
    marginBottom: theme.spacing(12),
    [theme.breakpoints.down("md")]: {
      marginBottom: theme.spacing(9),
    },
    [theme.breakpoints.down("sm")]: {
      marginBottom: theme.spacing(6),
    },
    [theme.breakpoints.down("sm")]: {
      marginBottom: theme.spacing(3),
    },
  },
  containerFix: {
    [theme.breakpoints.up("md")]: {
      maxWidth: "none !important",
    },
  },
  waveBorder: {
    paddingTop: theme.spacing(4),
  },
  overlay: {
    position: "absolute",
    top: 0,
    left: 0,
    width: "100%",
    height: "100%",
    backgroundColor: "rgba(0,0,0,0.3)",
    zIndex: 1,
  },
  overlayContent: {
    position: 'relative',
    width: '80%',
    height: '100%',
    margin: 'auto',
    padding: '200px 0 40px',
    textAlign: 'left',
    color: '#fff',
    [theme.breakpoints.down("sm")]: {
      width: '100%',
      padding: '150px 20px 40px',
    },
  },
  title: {
    fontSize: '2.5rem',
    maxWidth: '70%',
    lineHeight: '1.4',
    textAlign: 'center',
    textTransform: 'uppercase',
    margin: '0 auto 60px',
    [theme.breakpoints.down("sm")]: {
      fontSize: '1.5rem',
      maxWidth: '90%',
    },
  },
  subitle: {
    fontSize: '15px',
    maxWidth: '70%',
    lineHeight: '1.6',
    textAlign: 'center',
    fontWeight: 'bold',
    textTransform: 'uppercase',
    letterSpacing: '3px',
    margin: '0 auto 10px',
    color: '#CCC',
    [theme.breakpoints.down("sm")]: {
      fontSize: '1rem',
      maxWidth: '90%',
    },
  },
  filter: {
    width: '70%',
    margin: '0 auto',
    padding: '20px',
    borderRadius: '2px',
    backgroundColor: 'rgba(255,255,255,0.6)',
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    [theme.breakpoints.down("sm")]: {
      width: '100%',
      padding: '10px',
    },
  },
  filterContent: {
    width: '100%',
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    flexWrap: 'wrap',
  },
  filterItem: {
    width: '30%',
    margin: '0 5px',
    [theme.breakpoints.down("sm")]: {
      width: '100%',
      margin: '0 0 20px',
    },
  },
  filterBtn: {
    width: '100%',
    height: '56px',
    lineHeight: '55px',
    padding: '0',
    borderRadius: '0px',
    backgroundColor: '#29a9e1',
    color: "#EEE",
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    '&:hover' : {
      backgroundColor: "#106b93",
    }
  },
  formControl: {
    width: "100%",
  },
  loadingContainer: {
    display: 'flex',
    height: '100%',
    alignItems: 'center',
    justifyContent: 'center',
  },
  loading: {
    width: '80px',
  },
  myicon: {
    position: 'absolute',
    width: '30px',
    top: 'calc(100% - 25px)',
    left: '48%',

  }
}));

function HeadSection(props) {
  const classes = useStyles();
  const { etablissements, doctors } = props;
  const [filtredDoctors, setFiltredDoctors] = React.useState([]);
  const { EtablissementIsLoading } = useSelector(state => state.etablissements);
  const { DoctorsIsLoading } = useSelector(state => state.doctors);
  const [filterData, setFilterData] = React.useState({
    etablissement: '',
    doctor: '',
  });

useEffect(() => {
  setFiltredDoctors(doctors);
}, [doctors])

/* useEffect(() => {
  if (filterData) {
    props.handelSetFilterData(filterData);
  }
}, [filterData, props]) */

  return (
    <Fragment>
      <div className={classNames("lg-p-top", classes.wrapper)}>
        <div className={classNames("container-fluid", classes.container)}>
          <img className={classes.introBG} src="/images/logged_out/intro-bg.jpg" alt="intro" />
          <div className={classes.overlay}>
            <div className={classes.overlayContent}>
              <p className={classes.subitle} >kinedoc</p>
              <h2 className={classes.title}>Prenez rapidement un <br /> rendez-vous avec votre médecin !</h2>
              {/* <p className={classes.subitle}>Sélectionnez votre médecin, choisissez la date et l'heure de votre rdv et recevez votre sms/mail de confirmation. C’est aussi simple que ça !</p> */}
              <div className={classes.filter}>
                {
                  EtablissementIsLoading || !etablissements || DoctorsIsLoading || !doctors ? (
                    <div className={classes.loadingContainer}>
                      <img className={classes.loading} src="/images/loading-36.gif" alt="loading" />
                    </div>
                  ) : (
                    <div className={classes.filterContent}>
                      <div className={classes.filterItem}>
                        <FormControl className={classes.formControl}>
                              <Autocomplete
                                  id="patient-simple-select"
                                  value={filterData.etablissement}
                                  onChange={(e, val) => {
                                      e.preventDefault();
                                      setFilterData({ ...filterData, etablissement: val })
                                      setFiltredDoctors(doctors.filter(doctor => doctor.etablissement._id === val._id))
                                  }}
                                  options={etablissements}
                                  getOptionLabel={(option) => option?.name || ''}
                                  style={{ width: "100%" }}
                                  renderInput={(params) => <TextField {...params} label="Etablissement" variant="outlined" />}
                              />
                          </FormControl>
                        </div>
                        <div className={classes.filterItem}>
                          <FormControl className={classes.formControl}>
                                <Autocomplete
                                    id="patient-simple-select"
                                    value={filterData.doctor}
                                    onChange={(e, val) => {
                                        e.preventDefault();
                                        setFilterData({ ...filterData, doctor: val })
                                    }}
                                    options={filtredDoctors}
                                    getOptionLabel={(option) => option?.user?.name || ''}
                                    style={{ width: "100%" }}
                                    renderInput={(params) => <TextField {...params} label="Médecin" variant="outlined" />}
                                />
                            </FormControl>
                        </div>
                        <div className={classes.filterItem} >
                          <Button className={classes.filterBtn}
                                  onClick={(e) => {
                                    e.preventDefault();
                                    props.handelSetFilterData(filterData)}
                                  }
                                  >
                              Rechercher
                          </Button>
                        </div>
                    </div>
                  )
                }
              </div>
              <img className={classes.myicon} src="/images/logged_out/myicon.png" alt="icon" />
            </div>
          </div>
        </div>
      </div>
    </Fragment>
  );
}

HeadSection.propTypes = {
  width: PropTypes.string,
  theme: PropTypes.object,
};

export default memo(HeadSection);

