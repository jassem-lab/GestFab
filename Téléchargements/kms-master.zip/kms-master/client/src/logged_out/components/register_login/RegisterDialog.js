import React, { useState, useCallback, useRef, Fragment } from "react";
import PropTypes from "prop-types";
import {
  FormHelperText,
  TextField,
  Button,
  withStyles,
} from "@material-ui/core";
import FormDialog from "../../../shared/components/FormDialog";
import ButtonCircularProgress from "../../../shared/components/ButtonCircularProgress";
import VisibilityPasswordTextField from "../../../shared/components/VisibilityPasswordTextField";
import { useDispatch, useSelector } from "react-redux";
import { signup } from "../../../actions/auth";
import { useHistory } from "react-router";
import "./style.css";
import InputLabel from "@material-ui/core/InputLabel";  
import MenuItem from "@material-ui/core/MenuItem";
import FormControl from "@material-ui/core/FormControl";
import Select from "@material-ui/core/Select";

const styles = (theme) => ({
  link: {
    transition: theme.transitions.create(["background-color"], {
      duration: theme.transitions.duration.complex,
      easing: theme.transitions.easing.easeInOut,
    }),
    cursor: "pointer",
    color: theme.palette.primary.main,
    "&:enabled:hover": {
      color: theme.palette.primary.dark,
    },
    "&:enabled:focus": {
      color: theme.palette.primary.dark,
    },
  },
});

function RegisterDialog(props) {
  const { setStatus, theme, onClose, status } = props;
  const history = useHistory();
  const [isPasswordVisible, setIsPasswordVisible] = useState(false);
  // const registerTermsCheckbox = useRef();
  const registerPassword = useRef();
  const registerPasswordRepeat = useRef();
  const registerLogin = useRef();
  const registerName = useRef();
  const registerPhone = useRef();
  const registerAdress = useRef();
  const registerCP = useRef();
  const registerCity = useRef();
  const gender = useRef();
  const dispatch = useDispatch();
  const { authLoading, authError } = useSelector((state) => state.auth);

  const register = useCallback(() => {
    if (!registerLogin.current.value || registerLogin.current.value === "") {
      setStatus("Set an Email");
      return;
    }
    /*  if (!registerTermsCheckbox.current.checked) {
      //setHasTermsOfServiceError(true);
      return;
    } */
    if (
      registerPassword.current.value !== registerPasswordRepeat.current.value
    ) {
      setStatus("passwordsDontMatch");
      return;
    }
    setStatus(null);
    dispatch(
      signup(
        {
          gender: gender.current.value,
          cp: registerCP.current.value,
          city: registerCity.current.value,
          adress: registerAdress.current.value,
          phone: registerPhone.current.value,
          email: registerLogin.current.value,
          password: registerPassword.current.value,
          name: registerName.current.value,
          role: "patient",
        },
        history
      )
    );
  }, [setStatus, dispatch, history]);

  return (
    <FormDialog
      loading={authLoading}
      onClose={onClose}
      open
      headline="S'enregistrer"
      onFormSubmit={(e) => {
        e.preventDefault();
        register();
      }}
      hideBackdrop
      hasCloseIcon
      content={
        <Fragment>
          <div className="row">
            <div className="col-md-3">
              <FormControl variant="outlined" fullWidth>
                <InputLabel id="demo-simple-select-outlined-label">
                  Genre
                </InputLabel>
                <Select
                  labelId="demo-simple-select-outlined-label"
                  id="demo-simple-select-outlined"
                  label="Genre"
                  ref={gender}
                >
                  <MenuItem value="">
                    <em>None</em>
                  </MenuItem>
                  <MenuItem value="M">M</MenuItem>
                  <MenuItem value="Mme">Mme</MenuItem>
                  <MenuItem value="Enf">Docteur</MenuItem>
                  <MenuItem value="Enf">Laboratoire</MenuItem>
                  <MenuItem value="Enf">Perso</MenuItem>
                  <MenuItem value="Enf">Enfant</MenuItem>
                </Select>
              </FormControl>
            </div>
            <div className="col-md-9">
              <TextField
                variant="outlined"
                required
                fullWidth
                inputRef={registerName}
                label="Nom et prénom"
                autoFocus
                autoComplete="off"
                type="text"
              />
            </div>
          </div>
          <div className="row">
            <div className="col-md-6">
              <TextField
                variant="outlined"
                margin="normal"
                required
                fullWidth
                inputRef={registerPhone}
                error={status === "invalidPhone"}
                label="Téléphone"
                autoFocus
                autoComplete="off"
                type="tel"
                onChange={() => {
                  if (status === "invalidPhone") {
                    setStatus(null);
                  }
                }}
                FormHelperTextProps={{ error: true }}
              />
            </div>
            <div className="col-md-6">
              <TextField
                variant="outlined"
                margin="normal"
                required
                fullWidth
                inputRef={registerLogin}
                error={status === "invalidEmail"}
                label="Email"
                autoFocus
                autoComplete="off"
                type="email"
                onChange={() => {
                  if (status === "invalidEmail") {
                    setStatus(null);
                  }
                }}
                FormHelperTextProps={{ error: true }}
              />
            </div>
          </div>
          <div className="row">
            <div className="col-md-12">
              <TextField
                variant="outlined"
                fullWidth
                inputRef={registerAdress}
                label="Adresse"
                autoFocus
                autoComplete="off"
                type="text"
              />
            </div>
          </div>
          <div className="row">
            <div className="col-md-6">
              <TextField
                variant="outlined"
                fullWidth
                inputRef={registerCP}
                label="Code postal"
                autoFocus
                autoComplete="off"
                type="text"
              />
            </div>
            <div className="col-md-6">
              <TextField
                variant="outlined"
                fullWidth
                inputRef={registerCity}
                label="Ville"
                autoFocus
                autoComplete="off"
                type="text"
              />
            </div>
          </div>
          <div className="row">
            <div className="col-md-6">
              <VisibilityPasswordTextField
                variant="outlined"
                margin="normal"
                required
                fullWidth
                error={
                  status === "passwordTooShort" ||
                  status === "passwordsDontMatch"
                }
                label="Mot de passe"
                inputRef={registerPassword}
                autoComplete="off"
                onChange={() => {
                  if (
                    status === "passwordTooShort" ||
                    status === "passwordsDontMatch"
                  ) {
                    setStatus(null);
                  }
                }}
                helperText={(() => {
                  if (status === "passwordTooShort") {
                    return "Create a password at least 6 characters long.";
                  }
                  if (status === "passwordsDontMatch") {
                    return "Your passwords dont match.";
                  }
                  return null;
                })()}
                FormHelperTextProps={{ error: true }}
                isVisible={isPasswordVisible}
                onVisibilityChange={setIsPasswordVisible}
              />
            </div>
            <div className="col-md-6">
              <VisibilityPasswordTextField
                variant="outlined"
                margin="normal"
                required
                fullWidth
                error={
                  status === "passwordTooShort" ||
                  status === "passwordsDontMatch"
                }
                label="Répéter le mot de passe"
                inputRef={registerPasswordRepeat}
                autoComplete="off"
                onChange={() => {
                  if (
                    status === "passwordTooShort" ||
                    status === "passwordsDontMatch"
                  ) {
                    setStatus(null);
                  }
                }}
                helperText={(() => {
                  if (status === "passwordTooShort") {
                    return "Le mot de passe est trés court.";
                  }
                  if (status === "passwordsDontMatch") {
                    return "Your passwords dont match.";
                  }
                })()}
                FormHelperTextProps={{ error: true }}
                isVisible={isPasswordVisible}
                onVisibilityChange={setIsPasswordVisible}
              />
            </div>
          </div>
          {/* <FormControlLabel
            style={{ marginRight: 0 }}
            control={
              <Checkbox
                color="primary"
                inputRef={registerTermsCheckbox}
                onChange={() => {
                  setHasTermsOfServiceError(false);
                }}
              />
            }
            label={
              <Typography variant="body1">
                I agree to the
                <span
                  className={classes.link}
                  onClick={authLoading ? null : openTermsDialog}
                  tabIndex={0}
                  role="button"
                  onKeyDown={(event) => {
                    // For screenreaders listen to space and enter events
                    if (
                      (!authLoading && event.keyCode === 13) ||
                      event.keyCode === 32
                    ) {
                      openTermsDialog();
                    }
                  }}
                >
                  {" "}
                  terms of service
                </span>
              </Typography>
            }
          /> */}
          {authError ? (
            <FormHelperText
              error
              style={{
                display: "block",
                marginTop: theme.spacing(-1),
              }}
            >
              {authError}
            </FormHelperText>
          ) : null}
        </Fragment>
      }
      actions={
        <Button
          type="submit"
          fullWidth
          variant="contained"
          size="large"
          color="secondary"
          disabled={authLoading}
        >
          Register
          {authLoading && <ButtonCircularProgress />}
        </Button>
      }
    />
  );
}

RegisterDialog.propTypes = {
  theme: PropTypes.object.isRequired,
  onClose: PropTypes.func.isRequired,
  openTermsDialog: PropTypes.func.isRequired,
  status: PropTypes.string,
  setStatus: PropTypes.func.isRequired,
  classes: PropTypes.object.isRequired,
};

export default withStyles(styles, { withTheme: true })(RegisterDialog);
