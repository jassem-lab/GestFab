import { configureStore, applyMiddleware, createStore } from "@reduxjs/toolkit";
import auth from "./reducers/auth";
import usersReducers from "./reducers/users";
import postsReducers from "./reducers/posts";
import chatsReducers from "./reducers/chats";
import doctorsReducers from "./reducers/doctors";
import agendasReducers from "./reducers/agendas";
import etablissementsReducers from "./reducers/etablissements";
import patientsReducers from "./reducers/patients";
import appointmentsReducers from "./reducers/appointments";
import settingsReducers from "./reducers/settings";
import resasReducers from "./reducers/resas";
import eventsReducers from "./reducers/events";
import smsReducers from "./reducers/sms";
import thunk from "redux-thunk";

import { chatReducer } from "./reducers/chats";

export const store = configureStore(
  {
    reducer: {
    
      auth: auth,
      chat: chatReducer,
      users: usersReducers,
      posts: postsReducers,
      chats: chatsReducers,
      doctors: doctorsReducers,
      etablissements: etablissementsReducers,
      agendas: agendasReducers,
      patients: patientsReducers,
      appointments: appointmentsReducers,
      resas: resasReducers,
      settings: settingsReducers,
      events: eventsReducers,
      sms: smsReducers,
    },
  },
  applyMiddleware(thunk)
);
