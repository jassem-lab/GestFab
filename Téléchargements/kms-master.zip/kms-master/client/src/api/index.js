import axios from "axios";
import { useEffect } from "react";
// export const API = axios.create({ baseURL: "http://localhost:5000" });
//const API = axios.create({ baseURL: 'http://164.92.243.232' })
export const API = axios.create({ baseURL: "https://kinedocrdv.fr" });

API.interceptors.request.use((req) => {
  if (localStorage.getItem("profile")) {
    req.headers.Authorization = `Bearer ${
      JSON.parse(localStorage.getItem("profile")).token
    }`;
  }
  return req;
});

export const signUp = (formData) => API.post("/api/auth/signup", formData);
export const signIn = (formData) => API.post("/api/auth/signin", formData);

export const fetchDoctor = (id) => API.get(`/api/doctors/fetchDoctor/${id}`);
export const fetchDoctorByUser = (id) =>
  API.get(`/api/doctors/fetchDoctorByUser/${id}`);
export const fetchDoctorsByEtab = (id) =>
  API.get(`/api/doctors/fetchDoctorsByEtab/${id}`);
export const fetchDoctors = () => API.get("/api/doctors/fetchDoctors");
export const createDoctor = (newDoctor) =>
  API.post("/api/doctors/createDoctor", newDoctor);
export const editDoctor = (id, updatedDoctor) =>
  API.patch(`/api/doctors/${id}`, updatedDoctor);
export const deleteDoctor = (id) => API.delete(`/api/doctors/${id}`);

export const fetchPatient = (id) => API.get(`/api/patients/fetchPatient/${id}`);
export const fetchPatients = () => API.get("/api/patients/fetchPatients");
export const filterPatients = (filters) =>
  API.post("/api/patients/filterPatients", filters);
export const fetchChatsByPatient = () =>
  API.post("/api/patients/getChatsByPatient");
export const fetchPatientsByEtab = (etabId) =>
  API.get(`/api/patients/fetchPatientsByEtab/${etabId}`);
export const createPatient = (newPatient) =>
  API.post("/api/patients/createPatient", newPatient);
export const editPatient = (id, updatedPatient) =>
  API.patch(`/api/patients/${id}`, updatedPatient);
export const deletePatient = (id) => API.delete(`/api/patients/${id}`);
export const blockPatient = (id, blacklist) =>
  API.post(`/api/patients/blockPatient/${id}`, { blacklist: blacklist });
export const seedPatients = () => API.get("/api/patients/seedPatients");
export const getAllPatientsChat = () => API.get("/api/patients/gettChat");

export const fetchEtablissement = (id) =>
  API.get(`/api/etablissements/fetchEtablissements/${id}`);
export const fetchEtablissements = () =>
  API.get("/api/etablissements/fetchEtablissements");
export const createEtablissement = (newEtablissement) =>
  API.post("/api/etablissements/createEtablissement", newEtablissement);
export const editEtablissement = (id, updatedEtablissement) =>
  API.patch(`/api/etablissements/${id}`, updatedEtablissement);
export const deleteEtablissement = (id) =>
  API.delete(`/api/etablissements/${id}`);

export const fetchAgenda = (id) => API.get(`/api/agendas/fetchAgendas/${id}`);
export const fetchAgendas = () => API.get("/api/agendas/fetchAgendas");
export const fetchAgendasByIds = (ids) =>
  API.post("/api/agendas/fetchAgendasByIds", { ids: ids });
export const createAgenda = (newAgenda) =>
  API.post("/api/agendas/createAgenda", newAgenda);
export const editAgenda = (id, updatedAgenda) =>
  API.patch(`/api/agendas/${id}`, updatedAgenda);
export const deleteAgenda = (id) => API.delete(`/api/agendas/${id}`);
export const createTemplate = (id, newTemplate) =>
  API.post(`/api/agendas/createTemplate/${id}`, newTemplate);
export const updateTemplate = (id, updatedTemplate) =>
  API.post(`/api/agendas/updateTemplate/${id}`, updatedTemplate);
export const getDoctorDuration = (id) =>
  API.get(`/api/agendas/getDoctorDuration/${id}`);

export const getUser = (id) => API.get(`/api/users/fetchUser/${id}`);
export const ListUsers = () => API.get(`/api/users/listUsers/`);
export const listAdmins = () => API.get(`/api/users/listAdmins/`);
export const AddUser = (newUser) => API.post(`/api/users/addUser/`, newUser);
export const EditUser = (id, newUser) =>
  API.post(`/api/users/editUser/${id}`, newUser);
export const DeleteUser = (id) => API.delete(`/api/users/${id}`);

export const fetchChat = (id) => API.get(`/api/chats/fetchChat/${id}`);
export const fetchUnseenMessages = () =>
  API.get("/api/chats/fetchUnseenMessage");
export const fetchChats = () => API.get("/api/chats/fetchChats");

export const fetchChatsByDoctors = (doctors) =>
  API.post("/api/chats/fetchChatsByDoctors", doctors);
export const createChat = (newChat) =>
  API.post("/api/chats/createChat", newChat);
export const editChat = (id, updatedChat) =>
  API.patch(`/api/chats/editChat/${id}`, updatedChat);
export const deleteChat = (id) => API.delete(`/api/chats/${id}`);
export const messageSeen = (id) => API.post(`/api/chats/seenChats/${id}`);
export const messageSeenByPatient = (id) =>
  API.post(`/api/chats/seenChatsByPatient/${id}`);
export const fetchChatByPatient = (id) =>
  API.post(`/api/chats/seenChatsByPatient/${id}`);

export const fetchAppointment = (id) =>
  API.get(`/api/appointments/fetchAppointment/${id}`);
export const fetchAppointments = () =>
  API.get("/api/appointments/fetchAppointments");
export const fetchMyAppointments = (id, filters) =>
  API.post(`/api/appointments/fetchMyAppointments/${id}`, filters);
export const filterAppointments = (filters) =>
  API.post("/api/appointments/filterAppointments", filters);
export const fetchAppointmentsByMonth = (month) =>
  API.get(`/api/appointments/fetchAppointmentsByMonth/${month}`);
export const createAppointment = (newAppointment) =>
  API.post("/api/appointments/createAppointment", newAppointment);
export const editAppointment = (id, updatedAppointment) =>
  API.patch(`/api/appointments/${id}`, updatedAppointment);
export const deleteAppointment = (id) => API.delete(`/api/appointments/${id}`);
export const changeStatus = (id, status, formData) =>
  API.post(`/api/appointments/changeStatus/${id}`, {
    status: status,
    formData: formData,
  });
export const addManyAppointments = (appointments, formData) =>
  API.post("/api/appointments/addManyAppointments", {
    appointmentsToAdd: appointments,
    formData: formData,
  });
export const seedAppointments = () =>
  API.get("/api/appointments/seedAppointments");

export const fetchResa = (id) => API.get(`/api/resas/fetchResa/${id}`);
export const fetchResas = () => API.get("/api/resas/fetchResas");
export const fetchResasByDoctorId = (id) =>
  API.get(`/api/resas/fetchResasByDoctorId/${id}`);
export const fetchResasByEtablissementId = (id) =>
  API.get(`/api/resas/fetchResasByEtablissementId/${id}`);
export const fetchResasByAgendas = (agendas) =>
  API.post("/api/resas/fetchResasByAgendas", { agendas: agendas });
export const fetchResasByMonth = (month) =>
  API.get(`/api/resas/fetchResasByMonth/${month}`);
export const fetchUpcomingFreeResas = (filters) =>
  API.post("/api/resas/fetchUpcomingFreeResas", filters);
export const createResa = (newResa) =>
  API.post("/api/resas/createResa", newResa);
export const editResa = (id, updatedResa) =>
  API.patch(`/api/resas/${id}`, updatedResa);
export const changeStatusResa = (id, status) =>
  API.put(`/api/resas/changeStatusResa/${id}`, { status: status });
export const deleteResa = (id) => API.delete(`/api/resas/${id}`);

//  RESERVATION VAD APIs

export const fetchResavad = (id) => API.get(`/api/resasvad/fetchResa/${id}`);
export const fetchResasvad = () => API.get("/api/resasvad/fetchResasVAD");
export const fetchResasByDoctorIdvad = (id) =>
  API.get(`/api/resasvad/fetchResasVADByDoctorId/${id}`);
export const fetchResasByEtablissementIdvad = (id) =>
  API.get(`/api/resasvad/fetchResasVADByEtablissementId/${id}`);
export const fetchResasByAgendasvad = (agendas) =>
  API.post("/api/resasvad/fetchResasVADByAgendas", { agendas: agendas });
export const fetchResasByMonthvad = (month) =>
  API.get(`/api/resasvad/fetchResasVADByMonth/${month}`);
export const fetchUpcomingFreeResasvad = (filters) =>
  API.post("/api/resasvad/fetchUpcomingFreeResasVAD", filters);
export const createResavad = (newResa) =>
  API.post("/api/resasvad/createResaVAD", newResa);
export const editResavad = (id, updatedResa) =>
  API.patch(`/api/resasvad/${id}`, updatedResa);
export const changeStatusResavad = (id, status) =>
  API.put(`/api/resasvad/changeStatusResaVAD/${id}`, { status: status });
export const deleteResavad = (id) => API.delete(`/api/resasvad/${id}`);

export const seedSettings = () => API.get("/api/settings/seedSettings");
export const fetchSettings = () => API.get("/api/settings/fetchSettings");
export const createSetting = (newSetting) =>
  API.post("/api/settings/createSetting", newSetting);
export const updateSetting = (updatedSetting) =>
  API.patch("/api/settings/updateSetting", updatedSetting);
export const deleteSetting = (id) => API.delete(`/api/settings/${id}`);

// Not Verified

export const fetchPosts = () => API.get(`/posts/fetchClientPosts`);
export const fetchWaitingPosts = () => API.get(`/posts/waitingPosts`);
export const fetchPublicPosts = () => API.get(`/posts/publicPosts`);
export const fetchPost = (id) => API.get(`/posts/getPost/${id}`);
export const createPost = (newPost) => API.post("/posts", newPost);
export const likePost = (id) => API.patch(`/posts/${id}/likePost`);
export const comment = (value, id) =>
  API.post(`/posts/${id}/commentPost`, { value });
export const updatePost = (id, updatedPost) =>
  API.patch(`/posts/${id}`, updatedPost);
export const deletePost = (id) => API.delete(`/posts/${id}`);
export const publicWaiting = (id, formData) =>
  API.put(`/posts/${id}/publicWaiting`, formData);
export const topSwitch = (id, formData) =>
  API.put(`/posts/${id}/topSwitch`, formData);

export const filterEvents = (filters) =>
  API.post("/api/events/filterEvents", filters);

export const getTomorrowApps = () => API.get("/api/sms/getTomorrowApps");
export const sendSms = () => API.get("/api/sms/sendSms");
export const smsLog = () => API.get("/api/sms/smsLog");
