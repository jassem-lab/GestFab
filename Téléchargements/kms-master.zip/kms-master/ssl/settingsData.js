export const settings = [
    {
        attribute: 'celluleHeight',
        value: 3,
        label: 'Cellule Height',
    },
]
