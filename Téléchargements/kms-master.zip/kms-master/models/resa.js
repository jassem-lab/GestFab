import mongoose from 'mongoose';

const resaSchema = new mongoose.Schema({
    start: String,
    doctor: String,
    type: String,
    color: String,
    status: String,
    agenda: String,
    takedBy: String,
}, {
    timestamps: true
});

const Resa = mongoose.model('Resa', resaSchema);
export default Resa;