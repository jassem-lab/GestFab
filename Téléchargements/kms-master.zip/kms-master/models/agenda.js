import mongoose from 'mongoose';

const agendaSchema = mongoose.Schema({
    name: String,
    speciality: String,
    consultationsTypes: [String],
    phone: String,
    template: { type: mongoose.Schema.Types.ObjectId, ref: 'Template' },
},  { timestamps: true })

var Agenda = mongoose.model('Agenda', agendaSchema);

export default Agenda;