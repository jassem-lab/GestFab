import mongoose from "mongoose";

const patientSchema = mongoose.Schema(
  {
    user: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
    assignedEtab: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Etablissement",
    },
    securityNumber: String,
    paymentCenter: String,
    birthday: String,
    fixeNumber: String,
    address: String,
    access: String,
    cp: String,
    city: String,
    information: String,
    rdv: { type: Boolean, default: true },
    treatingDoctor: Boolean,
    ame: Boolean,
    cmu: Boolean,
    blacklist: { type: Boolean, default: false },
  },
  { timestamps: true }
);

export default mongoose.model("Patient", patientSchema);
