import mongoose from 'mongoose';

const templateSchema = mongoose.Schema({
    startDate: Date,
    endDate: Date,
    durationPart: Number,
    rdvsByPart: Number,
    table: [],
},  { timestamps: true })

var Template = mongoose.model('Template', templateSchema);

export default Template;