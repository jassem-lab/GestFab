import mongoose from 'mongoose';

const smsSchema = new mongoose.Schema({
    date: String,
    doctor: String,
    patient: String,
    phone: String,
}, {
    timestamps: true
});

const Sms = mongoose.model('Sms', smsSchema);
export default Sms;