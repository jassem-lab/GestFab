import mongoose from "mongoose";

const userSchema = mongoose.Schema({
  name: String,
  email: { type: String, required: true, unique: true },
  phone: String,
  gender: String,
  password: { type: String, required: true },
  role: { type: String, default: 'patient' },
  avatar: String
});

export default mongoose.model("User", userSchema);