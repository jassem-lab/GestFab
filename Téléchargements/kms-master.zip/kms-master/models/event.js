import mongoose from "mongoose";

const EventSchema = mongoose.Schema(
  {
    appointmentDate: String,
    patientId: String,
    patientName: String,
    doctorId: String,
    doctorName: String,
    appointmentType: String,
    appointmentTypeColor: String,
    motif: String,
    notes: String,
    actorName: String,
    actorRole: String,
    eventType: String,
  },
  { timestamps: true }
);

const Event = mongoose.model("Event", EventSchema);

export default Event;
