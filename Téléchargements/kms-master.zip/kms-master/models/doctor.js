import mongoose from 'mongoose';

const doctorSchema = mongoose.Schema({
    user: {type: mongoose.Schema.Types.ObjectId, ref: 'User'},
    etablissement: {type: mongoose.Schema.Types.ObjectId, ref: 'Etablissement'},
    agendas: {type: [mongoose.Schema.Types.ObjectId], ref: 'Agenda'},
},  { timestamps: true })

export default mongoose.model('Doctor', doctorSchema);