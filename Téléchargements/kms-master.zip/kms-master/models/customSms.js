import mongoose from "mongoose";

const customSmsSchema = new mongoose.Schema(
  {
    date: String,
    doctor: String,
    patient: String,
    phone: String,
    message: String,
  },
  {
    timestamps: true,
  }
);

const customSms = mongoose.model("customSms", customSmsSchema);
export default customSms;
