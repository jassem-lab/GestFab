import mongoose from 'mongoose';

const settingSchema = mongoose.Schema({
    attribute: '',
    value: '',
    label: '',
},  { timestamps: true })

var Setting = mongoose.model('Setting', settingSchema);

export default Setting;