import mongoose from 'mongoose';

const postSchema = mongoose.Schema({
    creator: {type: mongoose.Schema.Types.ObjectId, ref: 'User'},
    status: { type: String, default: "Waiting" },
    title: String,
    photos: [String],
    top: { type: Boolean, default: false},
    likes: { type: [String], default: [] },
    comments: { type: [String], default: [] },
},  { timestamps: true })

var Post = mongoose.model('Post', postSchema);

export default Post;