import mongoose from 'mongoose';

const appointementSchema = new mongoose.Schema({
    createdBy: {type: mongoose.Schema.Types.ObjectId, ref: 'User'},
    doctor: {type: mongoose.Schema.Types.ObjectId, ref: 'Doctor'},
    patient: {type: mongoose.Schema.Types.ObjectId, ref: 'Patient'},
    start: {type: String},
    duration: {type: Number},
    type: {type: String},
    color: {type: String},
    motif: {type: String},
    notes: {type: String},
    status: {type: String, default: 'Attente'},
    agenda: {type: mongoose.Schema.Types.ObjectId, ref: 'Agenda'},
    celluleId: {type: mongoose.Schema.Types.ObjectId, ref: 'Resa'},
    sms: {type: Boolean, default: false},
}, {
    timestamps: true
});

const Appointement = mongoose.model('Appointement', appointementSchema);
export default Appointement;