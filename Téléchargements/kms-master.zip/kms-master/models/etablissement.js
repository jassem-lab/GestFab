import mongoose from 'mongoose';

const etablissementSchema = mongoose.Schema({
    name: String,
    phone: String,
    address: String,
    postalCode: String,
    city: String,
    startDayHour: {type: Number, min: 0, max: 23, default: 8},
    endDayHour: {type: Number, min: 0, max: 23, default: 18},
    excludedDays: [Number],
},  { timestamps: true })

var Etablissement = mongoose.model('Etablissement', etablissementSchema);

export default Etablissement;