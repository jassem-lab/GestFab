import express from "express";

import {
  getPatients,
  getPatient,
  createPatient,
  editPatient,
  deletePatient,
  blockPatient,
  getPatientsByEtab,
  clearPatients,
  filterPatients,
  getChatsByPatient,
  getMyAppointmentsByPatients,
} from "../controllers/patients.js";

const router = express.Router();
import auth from "../middleware/auth.js";

router.get("/getChatsByPatient/:id", getChatsByPatient);
router.get("/getMyAppointmentsByPatients/:id", getMyAppointmentsByPatients);
router.get("/fetchPatients", getPatients);
router.get("/fetchPatient/:id", getPatient);
router.get("/fetchPatientsByEtab/:id", getPatientsByEtab);
router.post("/filterPatients", filterPatients);
router.post("/createPatient", createPatient);
router.patch("/:id", editPatient);
router.post("/blockPatient/:id", blockPatient);
router.delete("/:id", deletePatient);
router.get("/clearPatients", clearPatients);

export default router;
