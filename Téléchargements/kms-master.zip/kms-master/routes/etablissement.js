import express from 'express';

import { getEtablissements, getEtablissement, createEtablissement, updateEtablissement, deleteEtablissement } from '../controllers/etablissement.js';

const router = express.Router();
import auth from "../middleware/auth.js";

router.get('/fetchEtablissements', getEtablissements);
router.get('/getEtablissement/:id', getEtablissement);

router.post('/createEtablissement', auth, createEtablissement);
router.patch('/:id', auth, updateEtablissement);
router.delete('/:id', auth, deleteEtablissement);

export default router;