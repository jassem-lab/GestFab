import express from "express";
import {
  getAllApps,
  sendCustomSms,
  getAllData,
} from "../controllers/customSms.js";

const router = express.Router();

router.post("/sendCustomSms", sendCustomSms);
router.get("/getAllApps/:startDate/:endDate", getAllApps);
router.get("/getAllData", getAllData);

export default router;
