import express from 'express';
import auth from "../middleware/auth.js";

import { filterEvents } from "../controllers/events.js";

const router = express.Router();

router.post('/filterEvents', auth, filterEvents);

export default router;
