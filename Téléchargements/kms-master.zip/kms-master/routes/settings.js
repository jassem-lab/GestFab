import express from 'express';
import { createSetting, deleteSetting, getSettings, updateSetting } from '../controllers/settings.js';

const router = express.Router();
import auth from "../middleware/auth.js";

router.get('/fetchSettings', auth, getSettings);
router.post('/createSetting', auth, createSetting);
router.patch('/updateSetting', auth, updateSetting);
router.delete('/:id', auth, deleteSetting);

export default router;