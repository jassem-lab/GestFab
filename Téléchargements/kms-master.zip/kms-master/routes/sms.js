import express from 'express';
import {
    getTomorrowApps,
    sendSms,
    smsLog
} from '../controllers/sms.js';

const router = express.Router();
import auth from "../middleware/auth.js";

router.get('/getTomorrowApps', auth, getTomorrowApps);
router.get('/sendSms', auth, sendSms);
router.get('/smsLog', auth, smsLog);

export default router;