import express from "express";

import {
  getAppointments,
  filterAppointments,
  getAppointment,
  createAppointment,
  editAppointment,
  deleteAppointment,
  changeStatus,
  addManyAppointments,
  seedAppointments,
  getMyAppointments,
  clearAppointments,
  getAppointmentsByMonth,
} from "../controllers/appointments.js";

const router = express.Router();
import auth from "../middleware/auth.js";

router.get("/fetchAppointments", auth, getAppointments);
router.get("/fetchAppointment/:id", auth, getAppointment);
router.post("/fetchMyAppointments/:id", auth, getMyAppointments);
router.post("/filterAppointments", auth, filterAppointments);
router.get("/fetchAppointmentsByMonth/:date", auth, getAppointmentsByMonth);
router.post("/createAppointment", auth, createAppointment);
router.patch("/:id", auth, editAppointment);
router.delete("/:id", auth, deleteAppointment);
router.post("/changeStatus/:id", auth, changeStatus);
router.post("/addManyAppointments", auth, addManyAppointments);
router.get("/clearAppointments", clearAppointments);

export default router;
