import express from 'express';
import { getAgendas, getAgenda, createAgenda, updateAgenda, deleteAgenda, createTemplate, updateTemplate, getAgendasByIds, getDoctorDuration } from '../controllers/agendas.js';

const router = express.Router();
import auth from "../middleware/auth.js";

router.get('/fetchAgendas', getAgendas);
router.post('/fetchAgendasByIds', getAgendasByIds);
router.get('/getAgenda/:id', getAgenda);
router.post('/createAgenda', auth, createAgenda);
router.patch('/:id', auth, updateAgenda);
router.delete('/:id', auth, deleteAgenda);
router.get('/getDoctorDuration/:id', getDoctorDuration);

router.post('/createTemplate/:id', createTemplate);
router.post('/updateTemplate/:id', updateTemplate);

export default router;