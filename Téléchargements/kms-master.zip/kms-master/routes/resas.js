import express from 'express';
import {
    createResa,
    deleteResa,
    editResa,
    getResas,
    getResasByAgenda,
    seedResas,
    getResasByDoctorId,
    changeStatusResa,
    getResasByMonth,
    clearResas,
    getResasByEtablissementId,
    getUpcomingFreeResas
} from '../controllers/resas.js';

const router = express.Router();
import auth from "../middleware/auth.js";

router.get('/fetchResas', getResas);
router.get('/fetchResasByDoctorId/:id', getResasByDoctorId);
router.get('/fetchResasByEtablissementId/:id', getResasByEtablissementId)
router.get('/fetchResasByMonth/:date', getResasByMonth);
router.post('/fetchResasByAgendas', getResasByAgenda);
router.post('/fetchUpcomingFreeResas', getUpcomingFreeResas);
router.post('/createResa', auth, createResa);
router.patch('/:id', auth, editResa);
router.delete('/:id', auth, deleteResa);
router.put('/changeStatusResa/:id', auth, changeStatusResa);
//router.get('/seedResas', seedResas);
router.get('/clearResas', clearResas);

export default router;