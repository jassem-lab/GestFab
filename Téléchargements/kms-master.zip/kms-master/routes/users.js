import express from "express";
import { addUser, deleteUser, editUser, listUsers, getUser, getAdmins, seedUsers, correctPhoneUsers  } from "../controllers/users.js";
import auth from "../middleware/auth.js";

const router = express.Router();


router.get("/listUsers", auth, listUsers);
router.get("/fetchUser/:id", getUser);
router.get("/listAdmins", auth, getAdmins);
router.post("/addUser", auth, addUser);
router.post("/editUser/:id", editUser);
router.delete("/:id", auth, deleteUser);
//router.get("/seedUsers", seedUsers);
//router.get("/correctPhoneUsers", correctPhoneUsers);

export default router;