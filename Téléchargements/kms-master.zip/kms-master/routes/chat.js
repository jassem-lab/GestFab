import express from "express";
import {
  createChat,
  getChat,
  getChats,
  getChatsByDoctors,
  deleteChat,
  messageSeen,
  messageSeenByPatient,
  editChat,
} from "../controllers/chat.js";

const router = express.Router();
import auth from "../middleware/auth.js";

router.get("/fetchChats/:id", auth, getChats);
router.get("/fetchChat/:id", auth, getChat);
router.post("/fetchChatsByDoctors", auth, getChatsByDoctors);
// router.post("/fetchChatByPatient", auth, getChatsByPatients);
router.post("/createChat", auth, createChat);
router.patch("/editChat/:id", auth, editChat);
router.post("/seenChats/:id", auth, messageSeen);
router.post("/seenChatsByPatient/:id", auth, messageSeenByPatient);
router.delete("/:id", auth, deleteChat);

export default router;
