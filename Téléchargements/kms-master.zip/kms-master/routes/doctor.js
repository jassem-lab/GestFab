import express from 'express';

import { getDoctors, getDoctor, createDoctor, editDoctor, deleteDoctor, getDoctorByUser, getDoctorsByEtab } from '../controllers/doctors.js';

const router = express.Router();
import auth from "../middleware/auth.js";

router.get('/fetchDoctors', getDoctors);
router.get('/fetchDoctor/:id', getDoctor);
router.get('/fetchDoctorByUser/:id', getDoctorByUser);
router.get('/fetchDoctorsByEtab/:id', getDoctorsByEtab);
router.post('/createDoctor', auth, createDoctor);
router.patch('/:id', auth, editDoctor);
router.delete('/:id', auth, deleteDoctor);

export default router;