import express from "express";
import Appointement from "../models/appointment.js";
import Resa from "../models/resa.js";
import moment from "moment";
import Patient from "../models/patient.js";
import Doctor from "../models/doctor.js";
import Event from "../models/event.js";
import User from "../models/user.js";
import Agenda from "../models/agenda.js";
import Chat from "../models/chat.js";
import axios from "axios";
const router = express.Router();

export const getAppointments = async (req, res) => {
  try {
    const appointments = await Appointement.find({});

    res.status(201).json(appointments);
  } catch (error) {
    res.status(404).json({ message: error.message });
  }
};

export const getMyAppointments = async (req, res) => {
  const { id } = req.params;

  const patient = await Patient.findOne({ user: id });
  if (!patient) {
    return res.status(404).json({ message: "No Patient" });
  }

  const {
    showCanceled = false,
    all,
    status,
    type,
    startDate,
    endDate,
    size = 20,
    page = 0,
  } = req.body;
  const filters = { patient: patient._id };

  if (all) {
    const appointments = await Appointement.find(filters)
      .populate({ path: "doctor", populate: { path: "user", select: "name" } })
      .sort({ start: -1 });

    return res.status(201).json(appointments);
  }

  if (status) {
    filters.status = status;
  }

  if (type) {
    filters.type = type;
  }

  if (showCanceled) {
    filters.status = { $ne: "Annuler" };
  }

  if (startDate) {
    if (!endDate) {
      filters.start = { $regex: `^${startDate}.*`, $options: "i" };
    } else {
      filters.start = { $gte: `${startDate}T00:00`, $lt: `${endDate}T23:59` };
    }
  } else if (endDate) {
    filters.start = { $lt: `${endDate}T23:59` };
  }

  try {
    const appointments = await Appointement.find(filters)
      .populate({ path: "doctor", populate: { path: "user", select: "name" } })
      .sort({ start: -1 })
      .skip(page * size)
      .limit(size);
    const count = await Appointement.countDocuments(filters);

    return res
      .status(201)
      .header("X-Pagination-Count", Math.ceil(count / size))
      .header("X-Pagination-Total", count)
      .header("X-Pagination-Page", page)
      .json(appointments);
  } catch (error) {
    res.status(404).json({ message: error.message });
  }
};

export const filterAppointments = async (req, res) => {
  const {
    showCanceled = false,
    status,
    type,
    doctorId,
    patientId,
    startDate,
    endDate,
    size = 20,
    page = 0,
  } = req.body;
  const filters = {};

  if (status) {
    filters.status = status;
  }

  if (type) {
    filters.type = type;
  }

  if (showCanceled) {
    filters.status = { $ne: "Annuler" };
  }

  if (doctorId) {
    filters.doctor = doctorId;
  }

  if (patientId) {
    filters.patient = patientId;
  }

  if (startDate) {
    if (!endDate) {
      filters.start = { $regex: `^${startDate}.*`, $options: "i" };
    } else {
      filters.start = { $gte: `${startDate}T00:00`, $lt: `${endDate}T23:59` };
    }
  } else if (endDate) {
    filters.start = { $lt: `${endDate}T23:59` };
  }

  try {
    const appointments = await Appointement.find(filters)
      .populate({ path: "createdBy", select: "-password -avatar" })
      .populate({
        path: "doctor",
        populate: { path: "user", select: "-password -avatar" },
      })
      .populate({
        path: "patient",
        populate: { path: "user", select: "-password -avatar" },
      })
      .sort({ start: -1 })
      .skip(page * size)
      .limit(size);
    const count = await Appointement.countDocuments(filters);

    res
      .status(201)
      .header("X-Pagination-Count", Math.ceil(count / size))
      .header("X-Pagination-Total", count)
      .header("X-Pagination-Page", page)
      .json(appointments);
  } catch (error) {
    res.status(404).json({ message: error.message });
  }
};

export const getAppointmentsByMonth = async (req, res) => {
  const { date } = req.params; // YYYY-MM-DD
  const dateMoment = moment(date, "YYYY-MM-DD");
  const startSearchDate = dateMoment.weekday(0).format("YYYY-MM-DDTHH:mm");
  const endSearchDate = dateMoment.weekday(7).format("YYYY-MM-DDTHH:mm");
  try {
    const appointments = await Appointement.find({
      start: {
        $gte: startSearchDate,
        $lt: endSearchDate,
      },
    }).populate("createdBy", "role"); // YYYY-MM-DDTHH:mm

    res.status(201).json(appointments);
  } catch (error) {
    res.status(404).json({ message: error.message });
  }
};

export const getAppointment = async (req, res) => {
  const { id } = req.params;
  try {
    const appointment = await Appointement.findById(id);
    res.status(200).json({ data: appointment });
  } catch (error) {
    res.status(404).json({ message: error.message });
  }
};

export const createAppointment = async (req, res) => {
  const {
    createdBy,
    doctor,
    patient,
    start,
    duration,
    type,
    motif,
    status,
    notes,
    celluleId,
  } = req.body;

  try {
    const patientExist = await Patient.findById(patient).populate(
      "user",
      "-password -avatar"
    );

    if (patientExist.blacklist) {
      return res.status(404).json({
        message:
          "Votres compte a été désactivé, veuillez contacter le secrétariat.",
      });
    }
    if (createdBy === patient && !patientExist.assignedEtab) {
      return res.status(404).json({
        message:
          "Vous n'êtes pas reconnus comme patient habituel du cabinet, si vous êtes un nouveau patient, veuillez contacter le secrétariat.",
      });
    }

    const doctorExist = await Doctor.findById(doctor).populate(
      "user",
      "-password -avatar"
    );

    let color;
    const dispo = await Resa.find({
      start: moment(start).format("YYYY-MM-DDTHH:mm"),
      status: "free",
      doctor: doctor,
    });
    if (dispo.length > 0) {
      dispo.forEach((element) => {
        if (element.type === type) {
          color = element.color;
          return;
        }
      });
    } else {
      return res.status(404).json({ message: "No available time" });
    }

    const newAppointment = new Appointement({
      createdBy: createdBy,
      doctor: doctor,
      patient: patient,
      start: start,
      duration: duration,
      type: type,
      color: color,
      motif: motif,
      status: status,
      notes: notes,
      celluleId: null,
    });

    const savedAppointments = await newAppointment.save();
    reportEvent(
      "CREATE",
      savedAppointments,
      patientExist,
      doctorExist,
      req.userId
    );

    if (celluleId) {
      const cellule = await Resa.findById(celluleId);
      cellule.status = "taked";
      cellule.takedBy = savedAppointments._id;
      savedAppointments.celluleId = celluleId;
      await cellule.save();
    } else {
      const cellules = await Resa.find({
        start: moment(start).format("YYYY-MM-DDTHH:mm"),
        status: "free",
        type: type,
        doctor: doctor,
      });
      if (cellules.length > 0) {
        const cellule = cellules[0];
        cellule.status = "taked";
        cellule.takedBy = savedAppointments._id;
        await cellule.save();
        savedAppointments.celluleId = cellule._id;
      } else {
        const newResa = new Resa({
          start: moment(start).format("YYYY-MM-DDTHH:mm"),
          duration: duration,
          type: type,
          color: color,
          status: "taked",
          takedBy: savedAppointments._id,
          doctor: doctor,
        });
        const savedResa = await newResa.save();
        savedAppointments.celluleId = savedResa._id;
      }
    }
    await savedAppointments.save();
    const ResAppointment = await Appointement.findById(savedAppointments._id);
    res.status(201).json(ResAppointment);
  } catch (error) {
    res.status(409).json({ message: error.message });
  }
};

export const editAppointment = async (req, res) => {
  const { id } = req.params;
  const {
    createdBy,
    doctor,
    patient,
    date,
    start,
    duration,
    type,
    motif,
    status,
    notes,
    celluleId,
  } = req.body;

  try {
    const currentAppointment = await Appointement.findById(id);
    const patientExist = await Patient.findById(patient).populate(
      "user",
      "-password -avatar"
    );
    const doctorExist = await Doctor.findById(doctor).populate(
      "user",
      "-password -avatar"
    );

    const updatedAppointment = {
      _id: id,
      createdBy: createdBy,
      doctor: doctor,
      patient: patient,
      date: date,
      start: start,
      duration: duration,
      type: type,
      motif: motif,
      status: status,
      notes: notes,
      celluleId: celluleId,
    };

    if (start !== currentAppointment.start) {
      const myResa = await Resa.findById(currentAppointment.celluleId);
      myResa.status = "free";
      myResa.takedBy = null;
      updatedAppointment.celluleId = null;
      const dispo = await Resa.find({
        start: moment(start).format("YYYY-MM-DDTHH:mm"),
        status: "free",
        type: type,
        doctor: doctor,
      });
      if (dispo.length > 0) {
        const cellule = dispo[0];
        cellule.status = "taked";
        cellule.takedBy = id;
        updatedAppointment.celluleId = cellule._id;
        await cellule.save();
      } else {
        const newResa = new Resa({
          start: moment(start).format("YYYY-MM-DDTHH:mm"),
          duration: duration,
          type: type,
          color: currentAppointment.color,
          status: "taked",
          takedBy: id,
          doctor: doctor,
        });
        const savedResa = await newResa.save();
        updatedAppointment.celluleId = savedResa._id;
      }
      reportEvent(
        "TRANSFER",
        updatedAppointment,
        patientExist,
        doctorExist,
        req.userId
      );
    }

    if (
      currentAppointment.status === "Attente" ||
      currentAppointment.status === "Confirmer"
    ) {
      if (status === "Annuler") {
        const cellule = await Resa.findById(currentAppointment.celluleId);
        cellule.status = "free";
        cellule.takedBy = null;
        await cellule.save();
        reportEvent(
          "CANCEL",
          updatedAppointment,
          patientExist,
          doctorExist,
          req.userId
        );
      } else {
        reportEvent(
          "UPDATE",
          updatedAppointment,
          patientExist,
          doctorExist,
          req.userId
        );
      }
    }

    if (currentAppointment.status === "Annuler") {
      if (status === "Attente" || status === "Confirmer") {
        const cellules = await Resa.find({
          start: moment(start).format("YYYY-MM-DDTHH:mm"),
          status: "free",
          doctor: doctor,
        });
        if (cellules.length > 0) {
          const cellule = cellules[0];
          cellule.status = "taked";
          cellule.takedBy = currentAppointment._id;
          await cellule.save();
          updatedAppointment.celluleId = cellule._id;
        } else {
          const newResa = new Resa({
            start: moment(start).format("YYYY-MM-DDTHH:mm"),
            duration: duration,
            type: type,
            color: currentAppointment.color,
            status: "taked",
            takedBy: id,
            doctor: doctor,
          });
          const savedResa = await newResa.save();
          updatedAppointment.celluleId = savedResa._id;
        }
        reportEvent(
          "UPDATE",
          updatedAppointment,
          patientExist,
          doctorExist,
          req.userId
        );
      }
    }

    const ResAppointment = await Appointement.findByIdAndUpdate(
      id,
      updatedAppointment,
      { new: true }
    );

    res.status(201).json(ResAppointment);
  } catch (error) {
    res.status(409).json({ message: error.message });
  }
};

export const deleteAppointment = async (req, res) => {
  const { id } = req.params;

  try {
    const appointment = await Appointement.findByIdAndRemove(id)
      .populate({
        path: "doctor",
        populate: { path: "user", select: "name phone" },
      })
      .populate({
        path: "patient",
        populate: { path: "user", select: "name phone" },
      });

    reportEvent(
      "DELETE",
      appointment,
      appointment.patient,
      appointment.doctor,
      req.userId
    );

    res.status(201).send("Appointment deleted successfully.");
  } catch (error) {
    res.status(500).json({ message: "Error" });
    console.log(error);
  }
};

export const changeStatus = async (req, res) => {
  const { id } = req.params;
  const { status, formData } = req.body;

  try {
    const currentAppointment = await Appointement.findById(id)
      .populate({ path: "doctor", populate: { path: "user", select: "name" } })
      .populate({
        path: "patient",
        populate: { path: "user", select: "name" },
      });

    if (currentAppointment) {
      if (status === "Annuler") {
        const resa = await Resa.findById(currentAppointment.celluleId);
        if (resa) {
          resa.status = "free";
          resa.takedBy = null;
          await resa.save();
        }
        currentAppointment.celluleId = null;
        currentAppointment.status = "Annuler";
        currentAppointment.motif = formData.motif;
        await currentAppointment.save();
        if (formData.sendMsg) {
          const newChat = new Chat({
            from: formData.connectedUser,
            to: currentAppointment.doctor.user._id,
            about: currentAppointment.patient._id,
            object: "Annulation de rendez-vous",
            message:
              "Le rendez vous de " +
              currentAppointment.patient.user.name +
              " a été annulé pour la raison suivante : " +
              formData.motif,
            file: null,
            seen: false,
          });
          await newChat.save();
        }
        if (formData.sendSms) {
          const url = "https://api.smsmode.com/http/1.6/sendSMS.do";
          const token = process.env.SMS_TOKEN;
          const message = `Le+rendez+vous+de+${
            currentAppointment.patient.user.name
          }+du${moment(currentAppointment.start).format(
            "DD/MM/YYYY-HH:mm"
          )}+a+ete+annule+pour+la+raison+suivante+:+${formData.motif
            .split(" ")
            .join("+")}`;
          const { data } = await axios.get(
            `${url}?accessToken=${token}&message=${message}&numero=${currentAppointment.doctor.user.phone}`
          );
          console.log(data);
        }
        reportEvent(
          "CANCEL",
          currentAppointment,
          currentAppointment.patient,
          currentAppointment.doctor,
          req.userId
        );
      } else {
        const resa = await Resa.findOne({
          start: moment(currentAppointment.start).format("YYYY-MM-DDTHH:mm"),
          status: "free",
          doctor: currentAppointment.doctor._id,
        });
        if (resa) {
          resa.status = "taked";
          resa.takedBy = currentAppointment._id;
          await resa.save();
          currentAppointment.celluleId = resa._id;
          currentAppointment.status = status;
          await currentAppointment.save();
          reportEvent(
            "UPDATE",
            currentAppointment,
            currentAppointment.patient,
            currentAppointment.doctor,
            req.userId
          );
        } else {
          return res.status(401).json({ message: "No Free Space" });
        }
      }
    } else {
      return res.status(401).json({ message: "Appointment not found" });
    }

    const ResAppointment = await Appointement.findById(id)
      .populate({ path: "doctor", populate: { path: "user", select: "name" } })
      .populate({
        path: "patient",
        populate: { path: "user", select: "name" },
      });

    res.status(201).json(ResAppointment);
  } catch (error) {
    res.status(409).json({ message: error.message });
  }
};

export const addManyAppointments = async (req, res) => {
  const { appointmentsToAdd, formData } = req.body;
  try {
    if (appointmentsToAdd) {
      await Promise.all(
        appointmentsToAdd.map(async (appointment) => {
          const newAppointment = await new Appointement({
            createdBy: formData.createdBy,
            doctor: appointment.doctor._id,
            patient: formData.patient,
            start: appointment.start,
            duration: formData.duration,
            type: appointment.type,
            motif: formData.motif,
            status: formData.status,
            notes: formData.notes,
          }).save();

          const savedAppointment = await Appointement.findById(
            newAppointment._id
          )
            .populate({
              path: "doctor",
              populate: { path: "user", select: "name" },
            })
            .populate({
              path: "patient",
              populate: { path: "user", select: "name" },
            });

          reportEvent(
            "CREATE",
            savedAppointment,
            savedAppointment.patient,
            savedAppointment.doctor,
            req.userId
          );
        })
      );
    }

    const myAppointments = await Appointement.find({});

    res.status(201).json(myAppointments);
  } catch (error) {
    console.log(error);
    res.status(409).json({ message: error.message });
  }
};

export const clearAppointments = async (req, res) => {
  try {
    const appointments = await Appointement.find({
      status: { $ne: "Annuler" },
    });
    const allApps = await Appointement.find({});

    /*    // GET TYPES & COLOR
        let ourTypes = []
        agendas.map(agenda => {
            agenda.template.table.map(cs => {
                 if (ourTypes.indexOf(cs.type) === -1) {
                     ourTypes.push({
                         type: cs.type,
                         color: cs.color
                    })
                }
            })
        }) */

    appointments.forEach(async (appointment) => {
      try {
        const duplicated = allApps.filter(
          (app) =>
            app.start === app.start &&
            app.patient === app.patient &&
            app._id !== app._id
        );
        if (duplicated.length > 0) {
          duplicated.forEach(async (duplicatedAppointment) => {
            await Appointement.findByIdAndRemove(duplicatedAppointment._id);
          });
        }
        /* const appMoment = moment(appointment.start).format('YYYY-MM-DD')
                let selectedAgenda = null;
                if (appointment.doctor === doctors[0]._id) {
                    if (moment(appMoment, 'YYYY-MM-DD').isAfter(moment('2022-03-01', 'YYYY-MM-DD'))) {
                        selectedAgenda = agendas[0]._id
                    } else {
                        selectedAgenda = agendas[1]._id
                    }
                } else {
                    selectedAgenda = agendas[2]._id
                }
                const resas = allResas.filter(resa =>
                    moment(resa.start).format('YYYY-MM-DDTHH:mm') === moment(appointment.start).format('YYYY-MM-DDTHH:mm') &&
                    resa.status === 'free' && 
                    resa.type.toLowerCase().trim() === appointment.type.toLowerCase().trim()
                );
                if (resas && resas.length > 0) {
                    const myresa = resas[0];
                    myresa.status = 'taked';
                    myresa.takedBy = appointment._id;
                    await myresa.save();
                    appointment.celluleId = myresa._id;
                } else {
                    const newResa = new Resa({
                        start: appointment.start,
                        type: appointment.type,
                        color: ourTypes.find(type => type.type.toLowerCase().trim() === appointment.type.toLowerCase().trim()).color,
                        status: 'taked',
                        takedBy: appointment._id,
                        doctor: appointment.doctor,
                        agenda: selectedAgenda
                    });
                    const savedResa = await newResa.save()
                    appointment.celluleId = savedResa._id
                }
                await appointment.save(); */
      } catch (error) {
        console.log(error);
      }
    });

    res.status(201).json("all fixed");
  } catch (error) {
    res.status(404).json({ message: error.message });
  }
};

export const seedAppointments = async (req, res) => {};

async function reportEvent(eventType, appointment, patient, doctor, actorId) {
  try {
    const actor = await User.findById(actorId);

    await new Event({
      appointmentDate: appointment?.start,
      patientId: patient?._id,
      patientName: patient?.user?.name,
      doctorId: doctor?._id,
      doctorName: doctor?.user?.name,
      appointmentType: appointment?.type,
      motif: appointment?.motif,
      notes: appointment?.notes,
      appointmentTypeColor: appointment?.color,
      actorName: actor?.name,
      actorRole: actor?.role,
      eventType: eventType,
    }).save();
  } catch (e) {
    console.error(`Event saving error: ${e.message}`);
  }
}

export default router;
