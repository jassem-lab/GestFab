import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import User from "../models/user.js";
import Patient from "../models/patient.js";

const secret = 'test';

export const signin = async (req, res) => {
    const { email, password } = req.body;
    const user = await User.findOne({ email: email});
    if(!user) return res.status(404).json({message: 'No user with that email'})
   /*  
    const hashedPassword = await bcrypt.hash(password, 12);
    user.password = hashedPassword;
    await user.save();
    return res.status(200).json({message: 'Password changed!'});
 */
    if(!user.password) return res.status(404).json({message: 'No password !'})
    bcrypt.compare(password, user.password, (error, match) => {
        if (error) res.status(500).json(error)
        else if (match) {
            const token = jwt.sign( { email: user.email, id: user._id }, secret, { expiresIn: "24h" } );
            const result = { _id: user._id, name: user.name, email: user.email, role: user.role, avatar: user.avatar }
            res.status(200).json({data: {user: result, token: token}})
        } else res.status(403).json({message: 'Password do not match!'})
    })

};
  
export const signup = async (req, res) => {
    const { gender, cp, city, adress, phone, name, email, password, role} = req.body;

    try {

        const userExist = await User.findOne({ email: email});
        if (userExist) return res.status(400).json({ message: "User already exists" });
        const hashedPassword = await bcrypt.hash(password, 12);
        const user = await (new User({ 
            gender: gender,
            name: name, 
            email: email, 
            phone: phone,
            password: hashedPassword, 
            role: role 
        })).save();
        const newPatient = { 
            user: user._id,
            adress: adress,
            city: city,
            cp: cp,

        };
        await newPatient.save();
        const token = jwt.sign( { email: user.email, id: user._id }, secret, { expiresIn: "24h" } );
        const result = {email: user.email}
        res.status(200).json({data: {user: result, token: token}})

      } catch (error) {
            res.status(500).json(error);
      }
};