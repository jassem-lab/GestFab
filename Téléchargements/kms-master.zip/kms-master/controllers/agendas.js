import express from "express";
import Agenda from "../models/agenda.js";
import Template from "../models/template.js";
import Resa from "../models/resa.js";
import moment from "moment";
import Doctor from "../models/doctor.js";

const router = express.Router();

export const getAgendas = async (req, res) => {
  try {
    const agendas = await Agenda.find({}).populate("template");
    res.status(201).json(agendas);
  } catch (error) {
    res.status(404).json({ message: error.message });
  }
};

export const getDoctorDuration = async (req, res) => {
  const { id } = req.params;
  try {
    const doctor = await Doctor.findById(id);
    const agendas = await Agenda.find({}).populate("template");

    if (agendas) {
      agendas.forEach((agenda) => {
        if (doctor.agendas.includes(agenda._id)) {
          return res.status(201).json(agenda.template.durationPart);
        }
      });
    }
  } catch (error) {
    res.status(404).json({ message: error.message });
  }
};

export const getAgendasByIds = async (req, res) => {
  const { ids } = req.body;
  try {
    const agendas = await Agenda.find({ _id: { $in: ids } }).populate(
      "template"
    );
    res.status(201).json(agendas);
  } catch (error) {
    res.status(404).json({ message: error.message });
  }
};

export const getAgenda = async (req, res) => {
  const { id } = req.params;
  try {
    const agenda = await Agenda.findById(id).populate("template");
    res.status(200).json({ data: agenda });
  } catch (error) {
    res.status(404).json({ message: error.message });
  }
};

export const createAgenda = async (req, res) => {
  const { agendaName, speciality, consultationsTypes, cabinePhone } = req.body;
  const newAgenda = new Agenda({
    name: agendaName,
    speciality: speciality,
    consultationsTypes: consultationsTypes,
    phone: cabinePhone,
  });
  try {
    await newAgenda.save();
    res.status(201).json(newAgenda);
  } catch (error) {
    res.status(409).json({ message: error.message });
  }
};

export const updateAgenda = async (req, res) => {
  const { id } = req.params;
  const {
    agendaName,
    speciality,
    consultationsTypes,
    cabinePhone,
    startDayHour,
    endDayHour,
    excludedDays,
  } = req.body;
  const currentAgenda = await Agenda.findById(id);
  const updatedAgenda = {
    _id: id,
    name: agendaName,
    speciality: speciality,
    consultationsTypes: consultationsTypes,
    phone: cabinePhone,
    template: currentAgenda.template,
  };
  try {
    await Agenda.findByIdAndUpdate(id, updatedAgenda, { new: true }).array();
    res.status(201).json(updatedAgenda);
  } catch (error) {
    res.status(409).json({ message: error.message });
  }
};

export const deleteAgenda = async (req, res) => {
  const { id } = req.params;
  try {
    await Agenda.findByIdAndRemove(id);
    res.json({ message: "Agenda deleted successfully." });
  } catch (error) {
    res.status(409).json({ message: error.message });
  }
};

export const createTemplate = async (req, res) => {
  const { id } = req.params;
  const { startDate, endDate, durationPart, rdvsByPart, table } = req.body;

  const template = new Template({
    startDate: startDate,
    endDate: endDate,
    durationPart: durationPart,
    rdvsByPart: rdvsByPart,
    table: table,
  });

  try {
    const savedTemplate = await template.save();
    const agenda = await Agenda.findById(id);
    agenda.template = savedTemplate._id;
    await agenda.save();
    const doctors = await Doctor.find({});
    const doctor = doctors.find((doctor) => doctor.agendas.includes(id));
    const currentMoment = moment(startDate);
    const endMoment = moment(endDate);
    const fakeAppointments = [];
    while (currentMoment.isBefore(endMoment, "day")) {
      table.forEach((consultationsType) => {
        if (
          consultationsType.days &&
          consultationsType.days.find(
            (day) => day.dayIndex === currentMoment.isoWeekday()
          )
        ) {
          if (
            consultationsType.days.find(
              (day) => day.dayIndex === currentMoment.isoWeekday()
            ).intervals
          ) {
            consultationsType.days
              .find((day) => day.dayIndex === currentMoment.isoWeekday())
              .intervals.forEach((interval) => {
                if (interval.cellules > 0) {
                  for (let i = 0; i < interval.cellules; i++) {
                    fakeAppointments.push({
                      start:
                        currentMoment.format("YYYY-MM-DD") +
                        "T" +
                        interval.start,
                      doctor: doctor._id,
                      duration: durationPart,
                      type: consultationsType.type,
                      color: consultationsType.color,
                      status: "free",
                      agenda: agenda._id,
                    });
                  }
                }
              });
          }
        }
      });
      currentMoment.add(1, "days");
    }
    await Resa.insertMany(fakeAppointments);
    res.status(201).json(agenda);
  } catch (error) {
    res.status(409).json({ message: error.message });
  }
};

export const updateTemplate = async (req, res) => {
  const { id } = req.params;
  const { startDate, endDate, durationPart, rdvsByPart, table } = req.body;

  try {
    const agenda = await Agenda.findById(id);
    const template = await Template.findById(agenda.template);
    template.startDate = startDate;
    template.endDate = endDate;
    template.durationPart = durationPart;
    template.rdvsByPart = rdvsByPart;
    template.table = table;
    await template.save();
    //await Resa.deleteMany({ agenda: id });
    const resas = await Resa.find({ agenda: id });
    const doctors = await Doctor.find({});
    const doctor = doctors.find((doctor) => doctor.agendas.includes(id));
    const currentMoment = moment(startDate);
    const endMoment = moment(endDate);
    const fakeAppointments = [];

    while (currentMoment.isBefore(endMoment, "day")) {
      table.forEach((consultationsType) => {
        if (
          consultationsType.days &&
          consultationsType.days.find(
            (day) => day.dayIndex === currentMoment.isoWeekday()
          )
        ) {
          if (
            consultationsType.days.find(
              (day) => day.dayIndex === currentMoment.isoWeekday()
            ).intervals
          ) {
            consultationsType.days
              .find((day) => day.dayIndex === currentMoment.isoWeekday())
              .intervals.forEach((interval) => {
                if (interval.cellules > 0) {
                  for (let i = 0; i < interval.cellules; i++) {
                    const myResa = resas.filter(
                      (resa) =>
                        resa.start ===
                        currentMoment.format("YYYY-MM-DD") +
                          "T" +
                          interval.start
                    );
                    if (myResa && myResa.length > 0) {
                      /* resa.color = consultationsType.color;
                                        resa.duration = durationPart;
                                        await resa.save(); */
                      console.log("Resa find");
                    } else {
                      fakeAppointments.push({
                        start:
                          currentMoment.format("YYYY-MM-DD") +
                          "T" +
                          interval.start,
                        doctor: doctor._id,
                        motif: consultationsType.motif,
                        duration: durationPart,
                        type: consultationsType.type,
                        color: consultationsType.color,
                        status: "free",
                        agenda: agenda._id,
                      });
                    }
                  }
                }
              });
          }
        }
      });
      currentMoment.add(1, "days");
    }
    await Resa.insertMany(fakeAppointments);
    res.status(201).json(agenda);
  } catch (error) {
    res.status(409).json({ message: error.message });
  }
};

export default router;
