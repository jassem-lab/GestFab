import express from "express";
import Appointement from "../models/appointment.js";
import moment from "moment";
import Sms from "../models/sms.js";
import axios from "axios";

const router = express.Router();

// Get tomorrow appointments
export const getTomorrowApps = async (req, res) => {
  const tomorrow = moment().add(1, "days").format("YYYY-MM-DD");
  const tomorrowStart = `${tomorrow}T00:00`;
  const tomorrowEnd = `${tomorrow}T23:59`;
  const status = ["Attente", "Confirmer"];

  try {
    const apps = await Appointement.find({
      start: {
        $gte: tomorrowStart,
        $lt: tomorrowEnd,
      },
      status: {
        $in: status,
      },
    })
      .populate({
        path: "doctor",
        populate: {
          path: "user",
          select: "-password -avatar",
        },
      })
      .populate({
        path: "patient",
        populate: {
          path: "user",
          select: "-password -avatar",
        },
      });
    const tomorrowSms = [];
    apps.forEach((app) => {
      if (app.patient && app.doctor) {
        tomorrowSms.push({
          appId: app._id,
          date: app.start,
          doctor: app.doctor.user.name,
          name: app.patient.user.name,
          phone: app.patient.user.phone,
        });
      }
    });

    res.status(201).json(tomorrowSms);
  } catch (error) {
    res.status(404).json({ message: error.message });
  }
};

// SendSms
export const sendSms = async (req, res) => {
  const tomorrow = moment().add(1, "days").format("YYYY-MM-DD");
  const tomorrowStart = `${tomorrow}T00:00`;
  const tomorrowEnd = `${tomorrow}T23:59`;
  const status = ["Attente", "Confirmer"];

  try {
    const apps = await Appointement.find({
      start: {
        $gte: tomorrowStart,
        $lt: tomorrowEnd,
      },
      status: {
        $in: status,
      },
    })
      .populate({
        path: "doctor",
        populate: {
          path: "user",
          select: "-password -avatar",
        },
      })
      .populate({
        path: "patient",
        populate: {
          path: "user",
          select: "-password -avatar",
        },
      });

    let sms = [];
    apps.forEach((app) => {
      if (app.patient && app.doctor) {
        if (app.patient.user.phone.length > 0) {
          sms.push({
            phone: app.patient.user.phone,
            date: moment(app.start).format("DD/MM/YYYY-HH:mm"),
            doctor: app.doctor.user.name,
          });
        }
      }
    });

    const url = "https://api.smsmode.com/http/1.6/sendSMS.do";
    const token = process.env.SMS_TOKEN;

    sms.forEach(async (sm) => {
      const message = `Rappel+RDV+du+${sm.date},+avec+${sm.doctor.replace(
        " ",
        "+"
      )},+Kinesitherapeute+a+Chef-Boutonne.En+cas+de+desistement,+veuillez+contacter+le+0549297008`;
      try {
        const { data } = await axios.get(
          `${url}?accessToken=${token}&message=${message}&numero=${sm.phone}`
        );
        console.log(data);
      } catch (error) {
        console.log(error);
      }
    });

    let appsIds = [];
    apps.forEach(async (app) => {
      if (!app.sms && app.patient.user.phone.length > 0) {
        appsIds.push(app.appId);
        app.sms = true;
        await app.save();
        const newSms = new Sms({
          date: app.start,
          doctor: app.doctor,
          patient: app.patient,
          phone: app.phone,
        });
        await newSms.save();
      }
    });

    return res.status(201).json({ message: "SMS envoyé" });
  } catch (error) {
    console.log(error);
  }
};

// Sms get
export const smsLog = async (req, res) => {
  try {
    const sms = await Sms.find({});
    res.status(201).json(sms);
  } catch (error) {
    res.status(404).json({ message: error.message });
  }
};
export default router;
