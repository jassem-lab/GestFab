import bcrypt from "bcryptjs";
import Doctor from "../models/doctor.js";
import User from "../models/user.js";
import Etablissement from "../models/etablissement.js";
import Agenda from "../models/agenda.js";
import Patient from "../models/patient.js";

export const seedUsers = async (req, res) => {
  try {
    const etablissements = await Etablissement.find({});
    const agendas = await Agenda.find({});
    // Remove All Products
    await User.deleteMany({});
    await Patient.deleteMany({});
    await Doctor.deleteMany({});

    // Maamoun User
    // const maamoun = new User({
    //   name: "Maamoun Grissa",
    //   email: "grissa.maamoun@gmail.com",
    //   password: bcrypt.hashSync("Grissa1906", 10),
    //   role: "admin",
    //   avatar: "",
    //   phone: "50870256",
    // });
    // await maamoun.save();

    // Ameni User
    // const ameni = new User({
    //   name: "Emilie Naouar",
    //   email: "amany180@hotmail.com",
    //   password: bcrypt.hashSync("123456", 10),
    //   role: "admin",
    //   avatar: "",
    //   phone: "",
    // });
    // await ameni.save();

    // Samy User
    // const samy = new User({
    //   name: "Mr. Samy",
    //   email: "samy@kinedocrdv.fr",
    //   password: bcrypt.hashSync("123456", 10),
    //   role: "client",
    //   avatar: "",
    //   phone: "",
    // });
    // const savedSamy = await samy.save();
    // const samyDoctor = new Doctor({
    //   user: savedSamy._id,
    //   etablissement: etablissements[0]._id,
    //   agendas: [agendas[0]._id, agendas[1]._id],
    // });
    // await samyDoctor.save();

    // Philippe User
    //     const philippe = new User({
    //       name: "Philippe",
    //       email: "philippe@kinedocrdv.fr",
    //       password: bcrypt.hashSync("123456", 10),
    //       role: "admin",
    //       avatar: "",
    //       phone: "",
    //     });
    //     const savedPhilippe = await philippe.save();
    //     const philippeDoctor = new Doctor({
    //       user: savedPhilippe._id,
    //       etablissement: etablissements[0]._id,
    //       agendas: [agendas[2]],
    //     });
    //     await philippeDoctor.save();

    const users = await User.find({});

    res.status(201).json(users);
  } catch (error) {
    res.status(404).json({ message: error.message });
  }
};

export const getUser = async (req, res) => {
  const { id } = req.params;
  try {
    const user = await User.findById(id, "-password");
    return res.status(200).json(user);
  } catch (error) {
    return res.status(404).json({ message: error.message });
  }
};

export const listUsers = async (req, res) => {
  try {
    const users = await User.find({});
    res.json({ data: users });
  } catch (error) {
    res.status(404).json({ message: error.message });
  }
};

export const getAdmins = async (req, res) => {
  try {
    const admins = await User.find({ role: "admin" }, { password: 0 });
    res.status(201).json(admins);
  } catch (error) {
    res.status(404).json({ message: error.message });
  }
};

export const addUser = async (req, res) => {
  const { name, email, phone, gender, password, role, avatar } = req.body;
  try {
    const oldUser = await User.findOne({ email });
    if (oldUser) {
      return res.status(400).json({ message: "User already exists" });
    }
    const hashedPassword = await bcrypt.hash(password, 12);
    await User.create({
      name,
      email,
      phone,
      gender,
      password: hashedPassword,
      role,
    });
    res.json({ message: "User Added successfully." });
  } catch (error) {
    res.status(500).json({ message: "Something went wrong" });
    console.log(error);
  }
};

export const editUser = async (req, res) => {
  const { id } = req.params;
  const { name, email, phone, avatar, password, role } = req.body;
  try {
    const oldUser = await User.findById(id);
    if (oldUser) {
      oldUser.name = name ? name : oldUser.name;
      oldUser.email = email ? email : oldUser.email;
      oldUser.phone = phone ? phone : oldUser.phone;
      oldUser.avatar = avatar ? avatar : oldUser.avatar;
      oldUser.role = role ? role : oldUser.role;
      if (password) {
        const hashedPassword = await bcrypt.hash(password, 12);
        oldUser.password = hashedPassword;
      } else {
        oldUser.password = oldUser.password;
      }
      await oldUser.save();
      const user = await User.findById(id, "-password");
      res.status(201).json(user);
    } else {
      res.status(404).json({ message: "User not found" });
    }
  } catch (error) {
    res.status(404).json({ message: error.message });
  }
};

export const deleteUser = async (req, res) => {
  const { id } = req.params;
  await User.findByIdAndRemove(id);
  res.status(201).send(`User Deleted`);
};

// correct phone users

export const correctPhoneUsers = async (req, res) => {
  try {
    const users = await User.find({});
    users.forEach(async (user) => {
      if (user.phone.length > 0) {
        user.phone = `0${user.phone}`;
        await user.save();
      }
    });
    res.status(201).json(users);
  } catch (error) {
    res.status(404).json({ message: error.message });
  }
};
