import express from "express";
import Appointement from "../models/appointment.js";
import moment from "moment";
import Sms from "../models/sms.js";
import axios from "axios";

const router = express.Router();

// SendSms
export const sendCustomSms = async (req, res) => {
  const tomorrow = moment().add(1, "days").format("YYYY-MM-DD");
  // const tomorrowStart = `${tomorrow}T00:00`;
  // const tomorrowEnd = `${tomorrow}T23:59`;
  // const status = ["Attente", "Confirmer"];
  const customSms = req.body;

  try {
    const url = "https://api.smsmode.com/http/1.6/sendSMS.do";
    const token = process.env.SMS_TOKEN;

    const messagedest = [];
    messagedest.push(customSms.customedSms);

    try {
      const mappingSms = async () => {
        for (let a of messagedest) {
          const message = await a.map((aa) =>
            axios.get(
              `${url}?accessToken=${token}&message=${customSms.message}&numero=${aa.phone}`
            )
          );
          console.log(message);
        }
      };
      mappingSms();
    } catch (err) {
      throw err;
    }
  } catch (err) {
    throw err;
  }
};
// Get All Apps for SMS
export const getAllApps = async (req, res) => {
  const startDate = req.params.startDate;
  const endDate = req.params.endDate;

  // const startDateSearch = moment(startDate, "YYYY-MM-DD");
  // const endDateSearch = moment(endDate, "YYYY-MM-DD");
  // console.log(date);
  // console.log(startDateSearch);
  // console.log(endDateSearch);
  try {
    const apps = await Appointement.find({
      start: {
        $gte: startDate,
        $lt: endDate,
      },
      status: { $in: "Attente" },
    })
      .populate({
        path: "doctor",
        populate: {
          path: "user",
          select: "-password -avatar",
        },
      })
      .populate({
        path: "patient",
        populate: {
          path: "user",
          select: "-password -avatar",
        },
      })
      .sort("-start");

    const tomorrowSms = [];
    apps.forEach((app) => {
      if (app.patient && app.doctor) {
        tomorrowSms.push({
          appId: app._id,
          date: app.start,
          doctor: app.doctor.user.name,
          name: app.patient.user.name,
          phone: app.patient.user.phone,
        });
      }
    });
    res.status(201).json({ tomorrowSms });
  } catch (error) {
    res.status(404).json({ message: error.message });
  }
};
export const getAllData = async (req, res) => {
  try {
    const apps = await Appointement.find({
      status: { $in: "Attente" },
    })
      .populate({
        path: "doctor",
        populate: {
          path: "user",
          select: "-password -avatar",
        },
      })
      .populate({
        path: "patient",
        populate: {
          path: "user",
          select: "-password -avatar",
        },
      });

    const tomorrowSms = [];
    apps.forEach((app) => {
      if (app.patient && app.doctor) {
        tomorrowSms.push({
          appId: app._id,
          date: app.start,
          doctor: app.doctor.user.name,
          name: app.patient.user.name,
          phone: app.patient.user.phone,
        });
      }
    });
    res.status(201).json({ tomorrowSms });
  } catch (error) {
    res.status(404).json({ message: error.message });
  }
};
export default router;
