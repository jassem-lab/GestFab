import express from "express";
import bcrypt from "bcryptjs";
import Patient from "../models/patient.js";
import User from "../models/user.js";
import Etablissement from "../models/etablissement.js";
import Chat from "../models/chat.js";
import Appointement from "../models/appointment.js";
const router = express.Router();

export const clearPatients = async (req, res) => {
  try {
    // Remove All Products
    await Patient.deleteMany({});
    res.status(201).json("all deleted");
  } catch (error) {
    res.status(404).json({ message: error.message });
  }
};

// export const hello world = async (req, res) => {
//   const { id } = req.params;

//   const patient = await Patient.findOne({ user: id });
//   if (!patient) {
//     return res.status(404).json({ message: "No Patient" });
//   } else {
//     return patient;
//   }
// if (filters) {
//   const appointments = await Appointement.find(filters)
//     .populate({ path: "doctor", populate: { path: "user", select: "name" } })
//     .sort({ start: -1 });

//   return res.status(201).json(appointments);
// }

// try {
//   const chat = await Chat.find({
//     $or: [{ from: { $in: id } }, { to: { $in: id } }],
//   })
//     .lean()
//     .populate("-password -avatar")
//     .populate("-password -avatar");

//   return res
//     .status(201)

//     .json(chat);
// } catch (error) {
//   return res.status(404).json({ message: error.message });
// }
// };

// GET PATIENTS CHAT //
export const getChatsByPatient = async (req, res) => {
  const { id } = req.params;
  try {
    const chat = await Chat.find({ about: id })
      .populate({ path: "from" })
      .populate({ path: "to" })
      .populate({ path: "user", populate: { path: "from", select: "name" } });
    return res.status(201).json(chat);
  } catch (error) {
    res.status(404).json({ message: error.message });
  }
};

// GET PATIENTS HISTORY  //

export const getMyAppointmentsByPatients = async (req, res) => {
  const { id } = req.params;

  const patient = await Patient.findOne({ user: id });
  if (!patient) {
    return res.status(404).json({ message: "No Patient" });
  }

  const {
    showCanceled = false,
    all,
    status,
    type,
    startDate,
    endDate,
    size = 20,
    page = 0,
  } = req.body;
  const filters = { patient: patient._id };

  if (all) {
    const appointments = await Appointement.find(filters)
      .populate({ path: "doctor", populate: { path: "user", select: "name" } })
      .sort({ start: -1 });

    return res.status(201).json(appointments);
  }

  if (status) {
    filters.status = status;
  }

  if (type) {
    filters.type = type;
  }

  if (showCanceled) {
    filters.status = { $ne: "Annuler" };
  }

  if (startDate) {
    if (!endDate) {
      filters.start = { $regex: `^${startDate}.*`, $options: "i" };
    } else {
      filters.start = { $gte: `${startDate}T00:00`, $lt: `${endDate}T23:59` };
    }
  } else if (endDate) {
    filters.start = { $lt: `${endDate}T23:59` };
  }

  try {
    const appointments = await Appointement.find(filters)
      .populate({ path: "doctor", populate: { path: "user", select: "name" } })
      .sort({ start: -1 })
      .skip(page * size)
      .limit(size);
    const count = await Appointement.countDocuments(filters);

    return res
      .status(201)
      .header("X-Pagination-Count", Math.ceil(count / size))
      .header("X-Pagination-Total", count)
      .header("X-Pagination-Page", page)
      .json(appointments);
  } catch (error) {
    res.status(404).json({ message: error.message });
  }
};

export const getPatients = async (req, res) => {
  try {
    const patients = await Patient.find({}).populate(
      "user",
      "-password -role -avatar"
    );
    res.json(patients);
  } catch (error) {
    res.status(404).json({ message: error.message });
  }
};

export const getPatientsByEtab = async (req, res) => {
  const { id } = req.params;
  try {
    const patients = await Patient.find({ assignedEtab: id }).populate(
      "user",
      "-password -avatar"
    );
    return res.status(201).json(patients);
  } catch (error) {
    return res.status(404).json({ message: error.message });
  }
};

export const filterPatients = async (req, res) => {
  const { phone, search, size = 20, page = 0 } = req.body;
  const filters = {};

  if (search) {
    const users = await User.find({
      name: { $regex: `.*${search}.*`, $options: "i" },
    }).select("_id");
    filters.user = { $in: users };
  }

  if (phone) {
    const usersByPhone = await User.find({
      phone: { $regex: `.*${phone}.*`, $options: "i" },
    }).select("_id");
    filters.user = { $in: usersByPhone };
  }

  try {
    const patients = await Patient.find(filters)
      .populate("user", "-password -avatar")
      .sort({ "user.name": 1 })
      .skip(page * size)
      .limit(size);
    const count = await Patient.countDocuments(filters);

    res
      .status(201)
      .header("X-Pagination-Count", Math.ceil(count / size))
      .header("X-Pagination-Total", count)
      .header("X-Pagination-Page", page)
      .json(patients);
  } catch (error) {
    res.status(404).json({ message: error.message });
  }
};

export const getPatient = async (req, res) => {
  const { id } = req.params;
  try {
    const patient = await Patient.findOne({ user: id }).populate(
      "user",
      "-password -avatar"
    );
    res.status(200).json(patient);
  } catch (error) {
    res.status(404).json({ message: error.message });
  }
};

export const createPatient = async (req, res) => {
  const {
    name,
    assignedEtab,
    securityNumber,
    paymentCenter,
    birthday,
    email,
    password,
    fixeNumber,
    phone,
    address,
    access,
    cp,
    city,
    information,
    rdv,
    treatingDoctor,
    ame,
    cmu,
    blacklist,
  } = req.body;
  let hashedPassword = "";

  try {
    const oldUser = await User.findOne({ email: email });
    if (oldUser)
      return res.status(401).json({ message: "User Already Exists!" });
    if (password) hashedPassword = await bcrypt.hash(password, 12);

    const newUser = new User({
      name: name,
      email: email,
      phone: phone,
      password: hashedPassword,
      role: "patient",
    });

    const user = await newUser.save();

    const newPatient = new Patient({
      user: user._id,
      assignedEtab: assignedEtab,
      securityNumber: securityNumber,
      paymentCenter: paymentCenter,
      birthday: birthday,
      email: email,
      fixeNumber: fixeNumber,
      address: address,
      access: access,
      cp: cp,
      city: city,
      information: information,
      rdv: rdv,
      treatingDoctor: treatingDoctor,
      ame: ame,
      cmu: cmu,
      blacklist: blacklist,
    });
    await newPatient.save();

    const patient = await Patient.findById(newPatient._id)
      .populate("user", "-password -avatar")
      .populate({
        path: "assignedEtab",
        model: "Etablissement",
      });

    res.status(201).json(patient);
  } catch (error) {
    res.status(409).json({ message: error.message });
  }
};

export const editPatient = async (req, res) => {
  let hashedPassword = null;
  const { id } = req.params;
  const {
    name,
    assignedEtab,
    securityNumber,
    paymentCenter,
    birthday,
    email,
    password,
    fixeNumber,
    phone,
    address,
    access,
    cp,
    city,
    information,
    rdv,
    treatingDoctor,
    ame,
    cmu,
    blacklist,
  } = req.body;

  // current patient fetch
  try {
    const currentPatient = await Patient.findById(id);

    if (password && password.length > 0) {
      hashedPassword = await bcrypt.hash(password, 12);
    }
    const updatedUser = {
      _id: currentPatient.user,
      name: name,
      email: email,
      phone: phone,
      password: hashedPassword,
    };

    await User.findByIdAndUpdate(currentPatient.user, updatedUser, {
      new: true,
    });

    const updatedPatient = {
      _id: currentPatient._id,
      user: currentPatient.user,
      assignedEtab: assignedEtab,
      securityNumber: securityNumber,
      paymentCenter: paymentCenter,
      birthday: birthday,
      email: email,
      fixeNumber: fixeNumber,
      address: address,
      access: access,
      cp: cp,
      city: city,
      information: information,
      rdv: rdv,
      treatingDoctor: treatingDoctor,
      ame: ame,
      cmu: cmu,
      blacklist: blacklist,
    };

    await Patient.findByIdAndUpdate(currentPatient._id, updatedPatient, {
      new: true,
    });

    const patient = await Patient.findById(id)
      .populate("user", "-password -avatar")
      .populate({
        path: "assignedEtab",
        model: "Etablissement",
      });

    res.status(201).json(patient);
  } catch (error) {
    res.status(409).json({ message: error.message });
  }
};

export const blockPatient = async (req, res) => {
  const { id } = req.params;
  const { blacklist } = req.body;
  try {
    const currentPatient = await Patient.findById(id)
      .populate("user", "-password -avatar")
      .populate({
        path: "assignedEtab",
        model: "Etablissement",
      });
    currentPatient.blacklist = blacklist;
    const result = await currentPatient.save();
    res.status(201).json(result);
  } catch (error) {
    res.status(409).json({ message: error.message });
  }
};

export const deletePatient = async (req, res) => {
  const { id } = req.params;
  const patient = await Patient.findById(id);

  try {
    await User.findByIdAndRemove(patient.user);
    await Patient.findByIdAndRemove(id);

    res.status(201).send("Patient deleted successfully.");
  } catch (error) {
    res.status(500).json({ message: "Error" });
    console.log(error);
  }
};

export default router;
