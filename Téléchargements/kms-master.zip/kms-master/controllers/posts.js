import express from 'express';
import Post from '../models/post.js';

const router = express.Router();

export const getPosts = async (req, res) => {
    try {
        const posts = await Post.find({ status: "Public"});
        if (posts) {
            posts.map(post => post.photos ? post.photos = [post.photos[0]] : null)
        }
        res.json({ data: posts});
    } catch (error) {    
        res.status(404).json({ message: error.message });
    }
}

export const getWaitingPosts = async (req, res) => {
    try {
        const posts = await Post.find({status: 'Waiting'})
                                .populate({path: 'creator', select: 'name'});
        if(posts) {
            posts.map(post => post.photos ? post.photos = [post.photos[0]] : null )
        }
        res.json({ data: posts});
    } catch (error) {    
        res.status(404).json({ message: error.message });
    }
}

export const getPublicPosts = async (req, res) => {
    try {
        const posts = await Post.find({status: 'Public'}).populate({path: 'creator', select: 'name'});
        if(posts) {
            posts.map(post => post.photos ? post.photos = [post.photos[0]] : null )
        }
        res.json({ data: posts});
    } catch (error) {    
        res.status(404).json({ message: error.message });
    }
}

export const getPost = async (req, res) => { 
    const { id } = req.params;
    try {
        const post = await Post.findById(id);
        res.status(200).json({data: post});
    } catch (error) {
        res.status(404).json({ message: error.message });
    }
}

export const createPost = async (req, res) => {
    const post = req.body;
    const newPost = new Post({ ...post })
    try {
        await newPost.save();
        res.status(201).json(newPost);
    } catch (error) {
        res.status(409).json({ message: error.message });
    }
}

export const updatePost = async (req, res) => {
    const { id } = req.params;
    const { title, message, creator, selectedFile, tags } = req.body;
    const updatedPost = { creator, title, message, tags, selectedFile, _id: id };
    await Post.findByIdAndUpdate(id, updatedPost, { new: true });
    res.json(updatedPost);
}

export const deletePost = async (req, res) => {
    const { id } = req.params;
    await Post.findByIdAndRemove(id);
    res.json({ message: "Post deleted successfully." });
}

export const likePost = async (req, res) => {
    const { id } = req.params;
    if (!req.userId) {
        return res.json({ message: "Unauthenticated" });
      }
    const post = await Post.findById(id);
    const index = post.likes.findIndex((id) => id ===String(req.userId));
    if (index === -1) {
      post.likes.push(req.userId);
    } else {
      post.likes = post.likes.filter((id) => id !== String(req.userId));
    }
    const updatedPost = await Post.findByIdAndUpdate(id, post, { new: true });
    res.status(200).json(updatedPost);
}

export const commentPost = async (req, res) => {
    const { id } = req.params;
    const { value } = req.body;
    const post = await Post.findById(id);
    post.comments.push(value);
    const updatedPost = await Post.findByIdAndUpdate(id, post, { new: true });
    res.json(updatedPost);
};

export const publicWaiting = async (req, res) => {
    const { id } = req.params;
    try {
      const post = await Post.findById(id);
      req.body.status ? post.status = req.body.status : null;
      req.body.rating ? post.rating = req.body.rating : null;
      req.body.avis ? post.avis = req.body.avis : null;
      await post.save();
      res.status(200).json(id);
    } catch (error) {
      res.status(409).json({ message: error.message });
    }
}

export const topSwtich = async (req, res) => {
    const { id } = req.params;
    try {
      const post = await Post.findById(id).populate({path: 'creator', select: 'name'});
    if(post) {
        post.photos = [post.photos[0]]
    }
    post.top = req.body.val;
    await post.save();
    res.status(200).json(post);
    } catch (error) {
      res.status(409).json({ message: error.message });
    }
}

export default router;