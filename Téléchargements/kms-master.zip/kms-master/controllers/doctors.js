import express from "express";
import bcrypt from "bcryptjs";
import Doctor from "../models/doctor.js";
import User from "../models/user.js";
import Etablissement from "../models/etablissement.js";

const router = express.Router();

export const getDoctors = async (req, res) => {
  try {
    const doctors = await Doctor.find({})
      .populate("user", "-password -avatar")
      .populate("etablissement");

    res.status(201).json(doctors);
  } catch (error) {
    res.status(404).json({ message: error.message });
  }
};

export const getDoctor = async (req, res) => {
  const { id } = req.params;
  try {
    const doctor = await Doctor.findById(id)
      .populate("user", "-password -avatar")
      .populate("etablissement");

    res.status(201).json(doctor);
  } catch (error) {
    res.status(404).json({ message: error.message });
  }
};

export const getDoctorByUser = async (req, res) => {
  const { id } = req.params;
  try {
    const doctor = await Doctor.findOne({ user: id })
      .populate("user", "-password -avatar")
      .populate("etablissement");

    res.status(201).json(doctor);
  } catch (error) {
    res.status(404).json({ message: error.message });
  }
};

export const getDoctorsByEtab = async (req, res) => {
  const { id } = req.params;
  try {
    const etab = await Etablissement.findById(id);
    const doctors = await Doctor.find({ etablissement: id })
      .populate("user", "-password -avatar")
      .populate("etablissement");

    res.status(201).json(doctors);
  } catch (error) {
    res.status(404).json({ message: error.message });
  }
};

export const createDoctor = async (req, res) => {
  const {
    name,
    phone,
    email,
    password,
    etablissementId,
    etablissementName,
    etablissementPhone,
    etablissementAdress,
    postalCode,
    city,
    startDayHour,
    endDayHour,
    excludedDays,
    agendas,
  } = req.body;
  let hashedPassword = "";
  let newEtablissement = null;
  let newEtablissementId = null;

  try {
    const oldUser = await User.findOne({ email: email });
    if (oldUser)
      return res.status(401).json({ message: "User Already Exist!" });
    if (password) hashedPassword = await bcrypt.hash(password, 12);

    const newUser = new User({
      name: name,
      email: email,
      phone: phone,
      password: hashedPassword,
      role: "client",
    });

    const user = await newUser.save();

    if (!etablissementId) {
      newEtablissement = new Etablissement({
        name: etablissementName,
        phone: etablissementPhone,
        address: etablissementAdress,
        postalCode: postalCode,
        city: city,
        startDayHour: startDayHour,
        endDayHour: endDayHour,
        excludedDays: excludedDays,
      });
      newEtablissementId = await newEtablissement.save();
    }

    let eID;

    if (newEtablissementId) {
      eID = newEtablissementId._id;
    } else {
      eID = etablissementId;
    }

    const newDoctor = new Doctor({
      user: user._id,
      etablissement: eID,
      agendas: agendas,
    });
    await newDoctor.save();

    const doctor = await Doctor.findById(newDoctor._id)
      .populate("user", "-password -avatar")
      .populate("etablissement");

    res.status(201).json(doctor);
  } catch (error) {
    res.status(409).json({ message: error.message });
  }
};

export const editDoctor = async (req, res) => {
  let hashedPassword = null;
  const { id } = req.params;
  const { name, phone, password, etablissementId, agendas } = req.body;

  try {
    const currentDoctor = await Doctor.findById(id);

    if (password) {
      hashedPassword = await bcrypt.hash(password, 12);
    }
    const updatedUser = {
      _id: currentDoctor.user,
      name: name,
      phone: phone,
      password: hashedPassword,
    };

    await User.findByIdAndUpdate(currentDoctor.user, updatedUser, {
      new: true,
    });

    const updatedDoctor = {
      _id: currentDoctor._id,
      user: currentDoctor.user,
      etablissement: etablissementId,
      agendas: agendas,
    };

    await Doctor.findByIdAndUpdate(currentDoctor._id, updatedDoctor, {
      new: true,
    });

    const doctor = await Doctor.findById(id)
      .populate("user", "-password -avatar")
      .populate("etablissement");

    res.status(201).json(doctor);
  } catch (error) {
    res.status(409).json({ message: error.message });
  }
};

export const deleteDoctor = async (req, res) => {
  const { id } = req.params;
  const doctor = await Doctor.findById(id);

  try {
    await User.findByIdAndRemove(doctor.user);
    await Doctor.findByIdAndRemove(id);

    res.status(201).send("Doctor deleted successfully.");
  } catch (error) {
    res.status(500).json({ message: "Error" });
    console.log(error);
  }
};

export default router;
