import express from 'express';
import Setting from '../models/setting.js';
// import * as data from '../ssl/settingsData.js';

const router = express.Router();

// SEED SETTINGS FROM settingData.js
/* export const seedSettings = async (req, res) => {
    try {
        // Remove All Products
        await Setting.deleteMany({});
        const settings = await Setting.insertMany(data.settings);
        res.status(201).json(settings);
    } catch (error) {
        res.status(404).json({ message: error.message });
    }
}; */

export const getSettings = async (req, res) => {    
    try {
        const settings = await Setting.find({})
        res.status(201).json(settings);
    } catch (error) {    
        res.status(404).json({ message: error.message });
    }
}

export const createSetting = async (req, res) => {
    const {attribute, value, label} = req.body;
    
    try {
        const newSetting = new Setting({
            attribute: attribute,
            value: value,
            label: label,
        });

        const setting = await newSetting.save();
        res.status(201).json(setting);
    } catch (error) {
        res.status(409).json({ message: error.message });
    }
}

export const updateSetting = async (req, res) => {
    const settings = req.body;
    
    try {
        settings.forEach(async (setting) => {
            await Setting.findByIdAndUpdate(setting._id, {
                attribute: setting.attribute,
                value: setting.value,
                label: setting.label,
            });
        });
        res.status(201).json(settings);

    } catch (error) {
        res.status(409).json({ message: error.message });
    }
}

export const deleteSetting = async (req, res) => {
    const { id } = req.params;

    try  {
        await Setting.findByIdAndRemove(id);
        res.status(201).send('Setting deleted successfully.') ;
    } catch (error){
        res.status(500).json({ message: "Error" });
        console.log(error);
    }

}
 

export default router;