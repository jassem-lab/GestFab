import Event from "../models/event.js";
import User from "../models/user.js";

export const filterEvents = async (req, res) => {
    const { patientId, doctorId, startDate, endDate, size = 20, page = 0 } = req.body;
    const filters = {};

    if (patientId) {
        filters.patientId = patientId
    }

    if (doctorId) {
        filters.doctorId = doctorId
    }

    if (startDate) {
        if (!endDate) {
            filters.createdAt = { $gte: `${startDate}T00:00` }
        } else {
            filters.createdAt = { $gte: `${startDate}T00:00`, $lt: `${endDate}T23:59` }
        }
    } else if (endDate) {
        filters.createdAt = { $lt: `${endDate}T23:59` }
    }

    try {
        const events = await Event.find(filters)
            .populate('actor', 'name', User)
            .sort({ createdAt: -1 })
            .skip(page * size)
            .limit(size);
        const count = await Event.countDocuments(filters);

        res.status(201)
            .header('X-Pagination-Count', Math.ceil(count / size))
            .header('X-Pagination-Total', count)
            .header('X-Pagination-Page', page)
            .json(events);
    } catch (error) {
        res.status(404).json({message: error.message});
    }
}
