import express from 'express';
import Etablissement from '../models/etablissement.js';

const router = express.Router();

export const getEtablissements = async (req, res) => {
    try {
        const etablissements = await Etablissement.find({});
        res.status(201).json(etablissements);
    } catch (error) {    
        res.status(404).json({ message: error.message });
    }
}

export const getEtablissement = async (req, res) => { 
    const { id } = req.params;
    try {
        const etablissement = await Etablissement.findById(id);
        res.status(201).json(etablissement);
    } catch (error) {
        res.status(404).json({ message: error.message });
    }
}

export const createEtablissement = async (req, res) => {
    const { etablissementName, etablissementPhone, etablissementAdress, postalCode, city, startDayHour, endDayHour, excludedDays } = req.body
    const newEtablissement = new Etablissement({ 
        name: etablissementName,
        phone: etablissementPhone,
        address: etablissementAdress,
        postalCode: postalCode,
        city: city,
        startDayHour: startDayHour,
        endDayHour: endDayHour,
        excludedDays: excludedDays
     })
    try {
        await newEtablissement.save();
        res.status(201).json(newEtablissement);
    } catch (error) {
        res.status(409).json({ message: error.message });
    }
}

export const updateEtablissement = async (req, res) => {
    const { id } = req.params;
    const { etablissementName, etablissementPhone, etablissementAdress, postalCode, city, startDayHour, endDayHour, excludedDays } = req.body
    const updatedEtablissement = { 
        _id: id,
        name: etablissementName,
        phone: etablissementPhone,
        address: etablissementAdress,
        postalCode: postalCode,
        city: city,
        startDayHour: startDayHour,
        endDayHour: endDayHour,
        excludedDays: excludedDays
    };
    try {
        await Etablissement.findByIdAndUpdate(id, updatedEtablissement, { new: true });
        res.status(201).json(updatedEtablissement);
    } catch (error) {
        res.status(409).json({ message: error.message });
    }
    
}

export const deleteEtablissement = async (req, res) => {
    const { id } = req.params;
    try {
        await Etablissement.findByIdAndRemove(id);
        res.status(201).json({ message: "Etablissement deleted successfully." });
    } catch (error) {
        res.status(409).json({ message: error.message });
    }
}

export default router;