import express from "express";
import Doctor from "../models/doctor.js";
import Resa from "../models/resa.js";
import moment from "moment";

const router = express.Router();

export const getResas = async (req, res) => {
  try {
    const resas = await Resa.find({});
    res.status(201).json(Resa);
  } catch (error) {
    res.status(404).json({ message: error.message });
  }
};

export const getResasByMonth = async (req, res) => {
  const { date } = req.params; // YYYY-MM-DD
  const dateMoment = moment(date, "YYYY-MM-DD");
  const startSearchDate = dateMoment.weekday(0).format("YYYY-MM-DDTHH:mm");
  const endSearchDate = dateMoment.weekday(7).format("YYYY-MM-DDTHH:mm");
  try {
    const resas = await Resa.find({
      start: {
        $gte: startSearchDate,
        $lt: endSearchDate,
      },
    }); // YYYY-MM-DDTHH:mm

    res.status(201).json(resas);
  } catch (error) {
    res.status(404).json({ message: error.message });
  }
};

export const getResasByAgenda = async (req, res) => {
  const { agendas } = req.body;
  try {
    const resas = await Resa.find({ agenda: { $in: agendas } });
    /* const myAgendas = await Agenda.find({ _id: {"$in" : agendas} }).populate('template');
        let calendar = [];

        myAgendas.forEach(agenda => {
            
            if (agenda.template) {
                const startMoment = moment(agenda.template.startDate);
                const endMoment = moment(agenda.template.endDate);
                const myAgenda = [];
                
                while (startMoment.isBefore(endMoment)) {
                    const day = startMoment.format('YYYY-MM-DD');
                    const myResas = resas.filter(resa => moment(resa.start).format('YYYY-MM-DD') === day && resa.agenda === agenda._id);
                    
                    if (myResas && myResas.length > 0) {
                        myAgenda.push({
                            day: day,
                            resas: myResas,
                        })                
                    }
                    
                    startMoment.add(1, 'days');
                }

                calendar.push({
                    agenda: agenda,
                    calendar: myAgenda,
                })
            }
        });
 */
    res.status(201).json(resas);
  } catch (error) {
    res.status(404).json({ message: error.message });
  }
};

export const getResasByDoctorId = async (req, res) => {
  const { id } = req.params;
  const myTypes = ["Cabine", "Salle"];
  try {
    const doctor = await Doctor.findById(id);
    const agendasIds = doctor.agendas;
    const resas = await Resa.find({
      agenda: { $in: agendasIds },
      status: "free",
      type: { $in: myTypes },
    });
    res.status(201).json(resas);
  } catch (error) {
    res.status(404).json({ message: error.message });
  }
};

export const getResasByEtablissementId = async (req, res) => {
  const { id } = req.params;
  const myTypes = ["Cabine", "Salle"];
  try {
    const doctors = await Doctor.find({ etablissement: id });
    const agendasIds = [];
    doctors.forEach((doctor) => {
      if (doctor.agendas) {
        doctor.agendas.map((agenda) => {
          agendasIds.push(agenda);
        });
      }
    });
    const resas = await Resa.find({
      agenda: { $in: agendasIds },
      status: "free",
      type: { $in: myTypes },
    });
    res.status(201).json(resas);
  } catch (error) {
    res.status(404).json({ message: error.message });
  }
};

export const getUpcomingFreeResas = async (req, res) => {
  const { types = [], doctors = [] } = req.body;
  const filters = {
    status: "free",
    start: { $gte: moment().format("YYYY-MM-DDTHH:mm") },
  };

  if (types && Array.isArray(types) && types.length) {
    filters.type = { $in: types };
  }

  if (doctors && Array.isArray(doctors) && doctors.length) {
    filters.doctor = { $in: doctors };
  }

  try {
    const resas = await Resa.find(filters).sort({ start: "asc" });
    res.status(201).json(resas);
  } catch (error) {
    res.status(404).json({ message: error.message });
  }
};

export const createResa = async (req, res) => {
  const { start, type, color, agenda } = req.body;

  try {
    const doctors = await Doctor.find({});
    const doctor = doctors.find((doctor) => doctor.agendas.includes(agenda));
    if (doctor) {
      const newResa = new Resa({
        start: start,
        doctor: doctor._id,
        type: type,
        color: color,
        status: "free",
        agenda: agenda,
      });
      const createdRed = await newResa.save();
      res.status(201).json(createdRed);
    } else {
      res.status(409).json({ message: "No Doctor" });
    }
  } catch (error) {
    res.status(409).json({ message: error.message });
  }
};

export const editResa = async (req, res) => {
  const { id } = req.params;
  const { start, type, color, status } = req.body;
  try {
    const currentResa = await Resa.findById(id);
    currentResa.start = start;
    currentResa.status = status; // Status updated !
    currentResa.type = type;
    currentResa.color = color;
    await currentResa.save();
    const updatedResa = await Resa.findById(id);
    res.status(200).json(updatedResa);
  } catch (error) {
    res.status(409).json({ message: error.message });
  }
};

export const changeStatusResa = async (req, res) => {
  const { id } = req.params;
  const { status } = req.body;

  try {
    const resa = await Resa.findById(id);
    resa.status = status;
    await resa.save();
    res.status(201).json(resa._id);
  } catch (error) {
    res.status(409).json({ message: error.message });
  }
};

export const deleteResa = async (req, res) => {
  const { id } = req.params;
  try {
    await Resa.findByIdAndDelete(id);
    res.status(201).json({ message: "Resa deleted" });
  } catch (error) {
    res.status(404).json({ message: error.message });
  }
};

export const seedResas = async (req, res) => {
  try {
    // Remove All Products
    await Resa.deleteMany({});
    res.status(201).json("all deleted");
  } catch (error) {
    res.status(404).json({ message: error.message });
  }
};

export const clearResas = async (req, res) => {
  try {
    /* const resas = await Resa.find({});
        resas.forEach(async resa => {
            resa.status = 'free'
            resa.takedBy = null;
            await resa.save();
        });
        res.status(201).json("all seted to free"); */
  } catch (error) {
    res.status(404).json({ message: error.message });
  }
};

export default router;
