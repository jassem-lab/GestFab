import express from "express";
import Chat from "../models/chat.js";

const router = express.Router();

// export const getChats = async (req, res) => {
//   const id = req.body;
//   try {
//     const chats = await Chat.find({ id })
//       .populate("from", "-password -avatar")
//       .populate("to", "-password -avatar");
//     res.status(201).json(chats.reverse());
//   } catch (error) {
//     res.status(404).json({ message: error.message });
//   }
// };
export const getChats = async (req, res) => {
  const { size = 20, page = 0 } = req.body;
  const filters = {};
  const id = req.body;
  const { doctorsByEtab } = req.body;
  const usersIds = [];
  // doctorsByEtab.map((doctor) => usersIds.push(doctor.user._id));
  //return res.status(201).json(doctorsIds)
  try {
    const chats = await Chat.find({
      id,
    })

      .populate("from", "-password -avatar")
      .populate("to", "-password -avatar")
      .skip(page * size)
      .limit(size);
    const count = await chats.countDocument(filters);
    res
      .status(201)
      .send({
        count,
        page,
      })
      .header("X-Pagination-Count", Math.ceil(count / size))
      .header("X-Pagination-Total", count)
      .header("X-Pagination-Page", page)
      .json(chats.reverse());
  } catch (error) {
    return res.status(404).json({ message: error.message });
  }
};
export const getChatsByDoctors = async (req, res) => {
  const { doctorsByEtab } = req.body;
  const usersIds = [];
  doctorsByEtab.map((doctor) => usersIds.push(doctor.user._id));
  //return res.status(201).json(doctorsIds)
  try {
    const chats = await Chat.find({
      $or: [{ from: { $in: usersIds } }, { to: { $in: usersIds } }],
    })

      .lean()
      .populate("from", "-password -avatar")
      .populate("to", "-password -avatar");
    return res.status(201).json(chats.reverse());
  } catch (error) {
    return res.status(404).json({ message: error.message });
  }
};

export const getChat = async (req, res) => {
  const { id } = req.body;
  try {
    const chats = await Chat.find({ to: id })
      .populate("from", "-password -avatar")
      .populate("to", "-password -avatar");
    res.json({ chats });
  } catch (error) {
    res.status(404).json({ message: error.message });
  }
};

export const createChat = async (req, res) => {
  const { from, to, about, object, message, file, seen } = req.body;
  const aboutId = about === "" ? null : about;

  try {
    const newChat = new Chat({
      from: from,
      to: to,
      about: aboutId,
      object: object,
      message: message,
      file: file,
      seen: seen,
    });

    await newChat.save();

    const chat = await Chat.findById(newChat._id)
      .populate("from", "-password -avatar")
      .populate("to", "-password -avatar");

    res.status(201).json(chat);
  } catch (error) {
    res.status(409).json({ message: error.message });
  }
};

export const editChat = async (req, res) => {
  const { id } = req.params;
  const { from, to, about, object, message, file, seen } = req.body;
  const aboutId = about === "" ? null : about;

  try {
    const updatedChat = {
      from: from,
      to: to,
      about: aboutId,
      object: object,
      message: message,
      file: file,
      seen: seen,
    };

    await Chat.findByIdAndUpdate(id, updatedChat, { new: true });

    const chat = await Chat.findById(id)
      .array()
      .populate("from", "-password -avatar")
      .populate("to", "-password -avatar");

    res.status(201).json(chat);
  } catch (error) {
    res.status(409).json({ message: error.message });
  }
};

export const messageSeen = async (req, res) => {
  const { id } = req.params;
  try {
    await Chat.findByIdAndUpdate(id, { seen: true }, { new: true });

    res.status(201).json({ message: "Message Seen Completed ..." });
  } catch (error) {
    res.status(409).json({ message: error.message });
  }
};

export const messageSeenByPatient = async (req, res) => {
  const { id } = req.params;
  try {
    const chatByPatient = await Chat.find({ about: id });
    chatByPatient.forEach(async (chat) => {
      chat.seen = true;
      await chat.save();
    });
    res.status(201).json({ message: "Message seen by patient completed ..." });
  } catch (error) {
    res.status(409).json({ message: error.message });
  }
};

export const deleteChat = async (req, res) => {
  const { id } = req.params;

  try {
    await Chat.findByIdAndRemove(id);

    res.status(201).send("Chat deleted successfully.");
  } catch (error) {
    res.status(500).json({ message: "Error" });
    console.log(error);
  }
};

export default router;
