# Summary

Date : 2022-01-12 21:24:24

Directory c:\Users\griss\OneDrive\Bureau\KineDoc

Total : 174 files,  37879 codes, 1260 comments, 1555 blanks, all 40694 lines

[details](details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| JSON | 5 | 19,978 | 0 | 5 | 19,983 |
| JavaScript | 166 | 17,777 | 1,222 | 1,509 | 20,508 |
| Markdown | 1 | 55 | 0 | 31 | 86 |
| CSS | 1 | 36 | 12 | 8 | 56 |
| HTML | 1 | 33 | 26 | 2 | 61 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 174 | 37,879 | 1,260 | 1,555 | 40,694 |
| client | 133 | 33,871 | 1,009 | 1,181 | 36,061 |
| client\public | 2 | 58 | 26 | 3 | 87 |
| client\src | 128 | 15,734 | 983 | 1,145 | 17,862 |
| client\src\actions | 12 | 825 | 16 | 98 | 939 |
| client\src\api | 1 | 91 | 4 | 16 | 111 |
| client\src\constants | 1 | 123 | 1 | 12 | 136 |
| client\src\logged_in | 39 | 7,695 | 95 | 484 | 8,274 |
| client\src\logged_in\components | 38 | 7,652 | 95 | 483 | 8,230 |
| client\src\logged_in\components\Appointment | 4 | 835 | 10 | 48 | 893 |
| client\src\logged_in\components\Calendar | 10 | 1,694 | 60 | 151 | 1,905 |
| client\src\logged_in\components\Clients | 1 | 12 | 0 | 4 | 16 |
| client\src\logged_in\components\Doctors | 5 | 1,830 | 1 | 66 | 1,897 |
| client\src\logged_in\components\Etablissements | 1 | 50 | 1 | 6 | 57 |
| client\src\logged_in\components\Event | 1 | 208 | 2 | 12 | 222 |
| client\src\logged_in\components\Forms | 1 | 90 | 0 | 12 | 102 |
| client\src\logged_in\components\Messenger | 4 | 878 | 2 | 58 | 938 |
| client\src\logged_in\components\Patients | 4 | 634 | 2 | 33 | 669 |
| client\src\logged_in\components\Profile | 1 | 165 | 2 | 12 | 179 |
| client\src\logged_in\components\dashboard | 1 | 94 | 0 | 8 | 102 |
| client\src\logged_in\components\navigation | 3 | 835 | 9 | 40 | 884 |
| client\src\logged_in\dummy_data | 1 | 43 | 0 | 1 | 44 |
| client\src\logged_out | 15 | 2,358 | 210 | 123 | 2,691 |
| client\src\logged_out\components | 15 | 2,358 | 210 | 123 | 2,691 |
| client\src\logged_out\components\cookies | 3 | 277 | 7 | 17 | 301 |
| client\src\logged_out\components\footer | 1 | 78 | 175 | 6 | 259 |
| client\src\logged_out\components\home | 3 | 900 | 14 | 36 | 950 |
| client\src\logged_out\components\navigation | 1 | 159 | 12 | 8 | 179 |
| client\src\logged_out\components\register_login | 5 | 810 | 2 | 34 | 846 |
| client\src\reducers | 12 | 333 | 2 | 34 | 369 |
| client\src\shared | 38 | 3,851 | 568 | 322 | 4,741 |
| client\src\shared\components | 29 | 3,427 | 39 | 182 | 3,648 |
| client\src\shared\functions | 9 | 424 | 529 | 140 | 1,093 |
| controllers | 12 | 1,649 | 239 | 263 | 2,151 |
| middleware | 1 | 22 | 0 | 9 | 31 |
| models | 12 | 152 | 0 | 32 | 184 |
| routes | 12 | 160 | 5 | 47 | 212 |

[details](details.md)